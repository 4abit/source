#pragma once
#include "../includes.hpp"
#include "hooking.hpp"

namespace ams {
	// @evitable.
	inline DWORD_PTR* pSwapChainVtable = NULL;
	inline HWND window = NULL;
	inline ID3D11Device* p_device = NULL;
	inline ID3D11DeviceContext* p_context = NULL;
	inline ID3D11RenderTargetView* main_render_target_view;

	// @evitable.
	namespace wndproc {
		inline WNDPROC original;
		LRESULT __stdcall  wndproc_hook( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam );

		inline bool opened_menu;
	}

	namespace skip_subtick {
		inline ams::detour_t shared_hook;

		void __fastcall hooker( ams::movement_services_t* movement_services, c_player_move_data* move_data );
	}

	namespace createmove {
		inline ams::detour_t shared_hook;

		void __fastcall hooker( ams::cs_input_t* input, unsigned int a2, __int64 a3, unsigned __int8 unk );
	}

	namespace validate_input {
		inline ams::detour_t shared_hook;

		void __fastcall hooker( ams::cs_input_t* input, int unk );
	}

	namespace frame_stage {
		inline ams::detour_t shared_hook;

		void __fastcall hooker( void* rcx, int frame_stage );
	}

	namespace hltv {
		inline ams::detour_t shared_hook;

		char __fastcall hooker( );
	}

	namespace view_matrix {
		inline ams::detour_t shared_hook;

		// preclass.
		class render_game_system_t;

		// main
		evo::view_matrix_t* __fastcall get_matrix_view( render_game_system_t* m_render_game_system, ams::render_view_t* m_view_render,
											evo::view_matrix_t* m_out_world_view, evo::view_matrix_t* m_out_view_projection, 
											evo::view_matrix_t* m_out_world_projection, evo::view_matrix_t* m_out_world_pixels );
	}

	namespace draw_object {
		inline ams::detour_t shared_hook;

		void __fastcall draw_object( void* animatable_object, void* dx11, material_data_t* arr_material_data, int data_count,
									 void* scene_view, void* scene_layer, void* unk1, void* unk2 );
	}

	// @evitable.
	namespace present {
		typedef HRESULT( __stdcall* presentfn )( IDXGISwapChain*, UINT, UINT );
		inline presentfn original;

		HRESULT __stdcall present_hook( IDXGISwapChain* swap_chain, UINT sync, UINT flags );
	}

	class hooks_t {
	public:
		void create_hooks( );
		void destroy_hooks( );
		void create_directx( );
	};

	// share class
	share_class( _hooks, hooks_t );


	// screen.
	namespace screen {
		inline bool world_error = false;
		bool world_to_screen( const evo::vec3_t& m_origin, evo::vec2_t& m_screen );
	}
}