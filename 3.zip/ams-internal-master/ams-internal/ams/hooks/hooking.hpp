#pragma once
#include "../thirdparty/minhook/minhook.h"

namespace ams {
	class detour_t {
		void* function;
		void* detour;
		void* trampoline;

	public:
		void hook( void* target, void* dtr, std::string what ) {
			function = target;
			detour = dtr;

			if ( !MH_CreateHook( function, detour, &trampoline ) ) {
				log_success( "hooked " + what );
			}
			MH_EnableHook( function );
		}

		void hook_virtual( void* ptr, int index, void* function, std::string what ) {
			hook( ( *reinterpret_cast< LPVOID** >( ptr ) )[ index ], function, what );
		}

		void hook( uintptr_t target, void* dtr, std::string what ) {
			hook( ( void* )target, dtr, what );
		}

		template <typename hook_original>
		hook_original get_original( ) {
			return reinterpret_cast< hook_original >( trampoline );
		}

		void unhook( ) {
			if ( !function || !detour )
				return;

			MH_DisableHook( function );
			MH_RemoveHook( function );
		}
	};
}