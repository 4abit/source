#include "../hooks.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hacks/visuals/visuals.hpp"
#include "../../hacks/rage/rage.hpp"
#include "../../hacks/chams/chams.hpp"

void __fastcall ams::draw_object::draw_object( void* animatable_object, void* dx11, material_data_t* arr_material_data,
											   int data_count, void* scene_view, void* scene_layer, void* unk1, void* unk2 ) {
	static const auto original = ams::draw_object::shared_hook.get_original<void( __fastcall* )
		( void*, void*, material_data_t*, int, void*, void*, void*, void* )>( );

	if ( !ams::engine->is_connected( ) || !ams::engine->is_in_game( ) ) {
		// just call it ig?
		return original( animatable_object, dx11, arr_material_data, data_count, scene_view, scene_layer, unk1, unk2 );
	}

	if ( game::local_controller == nullptr || game::local_pawn == nullptr ) {
		// just call it ig?
		return original( animatable_object, dx11, arr_material_data, data_count, scene_view, scene_layer, unk1, unk2 );
	}

	if ( !ams::_chams->draw_object( animatable_object, dx11, arr_material_data, data_count, scene_view, scene_layer, unk1, unk2 ) ) {
		// whatig?
		original( animatable_object, dx11, arr_material_data, data_count, scene_view, scene_layer, unk1, unk2 );
	}
}
