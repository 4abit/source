#include "../hooks.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hacks/visuals/visuals.hpp"
#include "../../hacks/rage/rage.hpp"

void __fastcall ams::validate_input::hooker( ams::cs_input_t* input, int unk ) {
	const auto original = ams::validate_input::shared_hook.get_original<void( __fastcall* )
		( ams::cs_input_t*, int )>( );

	const evo::vec3_t m_angle = input->viewangles;

	// call original
	original( input, unk );

	// restore
	input->viewangles = m_angle;
}
