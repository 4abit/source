#include "../hooks.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hacks/visuals/visuals.hpp"
#include "../../hacks/rage/rage.hpp"
#include "../../hacks/visuals/usermode/usermode.hpp"

// forward declare.
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );

// wndproc.
LRESULT __stdcall ams::wndproc::wndproc_hook( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam ) {
    if ( msg == WM_MOUSEMOVE )
        evo::_input->set_mouse_position( evo::vec2_t( GET_X_LPARAM( lparam ), GET_Y_LPARAM( lparam ) ) );

    if ( msg == WM_MOUSEWHEEL )
        evo::_input->set_mouse_wheel( GET_WHEEL_DELTA_WPARAM( wparam ) / WHEEL_DELTA );

    if ( GetAsyncKeyState( VK_HOME ) & 1 )
        opened_menu = !opened_menu;

    // call original
    return ::CallWindowProcA( original, hwnd, msg, wparam, lparam );
}

// present.
HRESULT __stdcall ams::present::present_hook( IDXGISwapChain* swap_chain, UINT sync, UINT flags ) {
    static bool initialized{ false };
    if ( !initialized ) {
        if ( SUCCEEDED( swap_chain->GetDevice( __uuidof( ID3D11Device ), reinterpret_cast< void** >( &p_device ) ) ) ) {
            p_device->GetImmediateContext( &p_context );

            auto swapchain_desc = DXGI_SWAP_CHAIN_DESC{};
            swap_chain->GetDesc( &swapchain_desc );
            window = swapchain_desc.OutputWindow;

            ID3D11Texture2D* back_buffer{};
            swap_chain->GetBuffer( 0, __uuidof( ID3D11Texture2D ), reinterpret_cast< void** >( &back_buffer ) );
            p_device->CreateRenderTargetView( back_buffer, nullptr, &main_render_target_view );
            back_buffer->Release( );

            wndproc::original = ( WNDPROC )SetWindowLongPtr( window, GWLP_WNDPROC, ( LONG_PTR )wndproc::wndproc_hook );

            ImGui::CreateContext( );
            ImGuiIO& io = ImGui::GetIO( );
            io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;

            ImGui_ImplWin32_Init( window );
            ImGui_ImplDX11_Init( p_device, p_context );
          
            evo::_render->initialize_font_system( );

            initialized = true;
        } else {
            return original( swap_chain, sync, flags );
        }
    }

    ImGui_ImplDX11_NewFrame( );
    ImGui_ImplWin32_NewFrame( );
    ImGui::NewFrame( );

    // cache entity.
    if ( ams::engine->is_in_game( ) && ams::engine->is_connected( ) ) {
        // cache data.
        ams::_game->cache_entity( );
    }

    _visuals->construct( );
    _menu->init( );
    _usermode->construct( );
    _rage->draw_targeted_point( );

    ImGui::EndFrame( );
    ImGui::Render( );

    p_context->OMSetRenderTargets( 1, &main_render_target_view, NULL );
    ImGui_ImplDX11_RenderDrawData( ImGui::GetDrawData( ) );

    return original( swap_chain, sync, flags );
}