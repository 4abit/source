#include "../hooks.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hacks/visuals/visuals.hpp"
#include "../../hacks/rage/rage.hpp"

void __fastcall ams::skip_subtick::hooker( ams::movement_services_t* movement_services, c_player_move_data* move_data ) {
	static auto original = ams::skip_subtick::shared_hook.get_original<void( __fastcall* )( void*, void* )>( );
	return original( movement_services, move_data );
}