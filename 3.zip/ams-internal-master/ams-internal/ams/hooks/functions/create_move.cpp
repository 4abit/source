#include "../hooks.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hacks/visuals/visuals.hpp"
#include "../../hacks/rage/rage.hpp"

void movement_fix( ams::user_cmd_t* cmd, evo::vec3_t original_angles ) {
	/* get wish angles */
	evo::vec3_t ang_wish_angles;
	ang_wish_angles = original_angles;

	evo::vec3_t pure_forward, pure_right, pure_up, curr_forward, curr_right, curr_up;
	evo::math::angle_vectors( ang_wish_angles, &pure_forward, &pure_right, &pure_up );
	evo::math::angle_vectors( evo::vec3_t( cmd->m_base_cmd->m_cmd_view->m_angle.x, cmd->m_base_cmd->m_cmd_view->m_angle.y, cmd->m_base_cmd->m_cmd_view->m_angle.z ), &curr_forward, &curr_right, &curr_up );

	pure_forward[ 2 ] = pure_right[ 2 ] = curr_forward[ 2 ] = curr_right[ 2 ] = 0.f;

	auto vector_normalize = [ ]( evo::vec3_t& vec ) -> float {
		float radius = sqrtf( vec.x * vec.x + vec.y * vec.y + vec.z * vec.z );
		float iradius = 1.f / ( radius + FLT_EPSILON );

		vec.x *= iradius;
		vec.y *= iradius;
		vec.z *= iradius;

		return radius;
		};

	vector_normalize( pure_forward );
	vector_normalize( pure_right );
	vector_normalize( curr_forward );
	vector_normalize( curr_right );

	evo::vec3_t pure_wish_dir;
	for ( auto i = 0u; i < 2; i++ )
		pure_wish_dir[ i ] = pure_forward[ i ] * cmd->m_base_cmd->m_forward_move + pure_right[ i ] * cmd->m_base_cmd->m_side_move;
	pure_wish_dir[ 2 ] = 0.f;

	evo::vec3_t curr_wish_dir;
	for ( auto i = 0u; i < 2; i++ )
		curr_wish_dir[ i ] = curr_forward[ i ] * cmd->m_base_cmd->m_forward_move + curr_right[ i ] * cmd->m_base_cmd->m_side_move;
	curr_wish_dir[ 2 ] = 0.f;

	if ( pure_wish_dir != curr_wish_dir ) {
		cmd->m_base_cmd->m_forward_move = ( pure_wish_dir.x * curr_right.y - curr_right.x * pure_wish_dir.y ) / ( curr_right.y * curr_forward.x - curr_right.x * curr_forward.y );
		cmd->m_base_cmd->m_side_move = ( pure_wish_dir.y * curr_forward.x - curr_forward.y * pure_wish_dir.x ) / ( curr_right.y * curr_forward.x - curr_right.x * curr_forward.y );
	}
}

void __fastcall ams::createmove::hooker( ams::cs_input_t* input, unsigned int a2, __int64 a3, unsigned __int8 unk ) {
	// hook original.
	static auto original = ams::createmove::shared_hook.get_original<void( __fastcall* )
		( ams::cs_input_t*, unsigned int, __int64, unsigned __int8 )>( );

	// call original again
	original( input, a2, a3, unk );

	// get user cmd.
	ams::user_cmd_t* cmd = input->get_user_cmd( );
	if ( cmd == nullptr ) {
		log_error( "cmd is nullptr" );
		original( input, a2, a3, unk );
	}

	// get local controller.
	auto local_controler = ams::player_controller_t::get_local_controller( );
	if ( local_controler == nullptr ) {
		log_error( "local_controler is nullptr" );
		original( input, a2, a3, unk );
	}

	// store local controller.
	ams::game::local_controller = local_controler;

	// get local pawn
	auto local_pawn = ams::resource_services->m_game_entity_system->construct<ams::player_pawn_t>(
		local_controler->get_pawn_handle( ) );
	if ( local_pawn == nullptr ) {
		log_error( "local_pawn is nullptr" );
		original( input, a2, a3, unk );
	}

	// store local pawn
	ams::game::local_pawn = local_pawn;

	// check if cmd is valid
	if ( !cmd || !cmd->m_base_cmd ) {
		return;
	}

	auto saved_viewangles = ams::input->viewangles;

	// run aimbot.
	ams::_rage->run( cmd );

	if ( cmd->m_base_cmd ) {
		cmd->m_base_cmd->m_cmd_view->m_angle.x = 89.f;
		cmd->m_base_cmd->m_cmd_view->m_angle.y += 180;
	}
	
	movement_fix( cmd, saved_viewangles );
}
