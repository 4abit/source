#include "../hooks.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hacks/visuals/visuals.hpp"

evo::view_matrix_t* __fastcall ams::view_matrix::get_matrix_view( render_game_system_t* m_render_game_system, ams::render_view_t* m_view_render,
																  evo::view_matrix_t* m_out_world_view, evo::view_matrix_t* m_out_view_projection,
																  evo::view_matrix_t* m_out_world_projection, evo::view_matrix_t* m_out_world_pixels ) {
	// hook original.
	static auto original = ams::view_matrix::shared_hook.get_original<evo::view_matrix_t * ( __fastcall* )
		( render_game_system_t*, ams::render_view_t*, evo::view_matrix_t*, evo::view_matrix_t*, evo::view_matrix_t*, evo::view_matrix_t* )>( );

	// get result
	evo::view_matrix_t* result = original( m_render_game_system, m_view_render, m_out_world_view, m_out_view_projection, m_out_world_projection, m_out_world_pixels );

	// get matrix.
	game::screen_matrix = *m_out_world_projection;

	// return original;
	return result;
}

bool ams::screen::world_to_screen( const evo::vec3_t& m_origin, evo::vec2_t& m_screen ) {
	const float m_width = game::screen_matrix[ 3 ][ 0 ] * m_origin.x + game::screen_matrix[ 3 ][ 1 ] * m_origin.y
		+ game::screen_matrix[ 3 ][ 2 ] * m_origin.z + game::screen_matrix[ 3 ][ 3 ];

	// behind us.
	if ( m_width < 0.001f ) {
		return false;
	}

	const float m_inverse = 1.0f / m_width;
	m_screen.x = ( game::screen_matrix[ 0 ][ 0 ] * m_origin.x + game::screen_matrix[ 0 ][ 1 ] * m_origin.y
				   + game::screen_matrix[ 0 ][ 2 ] * m_origin.z + game::screen_matrix[ 0 ][ 3 ] ) * m_inverse;

	m_screen.y = ( game::screen_matrix[ 1 ][ 0 ] * m_origin.x + game::screen_matrix[ 1 ][ 1 ] * m_origin.y
				   + game::screen_matrix[ 1 ][ 2 ] * m_origin.z + game::screen_matrix[ 1 ][ 3 ] ) * m_inverse;

	// screen transform
	// get the screen position in pixels of given point
	const ImVec2 display_size = ImGui::GetIO( ).DisplaySize;
	m_screen.x = ( display_size.x * 0.5f ) + ( m_screen.x * display_size.x ) * 0.5f;
	m_screen.y = ( display_size.y * 0.5f ) - ( m_screen.y * display_size.y ) * 0.5f;

	return true;
}