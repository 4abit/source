#include "hooks.hpp"
#include "../hacks/chams/chams.hpp"
#include "../game-data/game_data.hpp"

// minhooks.
#include "../thirdparty/minhook/minhook.h"

void ams::hooks_t::create_hooks( ) { 
	/*
		* create move ida:
		* CCSGOInput:: ; #STR: "cl: %d: %s\n", "cl: %d ===========================\n"
		* func index: 4-5
	*/
	ams::createmove::shared_hook.hook_virtual( ams::input, 5, ams::createmove::hooker, "createmove::hooker" );
	ams::frame_stage::shared_hook.hook_virtual( ams::client, 36, ams::frame_stage::hooker, "framestage::hooker" );

	/*
		.text:0000000180AAB73B                 mov     dword ptr [rbp+var_10+8], ebx
		.text:0000000180AAB73E                 lea     rax, htlv_reveal_money
		.text:0000000180AAB745                 mov     qword ptr [rbp+var_10], rax
		.text:0000000180AAB749                 lea     r8, somecvarig
		.text:0000000180AAB750                 movaps  xmm0, [rbp+var_10]
		.text:0000000180AAB754                 lea     rdx, [rbp+var_10]
		.text:0000000180AAB758                 lea     rcx, aIsdemoorhltv ; "IsDemoOrHltv"
	*/
	ams::hltv::shared_hook.hook( memory::find_pattern( L"client.dll", "48 83 EC 28 48 8B 0D ?? ?? ?? ?? 48 8B 01 FF 90 ?? ?? ?? ?? 84 C0 75 0D" ), ams::hltv::hooker, "hltv" );
	//ams::skip_subtick::shared_hook.hook( memory::to_absolute( memory::search_for_memory( "client.dll", "E8 ? ? ? ? 48 8B 43 30 33 ED" ) + 0x1 ), ams::skip_subtick::hooker, "skip subtick" );
	
	/*
		* get matrix view:
		* CViewRender:: ; #STR: "C:\\buildworker\\csgo_rel_win64\\build\\src\\game\\client\ ; // -1 : "CViewRender::Render"
	*/
	ams::view_matrix::shared_hook.hook( memory::find_pattern( L"client.dll", "40 53 48 81 EC ? ? ? ? 49 8B C1" ), ams::view_matrix::get_matrix_view, "get_matrix_view" );
	ams::draw_object::shared_hook.hook( memory::find_pattern( L"scenesystem.dll", "48 8B C4 48 89 50 10 53" ), ams::draw_object::draw_object, "draw_object" );
	
	
	ams::validate_input::shared_hook.hook_virtual( ams::input, 7, ams::validate_input::hooker, "validate input" );
}

void ams::hooks_t::destroy_hooks( ) {
	// destroy hooks
	ams::createmove::shared_hook.unhook( );
	ams::view_matrix::shared_hook.unhook( );
	ams::draw_object::shared_hook.unhook( );
	ams::validate_input::shared_hook.unhook( );
	ams::frame_stage::shared_hook.unhook( );
	ams::hltv::shared_hook.unhook( );
}

// got this from unknowncheats.
void ams::hooks_t::create_directx( ) {
	// get window.
	HWND instance = GetForegroundWindow( );

	// directx vars.
	IDXGISwapChain* m_swap_chain;
	ID3D11Device* m_device;
	ID3D11DeviceContext* m_context;

    // init memory.
    D3D_FEATURE_LEVEL m_feature_level = D3D_FEATURE_LEVEL_11_0;
    DXGI_SWAP_CHAIN_DESC m_chain_desc;
    ZeroMemory( &m_chain_desc, sizeof( m_chain_desc ) );
	m_chain_desc.BufferCount = 1;
	m_chain_desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	m_chain_desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	m_chain_desc.OutputWindow = instance;
	m_chain_desc.SampleDesc.Count = 1;
	m_chain_desc.Windowed = TRUE;
	m_chain_desc.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
	m_chain_desc.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
	m_chain_desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

	// create device and swap
	D3D11CreateDeviceAndSwapChain( NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, NULL, &m_feature_level, 1
								   , D3D11_SDK_VERSION, &m_chain_desc, &m_swap_chain, &m_device, NULL, &m_context );

	// swapchain vtable.
	DWORD_PTR* m_swap_vtable = reinterpret_cast< DWORD_PTR* >( m_swap_chain );
	if ( m_swap_vtable == nullptr )
		return;

	m_swap_vtable = reinterpret_cast< DWORD_PTR* >( m_swap_vtable[ 0 ] );

	// create hook.
	MH_CreateHook( reinterpret_cast< DWORD_PTR* >( ( BYTE* )m_swap_vtable[ 8 ] ), 
				   present::present_hook, reinterpret_cast< void** >( &present::original ) );

	// release.
	m_device->Release( );
	m_context->Release( );
	m_swap_chain->Release( );
}

#include "../hacks/visuals/world/world.hpp"
void __fastcall ams::frame_stage::hooker( void* rcx, int frame_stage ) { 
	const auto original = ams::frame_stage::shared_hook.get_original<void( __fastcall* )( void*, int )>();

	// run feature
	_world->construct( );

	return original( rcx, frame_stage );
}

char __fastcall ams::hltv::hooker( ) {
	const auto original = ams::hltv::shared_hook.get_original<char( __fastcall* )( )>( );

	// should work ig
	if ( _cfg->bool_elem[ bool_features::reveal_money ] ) {
		return 1;
	} else {
		return original( );
	}
}
