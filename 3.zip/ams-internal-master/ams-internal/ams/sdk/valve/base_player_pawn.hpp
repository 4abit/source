#pragma once
#include "weapon/weapon.hpp"
#include "../../utils/other/base_handle.hpp"
#include "../../interfaces/valve/game_resource_service.hpp"
#include "../../interfaces/valve/entity_system.hpp"

namespace ams {
	class item_services_t {
	public:
		CS_CLASS_NO_INITIALIZER( item_services_t );

		schema_add_field( bool, has_defuser, "CCSPlayer_ItemServices->m_bHasDefuser" );
		schema_add_field( bool, has_hemlet, "CCSPlayer_ItemServices->m_bHasHelmet" );
		schema_add_field( bool, has_heavy_armor, "CCSPlayer_ItemServices->m_bHasHeavyArmor" );
	};

	enum bone_index : DWORD {
		head = 6,
		neck_0 = 5,
		spine_1 = 4,
		spine_2 = 2,
		pelvis = 0,
		arm_upper_L = 8,
		arm_lower_L = 9,
		hand_L = 10,
		arm_upper_R = 13,
		arm_lower_R = 14,
		hand_R = 15,
		hand_R2 = 16,
		leg_upper_L = 22,
		leg_lower_L = 23,
		ankle_L = 24,
		leg_upper_R = 25,
		leg_lower_R = 26,
		ankle_R = 27,
	};

	enum e_hitgroups {
		hitgroup_invalid = -1,
		hitgroup_generic = 0,
		hitgroup_head,
		hitgroup_chest,
		hitgroup_stomach,
		hitgroup_left_arm,
		hitgroup_right_arm,
		hitgroup_left_leg,
		hitgroup_right_leg,
		hitgroup_neck,
		hitgroup_unused,
		hitgroup_gear,
		hitgroup_special,
		hitgroup_count,
	};

	class movement_services_t {
	public:
		schema_add_field( int, m_impulse, "CPlayer_MovementServices->m_nImpulse" );
		schema_add_field( uint32_t, m_buttons, "CPlayer_MovementServices->m_nButtons" );

		ams::player_pawn_t* get_owner( ) {
			return *reinterpret_cast< ams::player_pawn_t** >( ( uintptr_t )this + 0x30 );
		}
	};

	class post_processing_t {
	public:
		CS_CLASS_NO_INITIALIZER( post_processing_t );

		schema_add_field( bool, master, "C_PostProcessingVolume->m_bMaster" );
		schema_add_field( float, min_exposure, "C_PostProcessingVolume->m_flMinExposure" );
		schema_add_field( float, max_exposure, "C_PostProcessingVolume->m_flMaxExposure" );
	};

	class camera_services_t {
	public:
		CS_CLASS_NO_INITIALIZER( camera_services_t );

		// < post_processing_t >
		/*
			auto local_pawn = ams::resource_services->m_game_entity_system->construct<ams::player_pawn_t>(
			local_controler->get_pawn_handle( ) );
		*/

		schema_add_field( CBaseHandle, post_processing_values, "CPlayer_CameraServices->m_hActivePostProcessingVolume" );
	};

	class weapon_services_t { // ithirates from cplayer_weaponservices
	public:
		CS_CLASS_NO_INITIALIZER( weapon_services_t );
		// m_flNextAttack
		// CCSPlayer_WeaponServices
		schema_add_field( float, next_attack, "CCSPlayer_WeaponServices->m_flNextAttack" );
	};

	class base_player_pawn_t : public base_model_entity_t {
	public:
		CS_CLASS_NO_INITIALIZER( base_player_pawn_t );

		schema_add_field( CBaseHandle, get_controller_handle, "C_BasePlayerPawn->m_hController" );
		schema_add_field( item_services_t*, item_services, "C_BasePlayerPawn->m_pItemServices" );
		schema_add_field( camera_services_t*, camera_services, "C_BasePlayerPawn->m_pCameraServices" );
		schema_add_field( weapon_services_t*, weapon_services, "C_BasePlayerPawn->m_pWeaponServices" );


		schema_add_field( int, get_survival_team, "C_CSPlayerPawnBase->m_nSurvivalTeam" );
		schema_add_field( weapon_base_t*, clipping_weapon, "C_CSPlayerPawnBase->m_pClippingWeapon" );
		schema_add_field( bool, is_scoped, "C_CSPlayerPawnBase->m_bIsScoped" );
		schema_add_field( int, armor_value, "C_CSPlayerPawnBase->m_ArmorValue" );

		void get_bone_position( std::uint32_t bone_index, evo::vec3_t& position, evo::vec3_t& rotation ) {
			using function_t = std::int64_t( __fastcall* )( base_player_pawn_t*, std::uint32_t, evo::vec3_t*, evo::vec3_t* );
			static function_t fn = reinterpret_cast< function_t >( memory::find_pattern( 
				L"client.dll", "48 89 6C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 4D 8B F1" ) );

			fn( this, bone_index, &position, &rotation );
		}

		[[nodiscard]] __forceinline bool is_armored( const int hitgroup ) {
			switch ( hitgroup ) {
				case hitgroup_head:
					return this->item_services()->has_hemlet( );
				case hitgroup_generic:
				case hitgroup_chest:
				case hitgroup_stomach:
				case hitgroup_left_arm:
				case hitgroup_right_arm:
					return true;
				default:
					return false;
			}
		}
	};
}