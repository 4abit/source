#pragma once

namespace ams {
	class collision_property_t {
	public:
		CS_CLASS_NO_INITIALIZER( collision_property_t );

		// schema.
		schema_add_field( evo::vec3_t, get_mins, "CCollisionProperty->m_vecMins" );
		schema_add_field( evo::vec3_t, get_maxs, "CCollisionProperty->m_vecMaxs" );
	};
}