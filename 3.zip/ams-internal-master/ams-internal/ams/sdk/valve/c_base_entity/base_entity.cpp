#include "../../../includes.hpp"

ams::base_entity_t* ams::base_entity_t::get_local_player( ) {
	const int m_index = ams::engine->get_local_player( );
	
	// return local
	return ams::resource_services->m_game_entity_system->construct( m_index );
}
