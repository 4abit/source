#pragma once

namespace ams {
	class base_entity_t : public entity_instance_t {
	public:
		CS_CLASS_NO_INITIALIZER( base_entity_t );

		// base controller
		[[nodiscard]] bool is_player_controller( ) {
			schema_class_info_data_t* m_class_info;
			get_schema_class_info( &m_class_info );
			if ( m_class_info == nullptr )
				return false;

			return FNV1A::Hash( m_class_info->m_name ) == FNV1A::HashConst( "C_CSPlayerController" );
		}

		// is weapon
		[[nodiscard]] bool is_weapon( ) {
			static schema_class_info_data_t* m_weapon_base_class = nullptr;
			if ( m_weapon_base_class == nullptr ) {
				// find schema module
				ams::schema_system->find_module( 
					CS_XOR( "client.dll" ) )->find_declared_class( &m_weapon_base_class, CS_XOR( "C_CSWeaponBase" ) );
			}

			schema_class_info_data_t* m_class_info;
			get_schema_class_info( &m_class_info );
			if ( m_class_info == nullptr )
				return false;

			return ( m_class_info->construct_from( m_weapon_base_class ) );
		}

		// get local player.
		static base_entity_t* get_local_player( );


		// fields.
		schema_add_field( std::int32_t, get_health, "C_BaseEntity->m_iHealth" );
		schema_add_field( int, get_team, "C_BaseEntity->m_iTeamNum" );
		schema_add_field( evo::vec3_t, get_velocity, "C_BaseEntity->m_vecAbsVelocity" );

		// transformers.
		schema_add_field( game_scene_node_t*, scene_node, "C_BaseEntity->m_pGameSceneNode" );
		schema_add_field( collision_property_t*, collision_property, "C_BaseEntity->m_pCollision" );
	};
}