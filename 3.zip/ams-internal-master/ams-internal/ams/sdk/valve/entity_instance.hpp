#pragma once

namespace ams {
	class entity_instance_t {
	public:
		// no initializer.
		// delete initializers to prevent using them
		CS_CLASS_NO_INITIALIZER( entity_instance_t );

		// function.
		void get_schema_class_info( schema_class_info_data_t** m_return ) {
			return memory::call_function<void, 38>( this, m_return );
		}

		[[nodiscard]] CBaseHandle get_reference_handle( ) {
			entity_indentity_t* m_identity = get_identity( );
			if ( m_identity == nullptr )
				return CBaseHandle( );

			return CBaseHandle( m_identity->get_entry_index( ), 
								m_identity->get_serial_numbers( ) - ( m_identity->get_flags( ) & 1 ) );
		}

		// schema.
		schema_add_field( entity_indentity_t*, get_identity, "CEntityInstance->m_pEntity" );
	};
}