#pragma once
#include "../../utils/other/stronghandle.hpp"

namespace ams {
	// preclass.
	struct alignas( 16 ) bone_data_t {
		evo::vec3_t pos;
		float scale;
		evo::vec4_t rot;
	};

	class model_skeleton_t {
	public:
		CS_CLASS_NO_INITIALIZER( model_skeleton_t );

		schema_add_offset( CUtlVector<const char*>, get_bone_names, 0x4 );
		schema_add_offset( CUtlVector<std::uint16_t>, get_parent_bone, 0x18 );
		schema_add_offset( CUtlVector<float>, get_bone_sphere, 0x30 );
		schema_add_offset( CUtlVector<std::uint32_t>, bone_flag, 0x48 );
		schema_add_offset( CUtlVector<evo::vec3_t>, get_parent_bone_position, 0x60 );
		schema_add_offset( CUtlVector<evo::QuaternionAligned_t>, get_parent_bone_rotation, 0x78 );
		schema_add_offset( CUtlVector<float>, get_parent_bone_scale, 0x90 );
	};

	class skeleton_bone_bounds_t {
	public:
		evo::vec3_t m_center; 
		evo::vec3_t m_size;
	};

	class render_skeleton_bone_t {
	public:
		CS_CLASS_NO_INITIALIZER( render_skeleton_bone_t );

		schema_add_offset( const char, m_bone_name, 0x0 );
		schema_add_offset( const char, m_parent_name, 0x8 );
		schema_add_offset( skeleton_bone_bounds_t, m_bbox, 0x40 );
		schema_add_offset( float, m_sphere_radius, 0x58 );
	};

	class render_skeleton_t {
	public:
		CS_CLASS_NO_INITIALIZER( render_skeleton_t );

		schema_add_offset( CUtlVector<render_skeleton_bone_t>, m_bones, 0x0 );
		schema_add_offset( CUtlVector<int32_t>, m_parent_bones, 0xB8);
		schema_add_offset( int32_t, m_bone_weight_count, 0x48 );
	};

	class render_mest_t {
	public:
		CS_CLASS_NO_INITIALIZER( render_mest_t );

		schema_add_offset( render_skeleton_t, m_skeleton, 0xB8 );
	};

	class model_t {
	public:
		CS_CLASS_NO_INITIALIZER( model_t );

		schema_add_offset( const char*, m_name, 0x8);
		schema_add_offset( model_skeleton_t, m_skeleton, 0x188 );
		schema_add_offset( CUtlVector<CStrongHandle<render_mest_t>>, m_meshes, 0x78 );

		// functions
		__forceinline uint32_t get_hitboxes_num( ) {
			using fn_hit = uint32_t( CS_FASTCALL* )( void* );
			static auto hitbox_num = reinterpret_cast< fn_hit >(
				memory::find_pattern( L"client.dll", CS_XOR( "E8 ? ? ? ? 8D 48 1F" ) ) );
			CS_ASSERT( hitbox_num != nullptr );

			return hitbox_num( this );
		}

		__forceinline uint32_t get_hitbox_flags( uint32_t index ) {
			using fn_hit = uint32_t( CS_FASTCALL* )( void*, uint32_t );
			static auto hitbox_flag = reinterpret_cast< fn_hit >( memory::find_pattern( L"client.dll", CS_XOR( "85 D2 78 16 3B 91" ) ) );
			CS_ASSERT( hitbox_flag != nullptr );

			return hitbox_flag( this, index );
		}

		__forceinline const char* get_hitbox_name( uint32_t index ) {
			using hitbox_name_fn = const char* ( CS_FASTCALL* )( void*, uint32_t );
			static auto hitbox_name = reinterpret_cast< hitbox_name_fn >( memory::find_pattern( L"client.dll", CS_XOR( "85 D2 78 25 3B 91" ) ) );
			CS_ASSERT( hitbox_name != nullptr );

			return hitbox_name( this, index );
		}

		__forceinline uint32_t get_hitbox_parent( uint32_t index ) {
			using hit_parent_fn = uint32_t( CS_FASTCALL* )( void*, uint32_t );
			static auto hitbox_parent = reinterpret_cast< hit_parent_fn >( memory::find_pattern( L"client.dll", CS_XOR( "85 D2 78 17 3B 91 70" ) ) );
			CS_ASSERT( hitbox_parent != nullptr );

			return hitbox_parent( this, index );
		}
	};
	
	enum bone_flags : uint32_t {
		FLAG_NO_BONE_FLAGS = 0x0,
		FLAG_BONEFLEXDRIVER = 0x4,
		FLAG_CLOTH = 0x8,
		FLAG_PHYSICS = 0x10,
		FLAG_ATTACHMENT = 0x20,
		FLAG_ANIMATION = 0x40,
		FLAG_MESH = 0x80,
		FLAG_HITBOX = 0x100,
		FLAG_BONE_USED_BY_VERTEX_LOD0 = 0x400,
		FLAG_BONE_USED_BY_VERTEX_LOD1 = 0x800,
		FLAG_BONE_USED_BY_VERTEX_LOD2 = 0x1000,
		FLAG_BONE_USED_BY_VERTEX_LOD3 = 0x2000,
		FLAG_BONE_USED_BY_VERTEX_LOD4 = 0x4000,
		FLAG_BONE_USED_BY_VERTEX_LOD5 = 0x8000,
		FLAG_BONE_USED_BY_VERTEX_LOD6 = 0x10000,
		FLAG_BONE_USED_BY_VERTEX_LOD7 = 0x20000,
		FLAG_BONE_MERGE_READ = 0x40000,
		FLAG_BONE_MERGE_WRITE = 0x80000,
		FLAG_ALL_BONE_FLAGS = 0xfffff,
		BLEND_PREALIGNED = 0x100000,
		FLAG_RIGIDLENGTH = 0x200000,
		FLAG_PROCEDURAL = 0x400000,
	};

	class model_state_t {
	public:
		CS_CLASS_NO_INITIALIZER( model_state_t );

		schema_add_field( CStrongHandle<model_t>, m_hmodel, "CModelState->m_hModel" );
		schema_add_offset( evo::c_transform*, bone_transform, 0x80 );

		bone_data_t* get_hitbox_data( ) noexcept {
			bone_data_t* data_ptr = *reinterpret_cast< bone_data_t** >( this + 0x80 );

			if ( data_ptr == nullptr )
				data_ptr = *reinterpret_cast< bone_data_t** >( reinterpret_cast< uintptr_t >( this ) + 0x80 );

			CS_ASSERT( data_ptr != nullptr );

			return data_ptr;
		}

		evo::vec3_t GetHitboxPos( uint32_t index ) {
			auto hitbox = this->get_hitbox_data( );
			if ( !hitbox )
				return evo::vec3_t{};

			if ( !( this->m_hmodel( )->get_hitbox_flags( index ) & bone_flags::FLAG_HITBOX ) )
				return evo::vec3_t{};

			auto parent_index = this->m_hmodel( )->get_hitbox_parent( index );
			if ( parent_index == -1 )
				return evo::vec3_t{};

			return hitbox[ index ].pos;
		}

		evo::vec4_t GetHitboxRotation( uint32_t index ) {
			auto hitbox = this->get_hitbox_data( );
			if ( !hitbox )
				return 0;

			if ( !( this->m_hmodel( )->get_hitbox_flags( index ) & bone_flags::FLAG_HITBOX ) )
				return 0;

			auto parent_index = this->m_hmodel( )->get_hitbox_parent( index );
			if ( parent_index == -1 )
				return 0;

			return hitbox[ index ].rot;
		}

		const char* GetHitboxName( uint32_t index ) {
			auto hitbox = this->get_hitbox_data( );
			if ( !hitbox )
				return nullptr;

			if ( !( this->m_hmodel( )->get_hitbox_flags( index ) & bone_flags::FLAG_HITBOX ) )
				return nullptr;

			auto parent_index = this->m_hmodel( )->get_hitbox_parent( index );
			if ( parent_index == -1 )
				return nullptr;

			return this->m_hmodel( )->get_hitbox_name( index );
		}
	};

	class skeleton_instance_t {
	public:
		CS_CLASS_NO_INITIALIZER( skeleton_instance_t );

		schema_add_field( model_state_t, get_model, "CSkeletonInstance->m_modelState" );
		schema_add_field( bool, is_animation_enabled, "CSkeletonInstance->m_bIsAnimationEnabled" );
		schema_add_field( bool, use_parent_bounds, "CSkeletonInstance->m_bUseParentRenderBounds" );
		schema_add_field( bool, disable_collisions_for_hieranchy, "CSkeletonInstance->m_bDisableSolidCollisionsForHierarchy" );
		schema_add_field( bool, dirty_motion_type, "CSkeletonInstance->m_bDirtyMotionType" );
		schema_add_field( bool, is_generating_parent_space, "CSkeletonInstance->m_bIsGeneratingLatchedParentSpaceState" );
		schema_add_field( uint8_t, get_hitbox_set, "CSkeletonInstance->m_nHitboxSet" );

		__forceinline void get_bone_data( bone_data_t& data, int index ) {
			// -1 / ; #STR: "gpGlocals->rendertime() called while IsInSimulation()
			using function_bone_data = void( __fastcall* )( void*, bone_data_t&, int index );
			static auto bone_data = reinterpret_cast< function_bone_data >( 
				memory::find_pattern( L"client.dll", CS_XOR( "E8 ? ? ? ? EB 19 48 8B CF" ) ) );

			// assert.
			CS_ASSERT( bone_data != nullptr );

			// return data.
			return bone_data( this, data, index );
		}

		__forceinline void __fastcall calc_world_space_bones( uint32_t parent, uint32_t mask ) {
			// what?: E8 ? ? ? ? 4C 8B AF ? ? ? ?
			// ida.
			// #STR: "Bone merge bones from parent were invalid: parent model '%,
			using functon_new_calc_bones = void( __fastcall )( void*, uint32_t );
			static auto bone_new = reinterpret_cast< functon_new_calc_bones* >( 
				memory::find_pattern( L"client.dll", CS_XOR( "40 55 56 57 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 48 8D 6C 24 ? 48 8B F1" ) ) );

			// assert.
			CS_ASSERT( bone_new != nullptr );

			// return data.
			return bone_new( this, mask );
		}
	};

	// main.
	class game_scene_node_t {
	public:
		CS_CLASS_NO_INITIALIZER( game_scene_node_t );

		schema_add_field( evo::c_transform, node_to_world, "CGameSceneNode->m_nodeToWorld" );
		schema_add_field( evo::vec3_t, get_vec_origin, "CGameSceneNode->m_vecOrigin" );
		schema_add_field( evo::vec3_t, get_abs_origin, "CGameSceneNode->m_vecAbsOrigin" );

		// skeleton instance
		skeleton_instance_t* get_skeleton_instance( ) {
			return memory::call_function<skeleton_instance_t*, 8U>( this );
		}
	};
}