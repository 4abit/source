#pragma once

namespace ams {
	// macros.
	using game_time_t = std::int32_t;
	using game_tick_t = std::int32_t;

	// preclass.
	class entity_instance_t;
	class entity_indentity_t {
	public:
		// no initializer.
		// delete initializers to prevent using them
		CS_CLASS_NO_INITIALIZER( entity_indentity_t );

		// schema.
		schema_add_offset( std::uint32_t, get_index, 0x10 );
		schema_add_field( const char*, get_designer_name, "CEntityIdentity->m_designerName" );
		schema_add_field( std::uint32_t, get_flags, "CEntityIdentity->m_flags" );

		// functions.
		[[nodiscard]] bool is_valid( ) {
			return get_index( ) != INVALID_EHANDLE_INDEX;
		}

		[[nodiscard]] int get_entry_index( ) {
			if ( !is_valid( ) )
				return ENT_ENTRY_MASK;

			return get_index( ) & ENT_ENTRY_MASK;
		}

		[[nodiscard]] int get_serial_numbers( ) {
			return get_index( ) >> NUM_SERIAL_NUM_SHIFT_BITS;
		}

		// instance.
		entity_instance_t* m_instance;
	};
}