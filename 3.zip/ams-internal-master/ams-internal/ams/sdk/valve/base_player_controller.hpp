#pragma once

namespace ams {
	class base_player_controller_t : public base_model_entity_t {
	public:
		CS_CLASS_NO_INITIALIZER( base_player_controller_t );

		schema_add_field( CBaseHandle, get_pawn_handle, "CBasePlayerController->m_hPawn" );
	};
}