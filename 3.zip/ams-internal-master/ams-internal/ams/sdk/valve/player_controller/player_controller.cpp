#include "../../../includes.hpp"

ams::player_controller_t* ams::player_controller_t::get_local_controller( ) {
	const int m_index = ams::engine->get_local_player( );
	return ams::resource_services->m_game_entity_system->construct< ams::player_controller_t>( m_index );
}
