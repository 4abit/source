#pragma once

namespace ams {
	class money_services_t {
	public:
		CS_CLASS_NO_INITIALIZER( money_services_t );

		// should work.
		schema_add_field( int, get_account, "CCSPlayerController_InGameMoneyServices->m_iAccount" );

	};

	class player_controller_t : public base_player_controller_t {
	public:
		CS_CLASS_NO_INITIALIZER( player_controller_t );

		// get lp controller.
		[[nodiscard]] static player_controller_t* get_local_controller( );

		// pawn handle.
		schema_add_field( CBaseHandle, get_player_pawn_handle, "CCSPlayerController->m_hPlayerPawn" );
		schema_add_field( bool, alive_pawn, "CCSPlayerController->m_bPawnIsAlive" );
		schema_add_field( const char*, get_player_name, "CCSPlayerController->m_sSanitizedPlayerName" );

		schema_add_field( money_services_t*, money_services, "CCSPlayerController->m_pInGameMoneyServices" );
	};
}