#pragma once
#include "valve.hpp" // i had to do it boss

namespace ams {
	// preclass.
	class glow_property_t;

	// main.
	class base_model_entity_t : public base_entity_t {
	public:
		CS_CLASS_NO_INITIALIZER( base_model_entity_t );

		// glow property
		schema_add_field( glow_property_t, glow_entry, "C_BaseModelEntity->m_Glow" );
		schema_add_field( evo::vec3_t, get_view_offset, "C_BaseModelEntity->m_vecViewOffset" );

		evo::vec3_t get_eye_pos( ) noexcept {
			const auto game_scene_node = scene_node( );
			// ASSERT_MSG(game_scene_node, "game_scene_node null in base_model_entity::get_eye_pos");

			// this should work igs
			return game_scene_node->get_vec_origin( ) + get_view_offset( );
		}
	};

	class glow_property_t : public base_model_entity_t {
	public:
		schema_add_field( bool, glowing, "CGlowProperty->m_bGlowing" );
		schema_add_field( int, glow_type, "CGlowProperty->m_iGlowType" );
		schema_add_field( int, glow_range, "CGlowProperty->m_nGlowRange" );
		schema_add_field( evo::col_t, glow_color_override, "CGlowProperty->m_glowColorOverride" );
	};
}