#pragma once
#include "../weapon/weapon.hpp"

namespace ams {
	class player_pawn_t : public player_pawn_base_t {
	public:
		CS_CLASS_NO_INITIALIZER( player_pawn_t );

		[[nodiscard]] bool enemy( player_pawn_t* m_other );
		[[nodiscard]] int associated_team( );

	};
}