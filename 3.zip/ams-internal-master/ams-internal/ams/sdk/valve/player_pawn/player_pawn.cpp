#include "../../../includes.hpp"

bool ams::player_pawn_t::enemy( player_pawn_t* m_other ) {
	if ( m_other == nullptr || this == m_other )
		return false;

	return this->associated_team( ) != m_other->associated_team( );
}

int ams::player_pawn_t::associated_team( ) {
	const int m_team = this->get_team( );
	return m_team;
}
