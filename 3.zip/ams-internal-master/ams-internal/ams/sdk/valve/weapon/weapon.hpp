#pragma once

namespace ams {
    enum CS2_ID {
        NONE = 0,
        DEAGLE = 1,
        ELITE = 2,
        FIVESEVEN = 3,
        GLOCK = 4,
        AK47 = 7,
        AUG = 8,
        AWP = 9,
        FAMAS = 10,
        G3SG1 = 11,
        GALILAR = 13,
        M249 = 14,
        M4A1 = 16,
        MAC10 = 17,
        P90 = 19,
        MP5SD = 23,
        UMP45 = 24,
        XM1014 = 25,
        BIZON = 26,
        MAG7 = 27,
        NEGEV = 28,
        SAWEDOFF = 29,
        TEC9 = 30,
        TASER = 31,
        HKP2000 = 32,
        MP7 = 33,
        MP9 = 34,
        NOVA = 35,
        P250 = 36,
        SHIELD = 37,
        SCAR20 = 38,
        SG556 = 39,
        SSG08 = 40,
        KNIFEGG = 41,
        KNIFE = 42,
        FLASHBANG = 43,
        HEGRENADE = 44,
        SMOKEGRENADE = 45,
        MOLOTOV = 46,
        DECOY = 47,
        INCGRENADE = 48,
        C4 = 49,
        HEALTHSHOT = 57,
        KNIFE_T = 59,
        M4A1_SILENCER = 60,
        USP_SILENCER = 61,
        CZ75A = 63,
        REVOLVER = 64,
        TAGRENADE = 68,
        FISTS = 69,
        BREACHCHARGE = 70,
        TABLET = 72,
        MELEE = 74,
        AXE = 75,
        HAMMER = 76,
        SPANNER = 78,
        KNIFE_GHOST = 80,
        FIREBOMB = 81,
        DIVERSION = 82,
        FRAG_GRENADE = 83,
        SNOWBALL = 84,
        BUMPMINE = 85,
        BAYONET = 500,
        KNIFE_CSS = 503,
        KNIFE_FLIP = 505,
        KNIFE_GUT = 506,
        KNIFE_KARAMBIT = 507,
        KNIFE_M9_BAYONET = 508,
        KNIFE_TACTICAL = 509,
        KNIFE_FALCHION = 512,
        KNIFE_SURVIVAL_BOWIE = 514,
        KNIFE_BUTTERFLY = 515,
        KNIFE_PUSH = 516,
        KNIFE_CORD = 517,
        KNIFE_CANIS = 518,
        KNIFE_URSUS = 519,
        KNIFE_GYPSY_JACKKNIFE = 520,
        KNIFE_OUTDOOR = 521,
        KNIFE_STILETTO = 522,
        KNIFE_WIDOWMAKER = 523,
        KNIFE_SKELETON = 525,
        STUDDED_BLOODHOUND_GLOVES = 5027,
        T_GLOVES = 5028,
        CT_GLOVES = 5029,
        SPORTY_GLOVES = 5030,
        SLICK_GLOVES = 5031,
        LEATHER_HANDWRAPS = 5032,
        MOTORCYCLE_GLOVES = 5033,
        SPECIALIST_GLOVES = 5034,
        STUDDED_HYDRA_GLOVES = 5035
    };

    enum weapon_type_t : std::uint32_t {
        weapon_type_knife = 0,
        weapon_type_pistol = 1,
        weapon_type_submachinegun = 2,
        weapon_type_rifle = 3,
        weapon_type_shotgun = 4,
        weapon_type_sniper_rifle = 5,
        weapon_type_machinegun = 6,
        weapon_type_c4 = 7,
        weapon_type_taser = 8,
        weapon_type_grenade = 9,
        weapon_type_equipment = 10,
        weapon_type_stackable_item = 11,
        weapon_type_fists = 12,
        weapon_type_breach_charge = 13,
        weapon_type_bump_mine = 14,
        weapon_type_tablet = 15,
        weapon_type_melee = 16,
        weapon_type_shield = 17,
        weapon_type_zone_repulsor = 18,
        weapon_type_unknown = 19,
    };

	class weapon_data_t {
	public:
		CS_CLASS_NO_INITIALIZER( weapon_data_t );

        schema_add_field( bool, is_revolver, "CCSWeaponBaseVData->m_bIsRevolver" );
        schema_add_field( weapon_type_t, weapon_type, "CCSWeaponBaseVData->m_WeaponType" );
        schema_add_field( bool, max_clip, "CBasePlayerWeaponVData->m_iMaxClip1" );
        schema_add_field( float, headshot_multiplier, "CCSWeaponBaseVData->m_flHeadshotMultiplier" );
        schema_add_field( int, damage, "CCSWeaponBaseVData->m_nDamage" );
        schema_add_field( float, armor_ratio, "CCSWeaponBaseVData->m_flArmorRatio" );
        schema_add_field( float, fl_penetration, "CCSWeaponBaseVData->m_flPenetration" );
        schema_add_field( float, fl_range, "CCSWeaponBaseVData->m_flRange" );
        schema_add_field( float, fl_range_modifier, "CCSWeaponBaseVData->m_flRangeModifier" );
	};

    class econ_item_t {
    public:
        CS_CLASS_NO_INITIALIZER( econ_item_t );

        // C_EconItemView->m_iItemDefinitionIndex
        schema_add_field( int, item_definition_index, "C_EconItemView->m_iItemDefinitionIndex" );
    };

    class attribute_container_t {
    public:
        CS_CLASS_NO_INITIALIZER( attribute_container_t );

        schema_add_field( econ_item_t, econ_item, "C_AttributeContainer->m_Item" );
    };

	class weapon_base_t {
	public:
		CS_CLASS_NO_INITIALIZER( weapon_base_t );

		// fields
        schema_add_field( int, get_clip, "C_BasePlayerWeapon->m_iClip1" );
        schema_add_field( float, next_primary_attack_tick, "C_BasePlayerWeapon->m_nNextPrimaryAttackTick" );
        schema_add_field( float, next_primary_attack_ratio, "C_BasePlayerWeapon->m_flNextPrimaryAttackTickRatio" );

        // econ entity. // or attribute_container_t*
        schema_add_field( attribute_container_t, attribute_manager, "C_EconEntity->m_AttributeManager" );

		// access weapon data
		weapon_data_t* get_weapon_data( ) { // weapon_v_data
			// ida: 48 8B 81 ? ? ? ? 48 8B 88 ? ? ? ? 48 8D 05 ? ? ? ? 48 85 C9 48 0F 45 C1 C3 CC CC CC 49 8B C8 + 0x3
			// 48 8B 81 ? ? ? ? 8B 80 ? ? ? ? C3 CC CC 66 89 54 24 ? - directly

			static auto offset = *reinterpret_cast< int* >( memory::find_pattern( L"client.dll", "48 8B 81 ? ? ? ? 85 D2 78 ? 48 83 FA ? 73 ? F3 0F 10 84 90 ? ? ? ? C3 F3 0F 10 80 ? ? ? ? C3 CC CC CC CC" ) + 0x3 );
			return *reinterpret_cast< weapon_data_t** >( ( uintptr_t )this + offset );
		}

		std::string get_weapon_name( ) {
			// ida: weapon_data - 0x3
			// 48 8B 81 ? ? ? ? 48 8B 88 ? ? ? ? 48 8D 05 ? ? ? ? 48 85 C9 48 0F 45 C1 C3 CC CC CC 49 8B C8

			static auto get_name = reinterpret_cast< const char* ( __fastcall* )( weapon_base_t* ) >( memory::find_pattern(
				L"client.dll", "48 8B 81 ? ? ? ? 48 8B 88 ? ? ? ? 48 8D 05 ? ? ? ? 48 85 C9 48 0F 45 C1 C3 CC CC CC 44 0F B6 41 ?" ) );

			return get_name( this );
		}

        __forceinline float get_spread( ) {
            using original_fn = float( __fastcall* )( void* );
            return ( *( original_fn** )this )[ 349 ]( this );
        }

        __forceinline float get_inaccuracy( ) {
            using original_fn = float( __fastcall* )( void* );
            return ( *( original_fn** )this )[ 399 ]( this );
        }

        // for reference.    
// sv_accelerate_use_weapon_speed inside "CGameMovement::Accelerate"
// 48 8B C4 F3 0F 11 50 ? 41 55 41 56 41 57 48 81 EC ? ? ? ? F2 41 0F 10 21 4D 8B E9 F2 0F 10 5A ? 0F 28 C4 44 0F 29 40 ? 0F 28 CB F3 44 0F 10 42 ? 4C 8B FA F3 45 0F 59 41 ? 
// mov     rcx, rbx
// call    qword ptr [ rax + 0AF8h ] <- index
// mov     rax, [ rbx ]
        __forceinline float get_max_speed( ) {
            using original_fn = float( __fastcall* )( void* );
            return ( *( original_fn** )this )[ 340 ]( this );
        }
	};

}