#pragma once
#include "entity_identity.hpp"
#include "entity_instance.hpp"
#include "collision_property.hpp"
#include "game_scene_node.hpp"
#include "c_base_entity/base_entity.hpp"
#include "base_model_entity.hpp"
#include "base_player_pawn.hpp"
#include "player_pawn_base.hpp"
#include "player_pawn/player_pawn.hpp"
#include "base_player_controller.hpp"
#include "player_controller/player_controller.hpp"
#include "weapon/weapon.hpp"

namespace ams {
	struct c_player_move_data {
		int n00000_d23;                 //0x0000
		char pad_0004[ 4 ];               //0x0004
		evo::vec3_t ang_aim_angle;         //0x0008
		evo::vec3_t ang_aim_angle2;        //0x0014
		float fl_forward_move;          //0x0020
		float fl_left_move;             //0x0024
		float fl_up_move;               //0x0028
		evo::vec3_t vec_move;              //0x002C
		char pad_0038[ 4 ];               //0x0038
		evo::vec3_t vec_velocity;          //0x003C
		evo::vec3_t ang_shot_angle;        //0x0048
		char pad_0054[ 28 ];              //0x0054
		bool b_should_jump;             //0x0070
		char pad_0071[ 55 ];              //0x0071
		evo::vec3_t vec_origin;            //0x00A8
	};
}