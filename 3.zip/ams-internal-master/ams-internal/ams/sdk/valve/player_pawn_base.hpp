#pragma once

namespace ams {
	class player_pawn_base_t : public base_player_pawn_t {
	public:
		CS_CLASS_NO_INITIALIZER( player_pawn_base_t );
	};
}