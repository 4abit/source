#pragma once
#pragma warning ( disable : 4005 )
#pragma warning ( disable : 26495 )
#pragma warning ( disable : 4244 )
#pragma warning ( disable : 4715 )
#pragma warning ( disable : 4018 )
#pragma warning ( disable : 4244 )
#pragma warning ( disable : 4267 )

#include <windows.h>
#include <windowsx.h>
#include <memory>
#include <sstream>
#include <iostream>
#include <functional>
#include <WinUser.h>
#include <string_view>
#include <map>
#include <cmath>
#include <algorithm>
#include <chrono>
#include <deque>
#include <mutex>
#include <optional>
#include <filesystem>
#include <fstream>
#include <random>
#include <array>
#include <mutex>

// dx includes.
#include <d3d11.h>
#include <D3D11.h>

#include <d3d9.h>
#include <d3dx9.h>

#pragma comment(lib, "legacy_stdio_definitions.lib")
#pragma comment(lib, "freetype.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

// libs dx.
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "D3D11.lib")

#include "thirdparty/imgui/imgui.h"
#include "thirdparty/imgui/imgui_freetype.h"
#include "thirdparty/imgui/imgui_impl_win32.h"
#include "thirdparty/imgui/imgui_impl_dx9.h"
#include "thirdparty/imgui/imgui_impl_dx11.h"

// drawlist.
#define ext_draw_list ImGui::GetBackgroundDrawList( )

// macros.
#define share_class( a, b ) inline const auto a = std::make_unique< b >();
#define reinterpret_(a, b) reinterpret_cast< a >( b )
#define str_(s) std::to_string(s)
#define log_error(s) std::cout << "[ams-error] " << std::string(s) << std::endl;
#define log_success(s) std::cout << "[ams] " << std::string(s) << std::endl;
#define log_warning(s) std::cout << "[ams-warning] " << std::string(s) << std::endl;

#include "evo-sdk/input_system/input_system.hpp"
#include "evo-sdk/sdk/sdk.hpp"
#include "evo-sdk/render/render_system.hpp"
#include "evo-sdk/keybind_states/sk.hpp"
#include "evo-sdk/animation_system/animation_system.hpp"
#include "evo-sdk/input_system/input_system.hpp"

#include "ui/container/container.hpp"
#include "ui/menu/menu.hpp"

// other includes.
#include "utils/other/utlhash.hpp"
#include "utils/memory/memory.hpp"
#include "interfaces/interfaces.hpp"
#include "interfaces/schema_system/schema_system.hpp"
#include "sdk/valve/valve.hpp"
#include "evo-sdk/config_system/cfg.hpp"

// resources.
#define IDS_APP_TITLE 103
#define IDR_MAINFRAME 128
#define IDD_GUITEST_DIALOG 102
#define IDD_ABOUTBOX 103
#define IDM_ABOUT 104
#define IDM_EXIT 105
#define IDI_GUITEST 107
#define IDI_SMALL 108
#define IDC_GUITEST 109
#define IDC_MYICON 2
#ifndef IDC_STATIC
#define IDC_STATIC -1
#endif

#pragma warning ( disable : 4005 )
#pragma warning ( disable : 26495 )
#pragma warning ( disable : 4244 )
#pragma warning ( disable : 4715 )
#pragma warning ( disable : 4018 )
#pragma warning ( disable : 4244 )
#pragma warning ( disable : 4267 )