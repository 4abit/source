#include "../../includes.hpp"

bool ams::cfg_t::save( std::string config_name ) {
	CreateDirectory( "C:\\amnesia_cs2", NULL );
	std::string file_path = "C:\\amnesia_cs2\\" + config_name + ".cfg";

	std::fstream file( file_path, std::ios::out | std::ios::in | std::ios::trunc );
	file.close( );

	file.open( file_path, std::ios::out | std::ios::in );
	if ( !file.is_open( ) ) {
		file.close( );
		return false;
	}

	const size_t settings_size = sizeof( cfg_t );
	for ( int i = 0; i < settings_size; i++ ) {
		byte current_byte = *reinterpret_cast< byte* >( uintptr_t( this ) + i );
		for ( int x = 0; x < 8; x++ ) {
			file << ( int )( ( current_byte >> x ) & 1 );
		}
	}

	file.close( );

	log_success( ( "saved config: " + config_name ) );

	return true;
}

void ams::cfg_t::load( int slot ) {

	std::string file_path = "C:\\amnesia_cs2\\" + _extern_cfg->files_cfg[ slot ] + ".cfg";

	std::fstream file;
	file.open( file_path, std::ios::out | std::ios::in );
	if ( !file.is_open( ) ) {
		file.close( );
		return;
	}

	std::string line;
	while ( file ) {
		std::getline( file, line );

		const size_t settings_size = sizeof( cfg_t );
		if ( line.size( ) > settings_size * 8 ) {
			file.close( );
			return;
		}
		for ( int i = 0; i < settings_size; i++ ) {
			byte current_byte = *reinterpret_cast< byte* >( uintptr_t( this ) + i );
			for ( int x = 0; x < 8; x++ ) {
				if ( line[ ( i * 8 ) + x ] == '1' )
					current_byte |= 1 << x;
				else
					current_byte &= ~( 1 << x );
			}
			*reinterpret_cast< byte* >( uintptr_t( this ) + i ) = current_byte;
		}
	}

	file.close( );

	/* store */
	_extern_cfg->loaded_cfg = true;

	/* log */
	log_success( ( "loaded config: " + _extern_cfg->files_cfg[ slot ] ) );

	return;
}

void ams::cfg_t::remove( int slot ) {
	std::string file_path = "C:\\amnesia_cs2\\" + _extern_cfg->files_cfg[ slot ] + ".cfg";

	// attempt to open the file for removal.
	std::fstream file( file_path, std::ios::in );
	if ( !file.is_open( ) ) {
		// file doesn't exist, or cannot be opened for removal.
		return;
	}

	// close the file.
	file.close( );

	// remove the file.
	if ( std::remove( file_path.c_str( ) ) != 0 ) {
		// error occurred while removing the file.
		return;
	}

	log_success( ( "removed config: " + _extern_cfg->files_cfg[ slot ] ) );
}

void ams::cfg_t::get_configs( ) {
	WIN32_FIND_DATA ffd;
	auto directory = "C:\\amnesia_cs2\\*";
	auto hFind = FindFirstFile( directory, &ffd );

	_extern_cfg->files_cfg.clear( );

	while ( FindNextFile( hFind, &ffd ) ) {
		if ( !( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) ) {
			std::string file_name = ffd.cFileName;
			if ( file_name.size( ) < 4 ) // .cfg
				continue;

			std::string end = file_name;
			end.erase( end.begin( ), end.end( ) - 4 ); // erase everything but the last 4 letters
			if ( end != ".cfg" )
				continue;

			file_name.erase( file_name.end( ) - 4, file_name.end( ) ); // erase the .cfg part
			_extern_cfg->files_cfg.push_back( file_name );
		}
	}

	log_success( ( "configs refreshed" ) );
}

void ams::cfg_t::pre_load_cfg_items( ) {
	
}

bool ams::cfg_t::create_config( std::string config_name ) {
	std::string file_path = "C:\\amnesia_cs2\\" + config_name + ".cfg";

	std::fstream file( file_path, std::ios::out | std::ios::in | std::ios::trunc );
	file.close( );

	file.open( file_path, std::ios::out | std::ios::in );
	if ( !file.is_open( ) ) {
		file.close( );
		return false;
	}
	file.close( );

	log_success( ( "created config: " + config_name ) );

	return true;
}
