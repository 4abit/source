#pragma once
#include "../../evo-sdk/keybind_states/sk.hpp"

enum bind_elem {
	esp_activation,
	grenade_assistant
};

enum int_features {
	health_shadow,
	ammo_shadow,
	health_color_style,
	ammo_color_style,
	material_type,
	rage_hitchance,
	rage_minimumdamage,
	rage_minimumdamage_wall,
	rage_minimumdamage_override,
};

enum keybind_features {
	damage_override,
};

enum float_features {
	nightmode_value,
	watermark_x,
	watermark_y,
};

enum bool_features {
	bounding_box,
	name_esp,
	health_esp,
	custom_health,
	health_enab_shadow,
	ammo_esp,
	ammo_en_shadow,
	weapon_name,
	weapon_icon,
	money_flag,
	deuser_flag,
	armor_flag,
	distance_flag,
	scoped_flag,
	enemy_chams,
	enemy_xyz_chams,
	skeleton_esp,
	headhitbox,
	neckhitbox,
	pelvishitbox,
	armshitbox,
	legshitbox,
	foothitbox,
	spinehitbox,
	ragebot,
	nightmode,
	reveal_money,
	force_visible_damage_global,
	watermark,
	indicators,
	knifebot,
	autostoprage,
};

enum color_featues {
	bounding_box_color,
	name_color,
	health_color,
	health_color2,
	ammo_color,
	ammo_color2,
	weapon_color,
	weapon_color2,
	chams_color_vis,
	chams_color_invis,
	skeleton_color
};

namespace ams {
	class extern_t {
	public:
		std::vector<std::string> files_cfg;
		evo::vec2_t watermark_pos{};
		evo::vec2_t keybinds_pos{};
		evo::vec2_t spec_pos{};
		evo::vec2_t bomb_pos{};
		evo::vec2_t local_info_pos{};
		evo::vec2_t enemy_info_pos{};

		bool loaded_cfg;
	};
	inline const auto _extern_cfg = std::make_unique< extern_t >( );

	class cfg_t {
	public:
		bool save( std::string config_name );
		void load( int slot );
		void remove( int slot );
		void get_configs( );
		void pre_load_cfg_items( );

		bool create_config( std::string config_name );

		int int_elem[ 256 ]{};
		float float_elem[ 256 ]{};
		bool bool_elem[ 256 ]{};
		int keybind_elem[2][ 256 ]{};

		// for color.
		evo::col_t color_elem[ 256 ]{ evo::col_t() };
		float color_hue_elem[ 256 ]{};
	};
	inline const auto _cfg = std::make_unique< cfg_t >( );

	namespace shared {
		__forceinline bool active( int feature ) {
			static bool smth{};
			return evo::utils::key_method( _cfg->keybind_elem[ 0 ][ feature ], _cfg->keybind_elem[ 1 ][ feature ], smth );
		}
	}
}