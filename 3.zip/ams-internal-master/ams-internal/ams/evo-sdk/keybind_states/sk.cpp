#include "../../includes.hpp"

void evo::utils::init_input( ) { 
	for ( int i = 0; i < 256; i++ ) {
		m_bPrevKeyState[ i ] = m_bKeyState[ i ];
		m_bKeyState[ i ] = GetAsyncKeyState( i );
	}

	POINT vMousePos;
	GetCursorPos( &vMousePos );
	ScreenToClient( FindWindow( nullptr, "Counter-Strike 2" ), &vMousePos );

	m_vPrevMousePos = m_vMousePos;
	m_vMousePos = { ( float )vMousePos.x, ( float )vMousePos.y };

	if ( !m_bInputLoopStarted )
		m_bInputLoopStarted = true;
}

bool evo::utils::key_method( const int iKey, const int iMethod, bool old_method ) {
	switch ( iMethod ) {
		case 0: // Always on
			return true;
			break;
		case 1: // Hold
			return GetAsyncKeyState( iKey );
			break;
		case 2: // Toggle
		{
			if ( old_method ) {
				static bool toggle;

				if ( key_pressed( iKey ) )
					toggle = !toggle;

				return toggle;
			} else {
				return GetKeyState( iKey );
			}
		}
		break;
		case 3: // Force off
			return !key_down( iKey );
			break;
	}
	return false;
}

bool evo::utils::key_pressed( const int iKey ) {
	return m_bKeyState[ iKey ] && !m_bPrevKeyState[ iKey ];
}

bool evo::utils::key_down( const int iKey ) {
	return m_bKeyState[ iKey ];
}

bool evo::utils::key_released( const int iKey ) {
	return !m_bKeyState[ iKey ] && m_bPrevKeyState[ iKey ];
}
