#pragma once

namespace evo {
	namespace utils {
		void init_input( );

		bool key_method( const int iKey, const int iMethod, bool old_method = false );
		bool key_pressed( const int iKey );
		bool key_down( const int iKey );
		bool key_released( const int iKey );

		inline bool m_bKeyState[ 256 ];
		inline bool m_bPrevKeyState[ 256 ];
		inline bool m_bInputLoopStarted = false;

		inline vec2_t m_vPrevMousePos, m_vMousePos;
	}
}