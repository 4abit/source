#pragma once
#include <d3d9types.h>

namespace evo { /* main namespace */
	namespace macros {
		/* render macros */
		using vec_t = ImVec2;
		using vec4_t = ImVec4;
		using u32_t = ImU32;
		using texture_id = ImTextureID;
	}

	namespace math {
		constexpr float pi = 3.1415926535897932384f; // pi
		constexpr float pi_2 = pi * 2.f;               // pi * 2

		__forceinline constexpr float deg_to_rad( float val ) {
			return val * ( pi / 180.f );
		}

		// radians to degrees.
		__forceinline constexpr float rad_to_deg( float val ) {
			return val * ( 180.f / pi );
		}
	}

	/* color shit */
	struct col_t {
		col_t( ) : r( 255 ), g( 255 ), b( 255 ), a( 255 ) { } /* default white */
		col_t( int r, int g, int b, int a = 255 ) : r( r ), g( g ), b( b ), a( a ) { }
		~col_t( ) { }

		typedef struct {
			double h;
			double s;
			double v;
		} hsv;

		typedef struct {
			double r;
			double g;
			double b;
		} rgb;

		col_t modify_alpha( int a ) {
			return col_t( r, g, b, a );
		}

		static float base( const unsigned char col ) {
			return col / 255.f;
		}

		std::uint32_t convert( ) {
			std::uint32_t out = 0;

			out = static_cast< std::uint32_t >( this->r ) << 0;
			out |= static_cast< std::uint32_t >( this->g ) << 8;
			out |= static_cast< std::uint32_t >( this->b ) << 16;
			out |= static_cast< std::uint32_t >( this->a ) << 24;

			return out;
		}

		__forceinline col_t hex_to_rgb( std::string hex_color ) {
			if ( hex_color[ 0 ] == '#' ) {
				hex_color.erase( 0, 1 );
			}

			std::stringstream ss;
			ss << std::hex << hex_color;
			unsigned int hex_value;
			ss >> hex_value;

			int red = ( hex_value >> 16 ) & 0xff;
			int green = ( hex_value >> 8 ) & 0xff;
			int blue = hex_value & 0xff;

			return col_t( red, green, blue );
		}

		static float hue( const col_t color ) {
			float R = base( color.r );
			float G = base( color.g );
			float B = base( color.b );
			float mx = max( R, max( G, B ) );
			float mn = min( R, min( G, B ) );

			if ( mx == mn )
				return 0.f;

			float delta = mx - mn;
			float hue = 0.f;

			if ( mx == R )
				hue = ( G - B ) / delta;

			else
				if ( mx == G )
					hue = 2.f + ( B - R ) / delta;

				else
					hue = 4.f + ( R - G ) / delta;

			hue *= 60.f;

			if ( hue < 0.f )
				hue += 360.f;

			return hue / 360.f;
		}

		static float saturation( const col_t color ) {
			float R = base( color.r );
			float G = base( color.g );
			float B = base( color.b );
			float mx = max( R, max( G, B ) );
			float mn = min( R, min( G, B ) );
			float delta = mx - mn;

			if ( mx == 0.f )
				return delta;

			return delta / mx;
		}

		static float brightness( const col_t color ) {
			float R = base( color.r );
			float G = base( color.g );
			float B = base( color.b );
			return max( R, max( G, B ) );
		}

		float hue( ) const {
			return hue( *this );
		}

		float saturation( ) const {
			return saturation( *this );
		}

		float brightness( ) const {
			return brightness( *this );
		}

		static col_t from_hsb( float hue /* 0.f - 1.f*/,
							   float saturation /* 0.f - 1.f */,
							   float brightness /* 0.f - 1.f */,
							   int alpha = 255 ) {
			hue = std::clamp( hue, 0.f, 1.f );
			saturation = std::clamp( saturation, 0.f, 1.f );
			brightness = std::clamp( brightness, 0.f, 1.f );
			float h = ( hue == 1.f ) ? 0.f : ( hue * 6.f );
			float f = h - static_cast< int >( h );
			float p = brightness * ( 1.f - saturation );
			float q = brightness * ( 1.f - saturation * f );
			float t = brightness * ( 1.f - ( saturation * ( 1.f - f ) ) );

			if ( h < 1.f )
				return col_t( brightness * 255, t * 255, p * 255, alpha );

			else
				if ( h < 2.f )
					return col_t( q * 255, brightness * 255, p * 255, alpha );

				else
					if ( h < 3.f )
						return col_t( p * 255, brightness * 255, t * 255, alpha );

					else
						if ( h < 4 )
							return col_t( p * 255, q * 255, brightness * 255, alpha );

						else
							if ( h < 5 )
								return col_t( t * 255, p * 255, brightness * 255, alpha );

							else
								return col_t( brightness * 255, p * 255, q * 255, alpha );
		}

		col_t blend( const col_t& other, float fraction ) const {
			int r_d = r - other.r;
			int g_d = g - other.g;
			int b_d = b - other.b;
			int a_d = a - other.a;

			int blended_r = r - ( r_d * fraction );
			int blended_g = g - ( g_d * fraction );
			int blended_b = b - ( b_d * fraction );
			int blended_a = a - ( a_d * fraction );

			return col_t{ blended_r, blended_g, blended_b, blended_a };
		}

		col_t darker( int amount ) {
			int red = r;
			int green = g;
			int blue = b;

			// reduce the RGB values by the given amount
			red = std::fmax( 0, red - amount );
			green = std::fmax( 0, green - amount );
			blue = std::fmax( 0, blue - amount );

			return col_t( red, green, blue, a );
		}

		static hsv rgb_to_hsv( int r, int g, int b ) {
			rgb in = { ( float )( r / 255 ), ( float )( g / 255 ) , ( float )( b / 255 ) };
			hsv         out;
			double      min, max, delta;

			min = in.r < in.g ? in.r : in.g;
			min = min < in.b ? min : in.b;

			max = in.r > in.g ? in.r : in.g;
			max = max > in.b ? max : in.b;

			out.v = max;
			delta = max - min;
			if ( delta < 0.00001 ) {
				out.s = 0;
				out.h = 0;
				return out;
			}
			if ( max > 0.0 ) {
				out.s = ( delta / max );
			} else {
				out.s = 0.0;
				out.h = NAN;
				return out;
			}
			if ( in.r >= max )
				out.h = ( in.g - in.b ) / delta;
			else
				if ( in.g >= max )
					out.h = 2.0 + ( in.b - in.r ) / delta;
				else
					out.h = 4.0 + ( in.r - in.g ) / delta;

			out.h *= 60.0;

			if ( out.h < 0.0 )
				out.h += 360.0;

			return out;
		}

		static col_t hsv_to_rgb( double h, double s, double v ) {
			double      hh, p, q, t, ff;
			long        i;
			rgb         out;

			if ( s <= 0.0 ) {
				out.r = v;
				out.g = v;
				out.b = v;
				return col_t( out.r * 255.f, out.g * 255.f, out.b * 255.f );
			}
			hh = h;
			if ( hh >= 360.0 ) hh = 0.0;
			hh /= 60.0;
			i = ( long )hh;
			ff = hh - i;
			p = v * ( 1.0 - s );
			q = v * ( 1.0 - ( s * ff ) );
			t = v * ( 1.0 - ( s * ( 1.0 - ff ) ) );

			switch ( i ) {
				case 0:
					out.r = v;
					out.g = t;
					out.b = p;
					break;
				case 1:
					out.r = q;
					out.g = v;
					out.b = p;
					break;
				case 2:
					out.r = p;
					out.g = v;
					out.b = t;
					break;

				case 3:
					out.r = p;
					out.g = q;
					out.b = v;
					break;
				case 4:
					out.r = t;
					out.g = p;
					out.b = v;
					break;
				case 5:
				default:
					out.r = v;
					out.g = p;
					out.b = q;
					break;
			}
			return col_t( int( out.r * 255.f ), int( out.g * 255.f ), int( out.b * 255.f ) );
		}

		int r, g, b, a;
	};

	/* color shit */
	struct fcol_t {
		fcol_t( ) = default;
		fcol_t( float _r, float _g, float _b, float _a = 1.0f ) :
			r( _r ), g( _g ), b( _b ), a( _a ) { }

		fcol_t( int _r, int _g, int _b, int _a = 255 ) {
			set_color( _r, _g, _b, _a );
		}

		__forceinline void set_color( float _r, float _g, float _b, float _a = 1.0f ) {
			r = _r;
			g = _g;
			b = _b;
			a = _a;
		}

		float r, g, b, a;
	};

	/* vec2 shit */
	struct vec2_t {
		/* default builders */
		vec2_t( ) : x( 0 ), y( 0 ) { }
		vec2_t( float x, float y ) : x( x ), y( y ) { }
		~vec2_t( ) { }

		/* operators */
		bool operator==( const vec2_t& src ) const {
			return ( src.x == this->x ) && ( src.y == y );
		}

		bool operator!=( const vec2_t& src ) const {
			return ( src.x != this->x ) || ( src.y != y );
		}

		float& operator[]( int i ) {
			return ( ( float* )this )[ i ];
		}

		float operator[]( int i ) const {
			return ( ( float* )this )[ i ];
		}

		/* vec - vec */
		vec2_t& operator-=( const vec2_t& v ) {
			this->x -= v.x; this->y -= v.y;
			return *this;
		}

		vec2_t& operator-=( float fl ) {
			this->x -= fl;
			this->y -= fl;

			return *this;
		}

		vec2_t& operator-( vec2_t v ) {
			vec2_t temp;
			temp.x = this->x - v.x;
			temp.y = this->y - v.y;

			return temp;
		}

		/* vec + vec */
		vec2_t& operator+=( const vec2_t& v ) {
			this->x += v.x; this->y += v.y;
			return *this;
		}

		vec2_t& operator+=( float fl ) {
			this->x += fl;
			this->y += fl;

			return *this;
		}

		vec2_t& operator+( vec2_t v ) {
			vec2_t temp;
			temp.x = this->x + v.x;
			temp.y = this->y + v.y;

			return temp;
		}

		void set( float x /*= 0.0f*/, float y /*= 0.0f */ ) {
			this->x = x;
			this->y = y;
		}

		vec2_t& operator=( const vec2_t& v ) {
			x = v.x;
			y = v.y;
			return *this;
		}

		__forceinline vec2_t operator*( const vec2_t& v ) const {
			return {
				x * v.x,
				y * v.y
			};
		}

		__forceinline vec2_t& operator*=( const vec2_t& v ) {
			x *= v.x;
			y *= v.y;
			return *this;
		}

		__forceinline vec2_t& operator*=( float f ) {
			x *= f;
			y *= f;
			return *this;
		}

		__forceinline vec2_t operator*( float f ) const {
			return {
				x * f,
				y * f
			};
		}

		/* > */
		bool operator<( const vec2_t& in ) const {
			return ( x < in.x && y < in.y );
		}

		bool operator>( const vec2_t& in ) const {
			return ( x > in.x && y > in.y );
		}

		bool invalid( ) const {
			return x == -1 && y == -1;
		}
		
		__forceinline float length_sqr( ) const {
			return ( x * x + y * y );
		}

		__forceinline float length( ) const {
			return std::sqrt( length_sqr( ) );
		}

		/* parameters */
		float x;
		float y;
	};

	class rect_t {
	public:
		int x, y, w, h;

		rect_t( ) : x( 0 ), y( 0 ), w( 0 ), h( 0 ) { }
		rect_t( int x, int y, int w, int h ) : x( x ), y( y ), w( w ), h( h ) { }
		~rect_t( ) { }
	};

	struct view_matrix_t {
		float* operator[]( int index ) { return matrix[ index ]; }
	
		float matrix[ 4 ][ 4 ];
	};

	class vec3_t {
	public:
		// data member variables
		float x, y, z;

	public:
		// ctors.
		__forceinline vec3_t( ) : x{}, y{}, z{} { }
		__forceinline vec3_t( float x, float y, float z ) : x{ x }, y{ y }, z{ z } { }

		// at-accesors.
		__forceinline float& at( const size_t index ) {
			return ( ( float* )this )[ index ];
		}
		__forceinline float& at( const size_t index ) const {
			return ( ( float* )this )[ index ];
		}

		// index operators.
		__forceinline float& operator( )( const size_t index ) {
			return at( index );
		}
		__forceinline const float& operator( )( const size_t index ) const {
			return at( index );
		}
		__forceinline float& operator[ ]( const size_t index ) {
			return at( index );
		}
		__forceinline const float& operator[ ]( const size_t index ) const {
			return at( index );
		}

		// equality operators.
		__forceinline bool operator==( const vec3_t& v ) const {
			return v.x == x && v.y == y && v.z == z;
		}
		__forceinline bool operator!=( const vec3_t& v ) const {
			return v.x != x || v.y != y || v.z != z;
		}

		// copy assignment.
		__forceinline vec3_t& operator=( const vec3_t& v ) {
			x = v.x;
			y = v.y;
			z = v.z;
			return *this;
		}

		// negation-operator.
		__forceinline vec3_t operator-( ) const {
			return vec3_t{ -x, -y, -z };
		}

		// arithmetic operators.
		__forceinline vec3_t operator+( const vec3_t& v ) const {
			return {
				x + v.x,
				y + v.y,
				z + v.z
			};
		}

		__forceinline vec3_t operator-( const vec3_t& v ) const {
			return {
				x - v.x,
				y - v.y,
				z - v.z
			};
		}

		__forceinline vec3_t operator*( const vec3_t& v ) const {
			return {
				x * v.x,
				y * v.y,
				z * v.z
			};
		}

		__forceinline vec3_t operator/( const vec3_t& v ) const {
			return {
				x / v.x,
				y / v.y,
				z / v.z
			};
		}

		// compound assignment operators.
		__forceinline vec3_t& operator+=( const vec3_t& v ) {
			x += v.x;
			y += v.y;
			z += v.z;
			return *this;
		}

		__forceinline vec3_t& operator-=( const vec3_t& v ) {
			x -= v.x;
			y -= v.y;
			z -= v.z;
			return *this;
		}

		__forceinline vec3_t& operator*=( const vec3_t& v ) {
			x *= v.x;
			y *= v.y;
			z *= v.z;
			return *this;
		}

		__forceinline vec3_t& operator/=( const vec3_t& v ) {
			x /= v.x;
			y /= v.y;
			z /= v.z;
			return *this;
		}

		// arithmetic operators w/ float.
		__forceinline vec3_t operator+( float f ) const {
			return {
				x + f,
				y + f,
				z + f
			};
		}

		__forceinline vec3_t operator-( float f ) const {
			return {
				x - f,
				y - f,
				z - f
			};
		}

		__forceinline vec3_t operator*( float f ) const {
			return {
				x * f,
				y * f,
				z * f
			};
		}

		__forceinline vec3_t operator/( float f ) const {
			return {
				x / f,
				y / f,
				z / f
			};
		}

		// compound assignment operators w/ float.
		__forceinline vec3_t& operator+=( float f ) {
			x += f;
			y += f;
			z += f;
			return *this;
		}

		__forceinline vec3_t& operator-=( float f ) {
			x -= f;
			y -= f;
			z -= f;
			return *this;
		}

		__forceinline vec3_t& operator*=( float f ) {
			x *= f;
			y *= f;
			z *= f;
			return *this;
		}

		__forceinline vec3_t& operator/=( float f ) {
			x /= f;
			y /= f;
			z /= f;
			return *this;
		}

		// methods.
		__forceinline void clear( ) {
			x = y = z = 0.f;
		}

		__forceinline float length_sqr( ) const {
			return ( ( x * x ) + ( y * y ) + ( z * z ) );
		}

		__forceinline float length_2d_sqr( ) const {
			return ( ( x * x ) + ( y * y ) );
		}

		__forceinline float length( ) const {
			return std::sqrt( length_sqr( ) );
		}

		[[nodiscard]] bool valid( ) const {
			return std::isfinite( this->x ) && std::isfinite( this->y ) && std::isfinite( this->z );
		}


		__forceinline float length_2d( ) const {
			return std::sqrt( length_2d_sqr( ) );
		}

		__forceinline float dot( const vec3_t& v ) const {
			return ( x * v.x + y * v.y + z * v.z );
		}

		__forceinline float dot( float* v ) const {
			return ( x * v[ 0 ] + y * v[ 1 ] + z * v[ 2 ] );
		}

		constexpr const bool zero( ) const noexcept {
			return x == 0.f && y == 0.f && z == 0.f;
		}

		__forceinline vec3_t cross( const vec3_t& v ) const {
			return {
				( y * v.z ) - ( z * v.y ),
				( z * v.x ) - ( x * v.z ),
				( x * v.y ) - ( y * v.x )
			};
		}

		[[nodiscard]] bool is_zero( ) const {
			return ( std::fpclassify( this->x ) == FP_ZERO &&
					 std::fpclassify( this->y ) == FP_ZERO &&
					 std::fpclassify( this->z ) == FP_ZERO );
		}

		__forceinline void to_direction( vec3_t* pvecForward, vec3_t* pvecRight = nullptr, vec3_t* pvecUp = nullptr ) const {
			if ( std::fabsf( this->x ) < 1e-6f && std::fabsf( this->y ) < 1e-6f ) {
				// pitch 90 degrees up/down from identity
				if ( pvecRight != nullptr ) {
					pvecRight->x = 0.0f;
					pvecRight->y = -1.0f;
					pvecRight->z = 0.0f;
				}

				if ( pvecUp != nullptr ) {
					pvecUp->x = -this->z;
					pvecUp->y = 0.0f;
					pvecUp->z = 0.0f;
				}
			} else {
				if ( pvecRight != nullptr ) {
					pvecRight->x = this->y;
					pvecRight->y = -this->x;
					pvecRight->z = 0.0f;
					pvecRight->norm_in_place( );
				}

				if ( pvecUp != nullptr ) {
					pvecUp->x = ( -this->x ) * this->z;
					pvecUp->y = -( this->y * this->z );
					pvecUp->z = this->y * this->y - ( -this->x ) * this->x;
					pvecUp->norm_in_place( );
				}
			}
		}

		__forceinline float norm_in_place( ) {
			const float flLength = this->length( );
			const float flRadius = 1.0f / ( flLength + std::numeric_limits<float>::epsilon( ) );

			this->x *= flRadius;
			this->y *= flRadius;
			this->z *= flRadius;

			return flLength;
		}

		__forceinline float dist_to( const vec3_t& vOther ) const {
			vec3_t delta;

			delta.x = x - vOther.x;
			delta.y = y - vOther.y;
			delta.z = z - vOther.z;

			return delta.length_2d( );
		}

		__forceinline float dist_to_3d( const vec3_t& vOther ) const {
			vec3_t delta;

			delta.x = x - vOther.x;
			delta.y = y - vOther.y;
			delta.z = z - vOther.z;

			return delta.length( );
		}

		__forceinline float normalize( ) {
			float len = length( );

			( *this ) /= ( length( ) + std::numeric_limits< float >::epsilon( ) );

			return len;
		}


		vec3_t normalize_boss( ) {
			this->x = std::isfinite( this->x ) ? std::remainder( this->x, 360.f ) : 0.f;
			this->y = std::isfinite( this->y ) ? std::remainder( this->y, 360.f ) : 0.f;
			this->z = 0.f;
			return *this;
		}

		__forceinline vec3_t normalized( ) const {
			auto vec = *this;

			vec.normalize( );

			return vec;
		}

		vec3_t clamp( ) {
			for ( size_t axis = 0; axis < 2; axis++ ) {
				auto& cur_axis = *( float* )( ( uintptr_t )this + axis );

				if ( !std::isfinite( cur_axis ) ) {
					cur_axis = 0.0f;
				}
			}

			x = std::clamp( x, -89.0f, 89.0f );
			y = std::clamp( std::remainder( y, 360.0f ), -180.0f, 180.0f );
			z = 0.0f;

			return *this;
		}

		//vec3_t world_to_screen( view_matrix_t matrix ) const {
		//	float _x = matrix[ 0 ][ 0 ] * x + matrix[ 0 ][ 1 ] * y + matrix[ 0 ][ 2 ] * z + matrix[ 0 ][ 3 ];
		//	float _y = matrix[ 1 ][ 0 ] * x + matrix[ 1 ][ 1 ] * y + matrix[ 1 ][ 2 ] * z + matrix[ 1 ][ 3 ];
		//
		//	float w = matrix[ 3 ][ 0 ] * x + matrix[ 3 ][ 1 ] * y + matrix[ 3 ][ 2 ] * z + matrix[ 3 ][ 3 ];
		//
		//	float inv_w = 1.f / w;
		//	_x *= inv_w;
		//	_y *= inv_w;
		//
		//
		//	float screen_x = GetSystemMetrics( SM_CXSCREEN ) * 0.5f;
		//	float screen_y = GetSystemMetrics( SM_CYSCREEN ) * 0.5f;
		//
		//	screen_x += 0.5f * _x * GetSystemMetrics( SM_CXSCREEN ) + 0.5f;
		//	screen_y -= 0.5f * _y * GetSystemMetrics( SM_CYSCREEN ) + 0.5f;
		//
		//
		//	return { screen_x, screen_y, w };
		//}
	};

	struct vec4_t {
		constexpr vec4_t( const float x = 0.0f, const float y = 0.0f, const float z = 0.0f, const float w = 0.0f ) :
			x( x ), y( y ), z( z ), w( w ) { }

		float x = 0.0f, y = 0.0f, z = 0.0f, w = 0.0f;
	};


	using matrix3x3_t = float[ 3 ][ 3 ];
	struct matrix3x4_t {
		matrix3x4_t( ) = default;

		constexpr matrix3x4_t(
			const float m00, const float m01, const float m02, const float m03,
			const float m10, const float m11, const float m12, const float m13,
			const float m20, const float m21, const float m22, const float m23 ) {
			arr_data[ 0 ][ 0 ] = m00;
			arr_data[ 0 ][ 1 ] = m01;
			arr_data[ 0 ][ 2 ] = m02;
			arr_data[ 0 ][ 3 ] = m03;
			arr_data[ 1 ][ 0 ] = m10;
			arr_data[ 1 ][ 1 ] = m11;
			arr_data[ 1 ][ 2 ] = m12;
			arr_data[ 1 ][ 3 ] = m13;
			arr_data[ 2 ][ 0 ] = m20;
			arr_data[ 2 ][ 1 ] = m21;
			arr_data[ 2 ][ 2 ] = m22;
			arr_data[ 2 ][ 3 ] = m23;
		}

		constexpr matrix3x4_t( const vec3_t& vec_forward, const vec3_t& vec_left, const vec3_t& vec_up, const vec3_t& vec_origin ) {
			set_forward( vec_forward );
			set_left( vec_left );
			set_up( vec_up );
			set_origin( vec_origin );
		}

		[[nodiscard]] float* operator[]( const int n_index ) {
			return arr_data[ n_index ];
		}

		[[nodiscard]] const float* operator[]( const int n_index ) const {
			return arr_data[ n_index ];
		}

		constexpr void set_forward( const vec3_t& vec_forward ) {
			arr_data[ 0 ][ 0 ] = vec_forward.x;
			arr_data[ 1 ][ 0 ] = vec_forward.y;
			arr_data[ 2 ][ 0 ] = vec_forward.z;
		}

		constexpr void set_left( const vec3_t& vec_left ) {
			arr_data[ 0 ][ 1 ] = vec_left.x;
			arr_data[ 1 ][ 1 ] = vec_left.y;
			arr_data[ 2 ][ 1 ] = vec_left.z;
		}

		constexpr void set_up( const vec3_t& vec_up ) {
			arr_data[ 0 ][ 2 ] = vec_up.x;
			arr_data[ 1 ][ 2 ] = vec_up.y;
			arr_data[ 2 ][ 2 ] = vec_up.z;
		}

		constexpr void set_origin( const vec3_t& vec_origin ) {
			arr_data[ 0 ][ 3 ] = vec_origin.x;
			arr_data[ 1 ][ 3 ] = vec_origin.y;
			arr_data[ 2 ][ 3 ] = vec_origin.z;
		}

		//[[nodiscard]] constexpr vec3_t get_forward( ) const {
		//	return { arr_data[ 0 ][ 0 ], arr_data[ 1 ][ 0 ], arr_data[ 2 ][ 0 ] };
		//}
		//
		//[[nodiscard]] constexpr vec3_t get_left( ) const {
		//	return { arr_data[ 0 ][ 1 ], arr_data[ 1 ][ 1 ], arr_data[ 2 ][ 1 ] };
		//}
		//
		//[[nodiscard]] constexpr vec3_t get_up( ) const {
		//	return { arr_data[ 0 ][ 2 ], arr_data[ 1 ][ 2 ], arr_data[ 2 ][ 2 ] };
		//}
		//
		//[[nodiscard]] constexpr vec3_t get_origin( ) const {
		//	return { arr_data[ 0 ][ 3 ], arr_data[ 1 ][ 3 ], arr_data[ 2 ][ 3 ] };
		//}

		constexpr void invalidate( ) {
			for ( auto& arr_sub_data : arr_data ) {
				for ( auto& fl_data : arr_sub_data )
					fl_data = std::numeric_limits<float>::infinity( );
			}
		}

		[[nodiscard]] constexpr matrix3x4_t concat_transforms( const matrix3x4_t& mat_other ) const {
			return {
				arr_data[ 0 ][ 0 ] * mat_other.arr_data[ 0 ][ 0 ] + arr_data[ 0 ][ 1 ] * mat_other.arr_data[ 1 ][ 0 ] + arr_data[ 0 ][ 2 ] * mat_other.arr_data[ 2 ][ 0 ],
				arr_data[ 0 ][ 0 ] * mat_other.arr_data[ 0 ][ 1 ] + arr_data[ 0 ][ 1 ] * mat_other.arr_data[ 1 ][ 1 ] + arr_data[ 0 ][ 2 ] * mat_other.arr_data[ 2 ][ 1 ],
				arr_data[ 0 ][ 0 ] * mat_other.arr_data[ 0 ][ 2 ] + arr_data[ 0 ][ 1 ] * mat_other.arr_data[ 1 ][ 2 ] + arr_data[ 0 ][ 2 ] * mat_other.arr_data[ 2 ][ 2 ],
				arr_data[ 0 ][ 0 ] * mat_other.arr_data[ 0 ][ 3 ] + arr_data[ 0 ][ 1 ] * mat_other.arr_data[ 1 ][ 3 ] + arr_data[ 0 ][ 2 ] * mat_other.arr_data[ 2 ][ 3 ] + arr_data[ 0 ][ 3 ],

				arr_data[ 1 ][ 0 ] * mat_other.arr_data[ 0 ][ 0 ] + arr_data[ 1 ][ 1 ] * mat_other.arr_data[ 1 ][ 0 ] + arr_data[ 1 ][ 2 ] * mat_other.arr_data[ 2 ][ 0 ],
				arr_data[ 1 ][ 0 ] * mat_other.arr_data[ 0 ][ 1 ] + arr_data[ 1 ][ 1 ] * mat_other.arr_data[ 1 ][ 1 ] + arr_data[ 1 ][ 2 ] * mat_other.arr_data[ 2 ][ 1 ],
				arr_data[ 1 ][ 0 ] * mat_other.arr_data[ 0 ][ 2 ] + arr_data[ 1 ][ 1 ] * mat_other.arr_data[ 1 ][ 2 ] + arr_data[ 1 ][ 2 ] * mat_other.arr_data[ 2 ][ 2 ],
				arr_data[ 1 ][ 0 ] * mat_other.arr_data[ 0 ][ 3 ] + arr_data[ 1 ][ 1 ] * mat_other.arr_data[ 1 ][ 3 ] + arr_data[ 1 ][ 2 ] * mat_other.arr_data[ 2 ][ 3 ] + arr_data[ 1 ][ 3 ],

				arr_data[ 2 ][ 0 ] * mat_other.arr_data[ 0 ][ 0 ] + arr_data[ 2 ][ 1 ] * mat_other.arr_data[ 1 ][ 0 ] + arr_data[ 2 ][ 2 ] * mat_other.arr_data[ 2 ][ 0 ],
				arr_data[ 2 ][ 0 ] * mat_other.arr_data[ 0 ][ 1 ] + arr_data[ 2 ][ 1 ] * mat_other.arr_data[ 1 ][ 1 ] + arr_data[ 2 ][ 2 ] * mat_other.arr_data[ 2 ][ 1 ],
				arr_data[ 2 ][ 0 ] * mat_other.arr_data[ 0 ][ 2 ] + arr_data[ 2 ][ 1 ] * mat_other.arr_data[ 1 ][ 2 ] + arr_data[ 2 ][ 2 ] * mat_other.arr_data[ 2 ][ 2 ],
				arr_data[ 2 ][ 0 ] * mat_other.arr_data[ 0 ][ 3 ] + arr_data[ 2 ][ 1 ] * mat_other.arr_data[ 1 ][ 3 ] + arr_data[ 2 ][ 2 ] * mat_other.arr_data[ 2 ][ 3 ] + arr_data[ 2 ][ 3 ]
			};
		}

		//[[nodiscard]] qangle_t to_angles( ) const;

		float arr_data[ 3 ][ 4 ] = {};
	};

	struct Quaternion_t {
		constexpr Quaternion_t( const float x = 0.0f, const float y = 0.0f, const float z = 0.0f, const float w = 0.0f ) :
			x( x ), y( y ), z( z ), w( w ) { }

		[[nodiscard]] bool IsValid( ) const {
			return ( std::isfinite( x ) && std::isfinite( y ) && std::isfinite( z ) && std::isfinite( w ) );
		}

		/// @param[in] vecOrigin [optional] translation for converted matrix
		/// @returns: matrix converted from quaternion
		[[nodiscard]] matrix3x4_t ToMatrix( const evo::vec3_t& vecOrigin = {} ) const {
			// CS_ASSERT( this->IsValid( ) ); see ya soon

			matrix3x4_t matOut;

	#ifdef _DEBUG // precalculate common multiplications
			const float x2 = this->x + this->x, y2 = this->y + this->y, z2 = this->z + this->z;
			const float xx = this->x * x2, xy = this->x * y2, xz = this->x * z2;
			const float yy = this->y * y2, yz = this->y * z2;
			const float zz = this->z * z2;
			const float wx = this->w * x2, wy = this->w * y2, wz = this->w * z2;

			matOut[ 0 ][ 0 ] = 1.0f - ( yy + zz );
			matOut[ 1 ][ 0 ] = xy + wz;
			matOut[ 2 ][ 0 ] = xz - wy;

			matOut[ 0 ][ 1 ] = xy - wz;
			matOut[ 1 ][ 1 ] = 1.0f - ( xx + zz );
			matOut[ 2 ][ 1 ] = yz + wx;

			matOut[ 0 ][ 2 ] = xz + wy;
			matOut[ 1 ][ 2 ] = yz - wx;
			matOut[ 2 ][ 2 ] = 1.0f - ( xx + yy );
	#else // let the compiler optimize calculations itself
			matOut[ 0 ][ 0 ] = 1.0f - 2.0f * this->y * this->y - 2.0f * this->z * this->z;
			matOut[ 1 ][ 0 ] = 2.0f * this->x * this->y + 2.0f * this->w * this->z;
			matOut[ 2 ][ 0 ] = 2.0f * this->x * this->z - 2.0f * this->w * this->y;

			matOut[ 0 ][ 1 ] = 2.0f * this->x * this->y - 2.0f * this->w * this->z;
			matOut[ 1 ][ 1 ] = 1.0f - 2.0f * this->x * this->x - 2.0f * this->z * this->z;
			matOut[ 2 ][ 1 ] = 2.0f * this->y * this->z + 2.0f * this->w * this->x;

			matOut[ 0 ][ 2 ] = 2.0f * this->x * this->z + 2.0f * this->w * this->y;
			matOut[ 1 ][ 2 ] = 2.0f * this->y * this->z - 2.0f * this->w * this->x;
			matOut[ 2 ][ 2 ] = 1.0f - 2.0f * this->x * this->x - 2.0f * this->y * this->y;
	#endif

			matOut[ 0 ][ 3 ] = vecOrigin.x;
			matOut[ 1 ][ 3 ] = vecOrigin.y;
			matOut[ 2 ][ 3 ] = vecOrigin.z;
			return matOut;
		}

		float x, y, z, w;
	};

	struct alignas( 16 ) QuaternionAligned_t : Quaternion_t {
		QuaternionAligned_t& operator=( const Quaternion_t& quatOther ) {
			this->x = quatOther.x;
			this->y = quatOther.y;
			this->z = quatOther.z;
			this->w = quatOther.w;
			return *this;
		}
	};

	static_assert( alignof( QuaternionAligned_t ) == 16 );

	struct vertex_t {
		float x = 0.f, y = 0.f, z = 0.f;
		DWORD color = 0xFFFFFFFF;

		vertex_t( ) { }

		vertex_t( vec3_t pos, col_t clr ) {
			x = pos.x;
			y = pos.y;
			color = D3DCOLOR_ARGB( clr.a, clr.r, clr.g, clr.b );
		}

		vertex_t( float _x, float _y, col_t clr ) {
			x = _x;
			y = _y;
			color = D3DCOLOR_ARGB( clr.a, clr.r, clr.g, clr.b );
		}

		vertex_t( const int _x, const int _y, col_t clr ) {
			x = ( float )_x;
			y = ( float )_y;
			color = D3DCOLOR_ARGB( clr.a, clr.r, clr.g, clr.b );
		}

		vertex_t( const int _x, const int _y, DWORD clr ) {
			x = ( float )_x;
			y = ( float )_y;
			color = clr;
		}
	};

	struct alignas( 16 ) VectorAligned_t : vec3_t {
		VectorAligned_t( ) = default;

		explicit VectorAligned_t( const vec3_t& vecBase ) {
			this->x = vecBase.x;
			this->y = vecBase.y;
			this->z = vecBase.z;
			this->w = 0.0f;
		}

		constexpr VectorAligned_t& operator=( const vec3_t& vecBase ) {
			this->x = vecBase.x;
			this->y = vecBase.y;
			this->z = vecBase.z;
			this->w = 0.0f;
			return *this;
		}

		float w = 0.0f;
	};

	static_assert( alignof( VectorAligned_t ) == 16 );

	class c_transform {
	public:
		VectorAligned_t m_position;
		//QuaternionAligned_t quatOrientation;
	};

	static_assert( alignof( c_transform ) == 16 );

	struct QAngle_t {
		constexpr QAngle_t( float x = 0.f, float y = 0.f, float z = 0.f ) :
			x( x ), y( y ), z( z ) { }

		constexpr QAngle_t( const float* arrAngles ) :
			x( arrAngles[ 0 ] ), y( arrAngles[ 1 ] ), z( arrAngles[ 2 ] ) { }

#pragma region qangle_array_operators

		[[nodiscard]] float& operator[]( const int nIndex ) {
			return reinterpret_cast< float* >( this )[ nIndex ];
		}

		[[nodiscard]] const float& operator[]( const int nIndex ) const {
			return reinterpret_cast< const float* >( this )[ nIndex ];
		}

#pragma endregion

#pragma region qangle_relational_operators

		bool operator==( const QAngle_t& angBase ) const {
			return this->IsEqual( angBase );
		}

		bool operator!=( const QAngle_t& angBase ) const {
			return !this->IsEqual( angBase );
		}

#pragma endregion

#pragma region qangle_assignment_operators

		constexpr QAngle_t& operator=( const QAngle_t& angBase ) {
			this->x = angBase.x;
			this->y = angBase.y;
			this->z = angBase.z;
			return *this;
		}

#pragma endregion

#pragma region qangle_arithmetic_assignment_operators

		constexpr QAngle_t& operator+=( const QAngle_t& angBase ) {
			this->x += angBase.x;
			this->y += angBase.y;
			this->z += angBase.z;
			return *this;
		}

		constexpr QAngle_t& operator-=( const QAngle_t& angBase ) {
			this->x -= angBase.x;
			this->y -= angBase.y;
			this->z -= angBase.z;
			return *this;
		}

		constexpr QAngle_t& operator*=( const QAngle_t& angBase ) {
			this->x *= angBase.x;
			this->y *= angBase.y;
			this->z *= angBase.z;
			return *this;
		}

		constexpr QAngle_t& operator/=( const QAngle_t& angBase ) {
			this->x /= angBase.x;
			this->y /= angBase.y;
			this->z /= angBase.z;
			return *this;
		}

		constexpr QAngle_t& operator+=( const float flAdd ) {
			this->x += flAdd;
			this->y += flAdd;
			this->z += flAdd;
			return *this;
		}

		constexpr QAngle_t& operator-=( const float flSubtract ) {
			this->x -= flSubtract;
			this->y -= flSubtract;
			this->z -= flSubtract;
			return *this;
		}

		constexpr QAngle_t& operator*=( const float flMultiply ) {
			this->x *= flMultiply;
			this->y *= flMultiply;
			this->z *= flMultiply;
			return *this;
		}

		constexpr QAngle_t& operator/=( const float flDivide ) {
			this->x /= flDivide;
			this->y /= flDivide;
			this->z /= flDivide;
			return *this;
		}

#pragma endregion

#pragma region qangle_arithmetic_unary_operators

		constexpr QAngle_t& operator-( ) {
			this->x = -this->x;
			this->y = -this->y;
			this->z = -this->z;
			return *this;
		}

		constexpr QAngle_t operator-( ) const {
			return { -this->x, -this->y, -this->z };
		}

#pragma endregion

#pragma region qangle_arithmetic_ternary_operators

		constexpr QAngle_t operator+( const QAngle_t& angAdd ) const {
			return { this->x + angAdd.x, this->y + angAdd.y, this->z + angAdd.z };
		}

		constexpr QAngle_t operator-( const QAngle_t& angSubtract ) const {
			return { this->x - angSubtract.x, this->y - angSubtract.y, this->z - angSubtract.z };
		}

		constexpr QAngle_t operator*( const QAngle_t& angMultiply ) const {
			return { this->x * angMultiply.x, this->y * angMultiply.y, this->z * angMultiply.z };
		}

		constexpr QAngle_t operator/( const QAngle_t& angDivide ) const {
			return { this->x / angDivide.x, this->y / angDivide.y, this->z / angDivide.z };
		}

		constexpr QAngle_t operator+( const float flAdd ) const {
			return { this->x + flAdd, this->y + flAdd, this->z + flAdd };
		}

		constexpr QAngle_t operator-( const float flSubtract ) const {
			return { this->x - flSubtract, this->y - flSubtract, this->z - flSubtract };
		}

		constexpr QAngle_t operator*( const float flMultiply ) const {
			return { this->x * flMultiply, this->y * flMultiply, this->z * flMultiply };
		}

		constexpr QAngle_t operator/( const float flDivide ) const {
			return { this->x / flDivide, this->y / flDivide, this->z / flDivide };
		}

#pragma endregion

		// @returns : true if each component of angle is finite, false otherwise
		[[nodiscard]] bool IsValid( ) const {
			return ( std::isfinite( this->x ) && std::isfinite( this->y ) && std::isfinite( this->z ) );
		}

		/// @returns: true if each component of angle equals to another, false otherwise
		[[nodiscard]] bool IsEqual( const QAngle_t& angEqual, const float flErrorMargin = std::numeric_limits<float>::epsilon( ) ) const {
			return ( std::fabsf( this->x - angEqual.x ) < flErrorMargin && std::fabsf( this->y - angEqual.y ) < flErrorMargin && std::fabsf( this->z - angEqual.z ) < flErrorMargin );
		}

		/// @returns: true if each component of angle equals zero, false otherwise
		[[nodiscard]] bool IsZero( ) const {
			// @test: to make this implementation right, we should use fpclassify here, but game aren't doing same, probably it's better to keep this same, just ensure that it will be compiled same
			return ( this->x == 0.0f && this->y == 0.0f && this->z == 0.0f );
		}

		/// @returns: length of hypotenuse
		[[nodiscard]] float Length2D( ) const {
			return std::sqrtf( x * x + y * y );
		}

		/// clamp each angle component by minimal/maximal allowed value for source sdk games
		/// @returns: clamped angle
		constexpr QAngle_t& Clamp( ) {
			this->x = std::clamp( this->x, -89.f, 89.f );
			this->y = std::clamp( this->y, -180.f, 180.f );
			this->z = std::clamp( this->z, -45.f, 45.f );
			return *this;
		}

		/// map polar angles to the range of [-180, 180] degrees
		/// @returns: normalized angle
		QAngle_t& Normalize( ) {
			this->x = std::remainderf( this->x, 360.f );
			this->y = std::remainderf( this->y, 360.f );
			this->z = std::remainderf( this->z, 360.f );
			return *this;
		}


	public:
		float x = 0.0f, y = 0.0f, z = 0.0f;
	};

	namespace math {
		constexpr float rad_pi{ 57.295779513082f };

		__forceinline void sin_cos( float radians, float* sine, float* cosine ) {
			*sine = sin( radians );
			*cosine = cos( radians );
		}

		__forceinline void angle_vectors( const vec3_t /*qajngle*/& angles, vec3_t* forward = nullptr, vec3_t* right = nullptr, vec3_t* up = nullptr ) {
			float sr, sp, sy, cr, cp, cy;

			sin_cos( deg_to_rad( angles.x ), &sp, &cp );
			sin_cos( deg_to_rad( angles.y ), &sy, &cy );
			sin_cos( deg_to_rad( angles.z ), &sr, &cr );

			if ( forward ) {
				forward->x = cp * cy;
				forward->y = cp * sy;
				forward->z = -sp;
			}

			if ( right ) {
				right->x = ( -1 * sr * sp * cy + -1 * cr * -sy );
				right->y = ( -1 * sr * sp * sy + -1 * cr * cy );
				right->z = -1 * sr * cp;
			}

			if ( up ) {
				up->x = ( cr * sp * cy + -sr * -sy );
				up->y = ( cr * sp * sy + -sr * cy );
				up->z = cr * cp;
			}
		}

		__forceinline static float get_fov( const vec3_t /* qangle */& current, const vec3_t& start, const vec3_t& end ) {
			vec3_t currentAim, targetAim = ( end - start ).normalized( );
			angle_vectors( current, &currentAim );
			return rad_to_deg( acos( targetAim.dot( currentAim ) ) );
		}

		constexpr float m_pitch = 0.022f;
		constexpr float m_yaw = 0.022f;

		__forceinline vec2_t angle_to_pixels( const vec3_t& angle ) {
			return vec2_t( -angle.y / m_yaw, angle.x / m_pitch );
		}

		__forceinline vec3_t pixels_to_angle( const vec2_t& pixel ) {
			auto result = vec3_t( -pixel.y * m_yaw, pixel.x * m_pitch, 0.f );
			result.clamp( );
			return result;
		}

		__forceinline void normalize_angles_sdk ( vec3_t& angles ) {
			for ( auto i = 0; i < 3; i++ ) {
				while ( angles[ i ] < -180.0f )
					angles[ i ] += 360.0f;
				while ( angles[ i ] > 180.0f )
					angles[ i ] -= 360.0f;
			}
		}

		__forceinline vec3_t normalize_angle_sdk ( vec3_t angle ) {
			while ( angle.x > 89.f ) {
				angle.x -= 180.f;
			}
			while ( angle.x < -89.f ) {
				angle.x += 180.f;
			}
			if ( angle.y > 180 ) {
				angle.y -= ( round( angle.y / 360 ) * 360.f );
			} else if ( angle.y < -180 ) {
				angle.y += ( round( angle.y / 360 ) * -360.f );
			}
			if ( ( angle.z > 50 ) || ( angle.z < 50 ) ) {
				angle.z = 0;
			}
			return angle;
		}

		__forceinline bool normalize_angles( vec3_t& angles ) {
			if ( std::isfinite( angles.x ) && std::isfinite( angles.y ) && std::isfinite( angles.z ) ) {
				angles.x = std::remainder( angles.x, 360.0f );
				angles.y = std::remainder( angles.y, 360.0f );

				return true;
			}
			return false;
		}

		__forceinline static void angle_vectors( const vec3_t& angles, vec3_t& forward, vec3_t* right = nullptr, vec3_t* up = nullptr ) {
			const auto sp = sin( math::deg_to_rad( angles.x ) ), cp = cos( math::deg_to_rad( angles.x ) ),
				sy = sin( math::deg_to_rad( angles.y ) ), cy = cos( math::deg_to_rad( angles.y ) ),
				sr = sin( math::deg_to_rad( angles.z ) ), cr = cos( math::deg_to_rad( angles.z ) );

			forward.x = cp * cy;
			forward.y = cp * sy;
			forward.z = -sp;

			if ( right ) {
				right->x = -1 * sr * sp * cy + -1 * cr * -sy;
				right->y = -1 * sr * sp * sy + -1 * cr * cy;
				right->z = -1 * sr * cp;
			}

			if ( up ) {
				up->x = cr * sp * cy + -sr * -sy;
				up->y = cr * sp * sy + -sr * cy;
				up->z = cr * cp;
			}
		}

		__forceinline bool clamp_angles( vec3_t& angles ) {
			if ( std::isfinite( angles.x ) && std::isfinite( angles.y ) && std::isfinite( angles.z ) ) {
				angles.x = std::clamp( angles.x, -89.0f, 89.0f );
				angles.y = std::clamp( angles.y, -180.0f, 180.0f );
				angles.z = 0.0f;

				return true;
			}

			return false;
		}

		__forceinline vec3_t vector_angles( const vec3_t& start, const vec3_t& end ) {
			const vec3_t delta = end - start;

			const float magnitude = std::sqrt( delta.x * delta.x + delta.y * delta.y );
			const float pitch = std::atan2( -delta.z, magnitude ) * rad_pi;
			const float yaw = std::atan2( delta.y, delta.x ) * rad_pi;

			return vec3_t( pitch, yaw, 0.0f );
		}

		template < typename T >
		__forceinline T clamp( const T& val, const T& minVal, const T& maxVal ) {
			if ( ( T )val < minVal )
				return minVal;
			else if ( ( T )val > maxVal )
				return maxVal;
			else
				return val;
		}

		__forceinline void vec_angles( const vec3_t& forward, vec3_t& angles ) {
			float tmp, yaw, pitch;

			if ( forward[ 1 ] == 0 && forward[ 0 ] == 0 ) {
				yaw = 0;
				if ( forward[ 2 ] > 0 )
					pitch = 270;
				else
					pitch = 90;
			} else {
				yaw = ( atan2( forward[ 1 ], forward[ 0 ] ) * 180 / 3.14159265358979323846f );
				if ( yaw < 0 )
					yaw += 360;

				tmp = sqrt( forward[ 0 ] * forward[ 0 ] + forward[ 1 ] * forward[ 1 ] );
				pitch = ( atan2( -forward[ 2 ], tmp ) * 180 / 3.14159265358979323846f );
				if ( pitch < 0 )
					pitch += 360;
			}

			angles[ 0 ] = pitch;
			angles[ 1 ] = yaw;
			angles[ 2 ] = 0;
		}

		__forceinline vec3_t calc_angle_boss( vec3_t src, vec3_t dst ) {
			vec3_t ret;
			vec_angles( dst - src, ret );
			return ret;
		}

		__forceinline vec3_t calc_ang( const vec3_t& src, const vec3_t& dst ) {
			constexpr auto k_pi = 3.14159265358979323846f;
			constexpr auto k_pi2 = k_pi * 2.f;
			constexpr auto k_rad_pi = 180.f / k_pi;

			vec3_t angles;

			vec3_t delta = src - dst;
			float hyp = delta.length_2d();

			angles.y = std::atanf( delta.y / delta.x ) * k_rad_pi;
			angles.x = std::atanf( -delta.z / hyp ) * -k_rad_pi;
			angles.z = 0.0f;

			if ( delta.x >= 0.0f )
				angles.y += 180.0f;

			return angles;
		}
	}

}

#define stringify(x) #x
#define concat_impl(x, y) x##y
#define concat(x, y) concat_impl(x, y)

template<typename t, t v>
struct constant_holder {
	enum class val_holder : t {
		val = v
	};
};

#define constant(value) ((decltype(value))constant_holder<decltype(value), value>::val_holder::val)

constexpr std::uint32_t seed = 0x45C3370D;
constexpr std::uint32_t prime = 0x1000193;

inline std::uint32_t fnv1a_rt( const char* key, const std::uint32_t length ) {
	const char* data = const_cast< char* >( key );
	auto hash = seed;

	for ( size_t i = 0; i < length; ++i ) {
		const auto value = static_cast< std::uint8_t >( data[ i ] );
		hash = hash ^ value;
		hash *= prime;
	}

	return hash;
}

constexpr std::uint32_t fnv1a_ct( const char* str, const std::uint32_t value = seed ) noexcept {
	return !*str ? value : fnv1a_ct( str + 1, static_cast< unsigned >( 1ull *
																	   ( value ^ static_cast< std::uint8_t >( *str ) ) * prime ) );
}

#define HASH_CT(s) constant(fnv1a_ct(s))
#define HASH_RT(s) fnv1a_rt(s, strlen(s))