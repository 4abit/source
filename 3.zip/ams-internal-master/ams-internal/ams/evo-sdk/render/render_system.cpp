#include "render_system.hpp"
#include "fonts.hpp"

void evo::render_t::initialize_font_system( ) {
	ImGuiIO& io = ImGui::GetIO( ); /* get imgui io */

	/* create a new cfg for each type of font */
	ImFontConfig cfg;// = new ImFontConfig( );

	cfg.PixelSnapH = true;
	cfg.OversampleH = cfg.OversampleV = 1;
	cfg.FontDataOwnedByAtlas = false;

	/* ranges */
	static const ImWchar ranges[ ] =
	{
	   0x0020, 0x00FF,
	   0x0400, 0x052F,
	   0x2DE0, 0x2DFF,
	   0xA640, 0xA69F,
	   0x3131, 0x3163,
	   0xAC00, 0xD79D,
	   0,
	};

	static const ImWchar ranges_ic[ ] = {

	   0x0020, 0x00FF, // Basic Latin + Latin Supplement
	   0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
	   0x2DE0, 0x2DFF, // Cyrillic Extended-A
	   0xA640, 0xA69F, // Cyrillic Extended-B
	   0xE000, 0xE226, // icons
	   0,
	};

	auto add_font = [ & ]( const char* font, float size )->void {
		io.Fonts->AddFontFromFileTTF( font, size, &cfg, ranges );

		printf( "[ams]-[font_system] - loaded font: %s, size: %.1f\n", font, size );
	};


	add_font( "C:\\Windows\\Fonts\\verdana.ttf", 11.0f );
	io.Fonts->AddFontFromMemoryTTF( lexendregular, sizeof( lexendregular ), 14 );
	io.Fonts->AddFontFromMemoryCompressedTTF( MenuIcons_compressed_data, MenuIcons_compressed_size, 16.0f, &cfg, io.Fonts->GetGlyphRangesJapanese( ) );
	io.Fonts->AddFontFromMemoryTTF( arrowmod, sizeof( arrowmod ), 22.0f, &cfg, io.Fonts->GetGlyphRangesJapanese( ) );
	io.Fonts->AddFontFromMemoryTTF( icons_binary, sizeof( icons_binary ), 12, &cfg, ranges_ic );
	io.Fonts->AddFontFromMemoryTTF( _smallest_pixel, sizeof( _smallest_pixel ), 10.f, &cfg );
	io.Fonts->AddFontFromMemoryTTF( iconbox, sizeof( iconbox ), 11.f, &cfg );
	io.Fonts->AddFontFromMemoryTTF( hearthicon, sizeof( hearthicon ), 13.f, &cfg );

	/* freetype build */
	//ImGuiFreeType::BuildFontAtlas( io.Fonts, ImGuiFreeTypeBuilderFlags_Monochrome | ImGuiFreeTypeBuilderFlags_MonoHinting );
	ImGuiFreeType::BuildFontAtlas( io.Fonts, ImGuiFreeTypeBuilderFlags_Bitmap );
}

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.hpp"

void evo::render_t::initialize_imgui( void* w, IDirect3DDevice9* device ) {
	IMGUI_CHECKVERSION( );

	ImGui::CreateContext( );
	ImGui::StyleColorsDark( );

	ImGui_ImplWin32_Init( w );
	ImGui_ImplDX9_Init( device );


	/* init font system */
	this->initialize_font_system( );
}

#include "../../thirdparty/imgui/imgui_internal.h"
void evo::render_t::add_radial_gradient( const evo::vec2_t& center, float radius, ImU32 col_in, ImU32 col_out ) {
	if ( radius < 0.5f )
		return;

	// Use arc with automatic segment count
	ext_draw_list->_PathArcToFastEx( ImVec2( center.x, center.y ), radius, 0, 48, 0 );
	const int count = ext_draw_list->_Path.Size - 1;

	unsigned int vtx_base = ext_draw_list->_VtxCurrentIdx;
	ext_draw_list->PrimReserve( count * 3, count + 1 );

	// Submit vertices
	const ImVec2 uv = ext_draw_list->_Data->TexUvWhitePixel;
	ext_draw_list->PrimWriteVtx( ImVec2( center.x, center.y ), uv, col_in );
	for ( int n = 0; n < count; n++ )
		ext_draw_list->PrimWriteVtx( ext_draw_list->_Path[ n + 1 ], uv, col_out );

	// Submit a fan of triangles
	for ( int n = 0; n < count; n++ ) {
		ext_draw_list->PrimWriteIdx( ( ImDrawIdx )( vtx_base ) );
		ext_draw_list->PrimWriteIdx( ( ImDrawIdx )( vtx_base + 1 + n ) );
		ext_draw_list->PrimWriteIdx( ( ImDrawIdx )( vtx_base + 1 + ( ( n + 1 ) % count ) ) );
	}
	ext_draw_list->_Path.Size = 0;
}

void evo::render_t::add_line( evo::vec2_t from, evo::vec2_t to, evo::col_t c, float thickness ) {
	ImGui::GetBackgroundDrawList( )->AddLine( ImVec2( from.x, from.y ), ImVec2( to.x, to.y ), c.convert( ), thickness );
}

void evo::render_t::add_circle( evo::vec2_t center, float radius, evo::col_t c ) {
	ext_draw_list->AddCircle( evo::macros::vec_t( center.x, center.y ), radius, c.convert( ) );
}

void evo::render_t::add_text( int x, int y, col_t c, int font, const char* text, int flag ) { 
	ImGuiIO& io = ImGui::GetIO( );
	ImGui::PushFont( io.Fonts->Fonts[ font ] );

	if ( flag == font_flags_t::dropshadow ) {
		ext_draw_list->AddText( evo::macros::vec_t( x + 1.f, y + 1.f ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
	}

	if ( flag == font_flags_t::dropshadow_low ) {
		ext_draw_list->AddText( evo::macros::vec_t( x + 1.f, y + 1.f ), col_t( 5, 5, 5 ).modify_alpha( c.a / 2 ).convert( ), text );
	}

	if ( flag == font_flags_t::outline ) {
		ext_draw_list->AddText( evo::macros::vec_t( x + 1, y - 1 ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
		ext_draw_list->AddText( evo::macros::vec_t( x - 1, y + 1 ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
		ext_draw_list->AddText( evo::macros::vec_t( x - 1, y - 1 ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
		ext_draw_list->AddText( evo::macros::vec_t( x + 1, y + 1 ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );

		ext_draw_list->AddText( evo::macros::vec_t( x, y + 1 ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
		ext_draw_list->AddText( evo::macros::vec_t( x, y - 1 ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
		ext_draw_list->AddText( evo::macros::vec_t( x + 1, y ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
		ext_draw_list->AddText( evo::macros::vec_t( x - 1, y ), col_t( 5, 5, 5 ).modify_alpha( c.a ).convert( ), text );
	}

	/* text */
	ext_draw_list->AddText( evo::macros::vec_t( x, y ), c.convert( ), text );

	ImGui::PopFont( );
}

evo::vec2_t evo::render_t::text_size( const char* text, int font ) {
	ImGuiIO& io = ImGui::GetIO( );

	return {
		io.Fonts->Fonts[ font ]->CalcTextSizeA( io.Fonts->Fonts[ font ]->FontSize, FLT_MAX, -1.0f, text ).x,
		io.Fonts->Fonts[ font ]->CalcTextSizeA( io.Fonts->Fonts[ font ]->FontSize, FLT_MAX, -1.0f, text ).y
	};
}

void evo::render_t::add_rect_filled( int x, int y, int w, int h, evo::col_t col, int round ) {
	ext_draw_list->AddRectFilled( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), col.convert( ), round );
}

void evo::render_t::add_rect_filled_shadowed( int x, int y, int w, int h, evo::col_t col, int round, int thickness ) {
	ext_draw_list->AddShadowRect( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), col.convert( ), thickness, evo::macros::vec_t( ), round, thickness );
}

void evo::render_t::add_rect( int x, int y, int w, int h, evo::col_t col, int round, int tickness ) {
	ext_draw_list->AddRect( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), col.convert( ), round, 0, tickness );
}

void evo::render_t::add_filled_circle( evo::vec2_t center, float radius, evo::col_t c ) {
	ext_draw_list->AddCircleFilled( evo::macros::vec_t( center.x, center.y ), radius, c.convert( ) );
}

evo::macros::u32_t lerp_color( evo::macros::u32_t col1, evo::macros::u32_t col2, float t ) {
		evo::macros::vec4_t c1 = ImGui::ColorConvertU32ToFloat4( col1 );
		evo::macros::vec4_t c2 = ImGui::ColorConvertU32ToFloat4( col2 );
		evo::macros::vec4_t lerped = evo::macros::vec4_t( c1.x + t * ( c2.x - c1.x ),
								c1.y + t * ( c2.y - c1.y ),
								c1.z + t * ( c2.z - c1.z ),
								c1.w + t * ( c2.w - c1.w ) );
		return ImGui::ColorConvertFloat4ToU32( lerped );
}

void evo::render_t::add_gradient_circle_filled( evo::vec2_t c, int radius, evo::col_t inner_color, evo::col_t outer_color ) {
	for ( int i = 0; i <= radius; ++i ) {
		float t = static_cast< float >( i ) / radius;
		ImU32 color = ImGui::GetColorU32( lerp_color( inner_color.convert( ), outer_color.convert( ), t ) );
		ext_draw_list->AddCircleFilled( evo::macros::vec_t( c.x, c.y ), static_cast< float >( i ), color );
	}
}

void evo::render_t::add_gradient_vertical( int x, int y, int w, int h, evo::col_t c1, evo::col_t c2, int rounding, ImDrawFlags flags ) {
	if ( rounding != 0 ) {
		ext_draw_list->AddRectFilledMultiColorRounded( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), _container->elem_back.convert(), c1.convert( ), c2.convert( ), c2.convert( ), c1.convert( ), rounding , flags);

	} else {
		ext_draw_list->AddRectFilledMultiColor( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), c1.convert( ), c2.convert( ), c2.convert( ), c1.convert( ) );
	}

}

void evo::render_t::add_gradient_horizontal( int x, int y, int w, int h, evo::col_t c1, evo::col_t c2, int rounding, ImDrawFlags flags ) {
	if ( rounding != 0 ) {
		ext_draw_list->AddRectFilledMultiColorRounded( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), _container->elem_back.convert( ), c1.convert( ), c1.convert( ), c2.convert( ), c2.convert( ), rounding, flags );
	} else {
		ext_draw_list->AddRectFilledMultiColor( evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), c1.convert( ), c1.convert( ), c2.convert( ), c2.convert( ) );
	}
}

void evo::render_t::add_drop_shadow( int x, int y, int w, int h, evo::col_t main_col, int size, int alpha_a ) {
	this->add_gradient_horizontal( x, y - size, w, size, main_col.modify_alpha( 0 ), main_col.modify_alpha( alpha_a ) );
	this->add_gradient_horizontal( x, y + h, w, size, main_col.modify_alpha( alpha_a ), main_col.modify_alpha( 0 ) );

	this->add_gradient_vertical( x - size, y, size, h, main_col.modify_alpha( 0 ), main_col.modify_alpha( alpha_a ) );
	this->add_gradient_vertical( x + w, y, size, h, main_col.modify_alpha( alpha_a ), main_col.modify_alpha( 0 ) );

}

void evo::render_t::add_image( int x, int y, int w, int h, evo::macros::texture_id user_texture_id, evo::col_t c ) {
	ext_draw_list->AddImage( user_texture_id, evo::macros::vec_t( x, y ), evo::macros::vec_t( x + w, y + h ), ImVec2( 0, 0 ), ImVec2( 1, 1 ), c.convert( ) );
}

void evo::render_t::bind_animation( int id, std::string text, evo::col_t color, int font, int x, int y, text_animation_t animation_type ) { 
	static int animation_[ 1000 ]; /* iterate */
	
	int w_of_text = this->text_size( text.c_str( ), font ).x;
	int h_of_text = this->text_size( text.c_str( ), font ).y;
	
	switch ( animation_type ) {
		case text_animation_t::left_to_right: {	
			auto animation = animation_controller.get( text + std::to_string( id ) + animation_controller.current_child );
			animation.adjust( animation.value + 3.f * animation_controller.get_min_deltatime( 0.025f ) * ( ( animation_[ id ] < w_of_text ) ? 1.f : -1.f ) );

			if ( animation.value >= 0.99f ) {
				animation_[ id ] = w_of_text;
			} else if ( animation.value <= 0.f ) {
				animation_[ id ] = 0;
			}
			
			this->clip_rect( x, y, w_of_text * animation.value, h_of_text, [ & ]( ) {
				this->add_text( x, y, color, font, text.c_str( ) );
			} );
		} break;
		case text_animation_t::middle_pulse: {
			auto animation = animation_controller.get( text + std::to_string( id ) + animation_controller.current_child );
			animation.adjust( animation.value + 3.f * animation_controller.get_min_deltatime( 0.025f ) * ( ( animation_[ id ] < w_of_text ) ? 1.f : -1.f ) );

			if ( animation.value >= 0.99f ) {
				animation_[ id ] = w_of_text;
			} else if ( animation.value <= 0.f ) {
				animation_[ id ] = 0;
			}

			this->clip_rect( x + ( w_of_text / 2 ) - ( ( ( w_of_text * 2 ) / 2 ) * ( animation.value / 2 ) ), y, 
							 ( ( w_of_text * 2 ) / 2 ) * animation.value, h_of_text, [ & ]( ) {
				this->add_text( x, y, color, font, text.c_str( ) );
			} );
		} break;
		case text_animation_t::tiny_color: {
			auto animation = animation_controller.get( text + std::to_string( id ) + animation_controller.current_child );
			animation.adjust( animation.value + 3.f * animation_controller.get_min_deltatime( 0.025f ) * ( ( animation_[ id ] < w_of_text ) ? 1.f : -1.f ) );

			if ( animation.value >= 0.99f ) {
				animation_[ id ] = w_of_text;
			} else if ( animation.value <= 0.f ) {
				animation_[ id ] = 0;
			}

			this->clip_rect( ( x - 15 ) + ( w_of_text * animation.value ), y, 45, h_of_text, [ & ]( ) {
				this->add_text( x, y, color, font, text.c_str( ) );
			} );
		} break;
	}
}

void evo::render_t::clip_rect( float x, float y, float w, float h, std::function< void( ) > function ) {
	ext_draw_list->PushClipRect( { x, y }, { x + w, y + h }, true );

	function( );

	ext_draw_list->PopClipRect( );
}

void evo::external_macro_t::make_rect_filled( int x, int y, int w, int h, col_t c, int r, bool overwrite ) {
	if ( overwrite ) {
		externals::external.rect_filled_a.insert( externals::external.rect_filled_a.begin( ), externals::draw_rect( x, y, w, h, c, r ) );
	} else {
		externals::external.rect_filled.insert( externals::external.rect_filled.begin( ), externals::draw_rect( x, y, w, h, c, r ) );
	}
}

void evo::external_macro_t::make_rect_filledex( int x, int y, int w, int h, col_t c, int r, bool overwrite ) {
	if ( overwrite ) {
		externals::external.rect_filled_a2.insert( externals::external.rect_filled_a2.begin( ), externals::draw_rect( x, y, w, h, c, r ) );
	} else {
		externals::external.rect_filled.insert( externals::external.rect_filled.begin( ), externals::draw_rect( x, y, w, h, c, r ) );
	}
}

void evo::external_macro_t::make_rect( int x, int y, int w, int h, col_t c, int r, int t, bool overwrite ) {
	if ( overwrite ) {
		externals::external.rect_a.insert( externals::external.rect_a.begin( ), externals::draw_thick_rect( x, y, w, h, c, r, t ) );
	} else {
		externals::external.rect.insert( externals::external.rect.begin( ), externals::draw_thick_rect( x, y, w, h, c, r, t ) );
	}
}

void evo::external_macro_t::make_text( int x, int y, col_t c, int fi, std::string text, font_flags_t flags ) {
	externals::external.text.insert( externals::external.text.begin( ), externals::draw_text( x, y, text, c, fi, flags ) );
}

void evo::external_macro_t::make_rect_filled_shadow( int x, int y, int w, int h, col_t c, int r, int s, bool overwrite ) {
	if ( overwrite ) {
		externals::external.rect_filled_shd_a.insert( externals::external.rect_filled_shd_a.begin( ), externals::draw_rect_shd( x, y, w, h, c, r, s ) );
	} else {
		externals::external.rect_filled_shd.insert( externals::external.rect_filled_shd.begin( ), externals::draw_rect_shd( x, y, w, h, c, r, s ) );
	}
}
