#pragma once
#include "../includes.hpp"

namespace ams {
	struct entity_cache_data_t {
		ams::player_controller_t* controller;
		ams::player_pawn_t* pawn;

		entity_cache_data_t( ams::player_controller_t* controller, ams::player_pawn_t* pawn ) {
			this->controller = controller;
			this->pawn = pawn;
		}
	};

	// main namespace
	namespace game {
		inline ams::player_controller_t* local_controller = nullptr;
		inline ams::player_pawn_t* local_pawn = nullptr;

		inline std::vector <entity_cache_data_t> entity_data;
		inline evo::view_matrix_t screen_matrix;

        inline std::string id_to_icon( int index ) {
            switch ( index ) {
                case 0: return ( "" );
                case 1: return ( "A" );
                case 2: return ( "B" );
                case 3: return ( "C" );
                case 4: return ( "D" );
                case 7: return ( "W" );
                case 8: return ( "U" );
                case 9: return ( "Z" );
                case 10: return ( "R" );
                case 11: return ( "X" );
                case 13: return ( "Q" );
                case 14: return ( "a" );
                case 16: return ( "S" );
                case 17: return ( "K" );
                case 19: return ( "P" );
                case 23: return ( "?" );
                case 24: return ( "L" );
                case 25: return ( "\\" );
                case 26: return ( "M" );
                case 27: return ( "^" );
                case 28: return ( "`" );
                case 29: return ( "]" );
                case 30: return ( "H" );
                case 31: return ( "b" );
                case 32: return ( "E" );
                case 33: return ( "N" );
                case 34: return ( "O" );
                case 35: return ( "_" );
                case 36: return ( "F" );
                case 37: return ( "\"" );
                case 38: return ( "Y" );
                case 39: return ( "V" );
                case 40: return ( "[" );
                case 41: return ( "" );
                case 42: return ( ">" );
                case 43: return ( "c" );
                case 44: return ( "d" );
                case 45: return ( "e" );
                case 46: return ( "f" );
                case 47: return ( "&" );
                case 48: return ( "%" );
                case 49: return ( "$" );
                case 57: return ( "q" );
                case 59: return ( ":" );
                case 60: return ( "T" );
                case 61: return ( "G" );
                case 63: return ( "I" );
                case 64: return ( "J" );
                case 68: return ( "t" );
                case 69: return ( "" );
                case 70: return ( "u" );
                case 72: return ( "#" );
                case 74: return ( "s" );
                case 75: return ( "" );
                case 76: return ( "p" );
                case 78: return ( "" );
                case 80: return ( "1" );
                case 81: return ( "f" );
                case 82: return ( "" );
                case 83: return ( "d" );
                case 84: return ( "r" );
                case 85: return ( "l" );
                case 500: return ( "g" );
                case 503: return ( "/" );
                case 505: return ( "1" );
                case 506: return ( "2" );
                case 507: return ( "4" );
                case 508: return ( "6" );
                case 509: return ( ";" );
                case 512: return ( "0" );
                case 514: return ( "9" );
                case 515: return ( "<" );
                case 516: return ( "@" );
                case 517: return ( "." );
                case 518: return ( "-" );
                case 519: return ( "." );
                case 520: return ( "3" );
                case 521: return ( "6" );
                case 522: return ( "8" );
                case 523: return ( "=" );
                case 525: return ( "7" );
                case 5027: return ( "" );
                case 5028: return ( "" );
                case 5029: return ( "" );
                case 5030: return ( "" );
                case 5031: return ( "" );
                case 5032: return ( "" );
                case 5033: return ( "" );
                case 5034: return ( "" );
                case 5035: return ( "" );
                default: return ( "" );
            }
        }
	}

	// class. 
	class game_data_t {
	public:
		void cache_entity( );
		void cache_aimbot( std::vector < entity_cache_data_t >& vec_sie );
	};

	share_class( _game, game_data_t );
}