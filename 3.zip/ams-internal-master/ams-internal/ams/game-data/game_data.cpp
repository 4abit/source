#include "game_data.hpp"

// sort type
enum sort_entity_type : int {
	sort_entity_none = -1,
	sort_entity_player = 0,
};

struct sort_entity_object_t {
    sort_entity_object_t( ams::base_entity_t* m_entity, CBaseHandle h_entity,sort_entity_type m_sort ) :
        m_entity( m_entity ), h_entity( h_entity ), m_sort( m_sort ) { }

    ams::base_entity_t* m_entity;
    CBaseHandle h_entity;
    sort_entity_type m_sort;
};

void ams::game_data_t::cache_entity( ) { 
    game::entity_data.clear( );

    // max enitity index
    const int m_highest_index = ams::resource_services->m_game_entity_system->get_highest_index( );

    // sorted entities
    std::vector<sort_entity_object_t> m_sorted_entities = {};

    // reserve size
    m_sorted_entities.reserve( m_highest_index );

    // iterate
    for ( int m_index = 1; m_index < m_highest_index; m_index++ ) {
        ams::base_entity_t* m_entity = ams::resource_services->m_game_entity_system->construct( m_index );
        if ( m_entity == nullptr ) {
            continue;
        }

        // class info.
        schema_class_info_data_t* m_class_info;
        m_entity->get_schema_class_info( &m_class_info );
        if ( m_class_info == nullptr ) {
            continue;
        }

        // hashed name.
        const FNV1A_t m_hashed_name = FNV1A::Hash( m_class_info->m_name );

        // vars.
        sort_entity_type m_entity_type = sort_entity_type::sort_entity_none;
     
        // stuff.
        if ( m_hashed_name == FNV1A::HashConst( "CCSPlayerController" ) ) {
            m_entity_type = sort_entity_type::sort_entity_player;
            ams::player_controller_t* m_player = reinterpret_cast< ams::player_controller_t* >( m_entity );
            if ( m_player == nullptr ) {
                continue;
            }
        }

        // only add sortable entities
        if ( m_entity_type != sort_entity_type::sort_entity_none )
            m_sorted_entities.emplace_back( m_entity, m_entity->get_reference_handle( ), m_entity_type );
    }

    for ( auto& [m_entity, h_entity, m_sort_type] : m_sorted_entities ) {
        // handle invalid skip
        if ( !h_entity.IsValid( ) )
            continue;

        // swithc cases
        switch ( m_sort_type ) {
            case sort_entity_type::sort_entity_player:
            {
                ams::player_controller_t* m_player = ams::resource_services->m_game_entity_system->construct<ams::player_controller_t>( h_entity );
                if ( m_player == nullptr ) {
                    break;
                }

                if ( !m_player->alive_pawn( ) ) {
                    break;
                }

                ams::player_pawn_t* player = ams::resource_services->m_game_entity_system->construct<ams::player_pawn_t>( m_player->get_pawn_handle( ) );
                if ( !player ) {
                    continue;
                }

                if ( player->get_health( ) <= 0 || !game::local_pawn->enemy( player ) ) {
                    continue;
                }

                // push data
                // entity_cache_data_t( controller / pawn );
                game::entity_data.emplace_back( ams::entity_cache_data_t( m_player, player ) );
            } break;

            // break default.
            default:
                break;
        }
    }
}

void ams::game_data_t::cache_aimbot( std::vector<entity_cache_data_t>& vec_sie ) {
    // max enitity index
    const int m_highest_index = ams::resource_services->m_game_entity_system->get_highest_index( );

    // sorted entities
    std::vector<sort_entity_object_t> m_sorted_entities = {};

    // reserve size
    m_sorted_entities.reserve( m_highest_index );

    // iterate
    for ( int m_index = 1; m_index < m_highest_index; m_index++ ) {
        ams::base_entity_t* m_entity = ams::resource_services->m_game_entity_system->construct( m_index );
        if ( m_entity == nullptr ) {
            continue;
        }

        // class info.
        schema_class_info_data_t* m_class_info;
        m_entity->get_schema_class_info( &m_class_info );
        if ( m_class_info == nullptr ) {
            continue;
        }

        // hashed name.
        const FNV1A_t m_hashed_name = FNV1A::Hash( m_class_info->m_name );

        // vars.
        sort_entity_type m_entity_type = sort_entity_type::sort_entity_none;

        // stuff.
        if ( m_hashed_name == FNV1A::HashConst( "CCSPlayerController" ) ) {
            m_entity_type = sort_entity_type::sort_entity_player;
            ams::player_controller_t* m_player = reinterpret_cast< ams::player_controller_t* >( m_entity );
            if ( m_player == nullptr ) {
                continue;
            }
        }

        // only add sortable entities
        if ( m_entity_type != sort_entity_type::sort_entity_none )
            m_sorted_entities.emplace_back( m_entity, m_entity->get_reference_handle( ), m_entity_type );
    }

    for ( auto& [m_entity, h_entity, m_sort_type] : m_sorted_entities ) {
        // handle invalid skip
        if ( !h_entity.IsValid( ) )
            continue;

        // swithc cases
        switch ( m_sort_type ) {
            case sort_entity_type::sort_entity_player:
            {
                ams::player_controller_t* m_player = ams::resource_services->m_game_entity_system->construct<ams::player_controller_t>( h_entity );
                if ( m_player == nullptr ) {
                    break;
                }

                if ( !m_player->alive_pawn( ) ) {
                    break;
                }

                ams::player_pawn_t* player = ams::resource_services->m_game_entity_system->construct<ams::player_pawn_t>( m_player->get_pawn_handle( ) );
                if ( !player ) {
                    continue;
                }

                if ( player->get_health( ) <= 0 || !game::local_pawn->enemy( player ) ) {
                    continue;
                }

                // push data
                // entity_cache_data_t( controller / pawn );
                vec_sie.emplace_back( ams::entity_cache_data_t( m_player, player ) );
            } break;

            // break default.
            default:
                break;
        }
    }
}
