#include "includes.hpp"
#include "hooks/hooks.hpp"
#include "thirdparty/minhook/minhook.h"
#include "hacks/chams/chams.hpp"

// initialize 
DWORD WINAPI initialize_hack( void* instance ) {
	[ & ]( ) { // initialize console.
		// alloc console.
		AllocConsole( );

		// redirect standard input, output, and error streams to the console.
		freopen_s( reinterpret_cast< FILE** >( stdin ), "conin$", "r", stdin );
		freopen_s( reinterpret_cast< FILE** >( stdout ), "conout$", "w", stdout );
		freopen_s( reinterpret_cast< FILE** >( stderr ), "conout$", "w", stderr );

		// set the console title.
		SetConsoleTitle( "amnesia cs2-internal" );
	}( );

	[ & ]( ) {
		MH_Initialize( );
		log_success( "initialized minhook." );
	}( );

	// init hack now brother.
	ams::_interfaces->create_interfaces( );

	// init schema.
	if ( !ams::schema::construct_schema( L"schema_dump.txt" ) ) {
		log_error( "failed to construct schema!" );

		return false;
	}

	// create dx after schema, we have to prioritize it
	ams::_hooks->create_hooks( );
	ams::_hooks->create_directx( );

	// init chams.
	ams::_chams->initialize( );

	// enable hooks.
	[ & ]( ) {
		MH_EnableHook( MH_ALL_HOOKS );
		log_success( "hooked everything succesfully." );
	}( );

	// stuff.
	while ( !GetAsyncKeyState( VK_END ) ) {
		std::this_thread::sleep_for( std::chrono::milliseconds( 50 ) );
	}

	std::this_thread::sleep_for( std::chrono::milliseconds( 250 ) );
	FreeLibraryAndExitThread( static_cast< HMODULE >( instance ), 0 );

	// return value.
	return TRUE;
}

// release 
DWORD WINAPI release( ) {
	// reset wndproc
	SetWindowLongPtrA( ams::window, GWLP_WNDPROC, LONG_PTR( ams::wndproc::original ) );

	// destroy hooks.
	ams::_hooks->destroy_hooks( );

	// unitialize hooks
	if ( MH_Uninitialize( ) == MH_STATUS::MH_OK ) {
		log_success( "uninitialized hooks" );
	}

	// log this.
	log_success( "cheat unitialized!" );

	// clear console.
	FreeConsole( );

	// return value.
	return TRUE;
}

// c_runtime.
BOOL WINAPI DllMain( HINSTANCE instance, DWORD call_reason, void* reserved ) {
	switch ( call_reason ) {
		case DLL_PROCESS_ATTACH:
			if ( HANDLE handle = CreateThread( nullptr, 0, initialize_hack, instance, 0, nullptr ) ) {
				CloseHandle( handle );
			}
			break;

		case DLL_PROCESS_DETACH:
			release( );
			break;

		default:
			break;
	}

	return TRUE;
}