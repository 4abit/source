#pragma once
#include "../../includes.hpp"

namespace ams {
	class chams_t {
	public:
		bool initialize( );
		void destroy( );
	public:
		bool draw_object( void* animatable_object, void* dx11, material_data_t* arr_material_data, int data_count,
						  void* scene_view, void* scene_layer, void* unk1, void* unk2 );

		bool override_material( void* animatable_object, void* dx11, material_data_t* arr_material_data, int data_count,
								void* scene_view, void* scene_layer, void* unk1, void* unk2 );
	private:
		bool m_initialized = false;
	};

	share_class( _chams, chams_t );
}