#include "chams.hpp"
#include "../../game-data/game_data.hpp"
#include "../../hooks/hooks.hpp"

// custom material
struct custom_material_data_t {
	ams::material2_t* m_material;
	ams::material2_t* m_material_z;
};

// material list.
enum material_list_t {
	material_white,
	material_default,
	material_illum,
	material_size
};

// array
static custom_material_data_t array_materials[ material_size ]; // material max

#include "../../utils/other/stronghandle.hpp"
ams::material2_t* create_material_default_visible( const char* m_name ) {
	const char szVmatBuffer[ ] = R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
    shader = "csgo_complex.vfx"
    F_PAINT_VERTEX_COLORS = 1
    F_TRANSLUCENT = 1
    
    g_vColorTint = [1, 1, 1, 1]
    TextureAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tColor = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tNormal = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tTintMask = resource:"materials/default/default_mask_tga_fde710a5.vtex"

})";

	auto buffer = new unsigned char[ 0x100 + sizeof( ams::key_values3_t ) ];
	CRT::MemorySet( buffer, 0, sizeof( buffer ) );
	ams::key_values3_t* kv3 = ( ams::key_values3_t* )( buffer + 0x100 );

	ams::kv3_id_t kv3ID;
	kv3ID.szName = "generic";
	kv3ID.unk0 = 0x469806E97412167C;
	kv3ID.unk1 = 0xE73790B53EE6F2AF;

	if ( !ams::load_key_value( kv3, nullptr, szVmatBuffer, &kv3ID, nullptr ) )
		throw;

	ams::material2_t** custom_material;
	ams::fn_create_material( nullptr, &custom_material, m_name, kv3, 0, 1 );

	return *custom_material;
}
ams::material2_t* create_material_default_invisible( const char* m_name ) {
	const char szVmatBuffer[ ] = R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
    shader = "csgo_complex.vfx"
    F_PAINT_VERTEX_COLORS = 1
    F_TRANSLUCENT = 1
    F_DISABLE_Z_BUFFERING = 1
    
    g_vColorTint = [1, 1, 1, 1]
    TextureAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tColor = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tNormal = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tTintMask = resource:"materials/default/default_mask_tga_fde710a5.vtex"

})";

	auto buffer = new unsigned char[ 0x100 + sizeof( ams::key_values3_t ) ];
	CRT::MemorySet( buffer, 0, sizeof( buffer ) );
	ams::key_values3_t* kv3 = ( ams::key_values3_t* )( buffer + 0x100 );

	ams::kv3_id_t kv3ID;
	kv3ID.szName = "generic";
	kv3ID.unk0 = 0x469806E97412167C;
	kv3ID.unk1 = 0xE73790B53EE6F2AF;

	if ( !ams::load_key_value( kv3, nullptr, szVmatBuffer, &kv3ID, nullptr ) )
		throw;

	ams::material2_t** custom_material;
	ams::fn_create_material( nullptr, &custom_material, m_name, kv3, 0, 1 );

	return *custom_material;
}
ams::material2_t* create_material_flat_visible( const char* m_name ) {
	const char szVmatBuffer[ ] = R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	shader = "csgo_unlitgeneric.vfx"
	F_PAINT_VERTEX_COLORS = 1
	F_TRANSLUCENT = 1
	F_BLEND_MODE = 1

	g_vColorTint = [1, 1, 1, 1]
	TextureAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tColor = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tNormal = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tTintMask = resource:"materials/default/default_mask_tga_fde710a5.vtex"

})";

	auto buffer = new unsigned char[ 0x100 + sizeof( ams::key_values3_t ) ];
	CRT::MemorySet( buffer, 0, sizeof( buffer ) );
	ams::key_values3_t* kv3 = ( ams::key_values3_t* )( buffer + 0x100 );

	ams::kv3_id_t kv3ID;
	kv3ID.szName = "generic";
	kv3ID.unk0 = 0x469806E97412167C;
	kv3ID.unk1 = 0xE73790B53EE6F2AF;

	if ( !ams::load_key_value( kv3, nullptr, szVmatBuffer, &kv3ID, nullptr ) )
		throw;

	ams::material2_t** custom_material;
	ams::fn_create_material( nullptr, &custom_material, m_name, kv3, 0, 1 );

	return *custom_material;
}
ams::material2_t* create_material_flat_invisible( const char* m_name ) {
	const char szVmatBuffer[ ] = R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	shader = "csgo_unlitgeneric.vfx"
	F_PAINT_VERTEX_COLORS = 1
	F_TRANSLUCENT = 1
	F_BLEND_MODE = 1
    F_DISABLE_Z_BUFFERING = 1

	g_vColorTint = [1, 1, 1, 1]
	TextureAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tAmbientOcclusion = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tColor = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tNormal = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tTintMask = resource:"materials/default/default_mask_tga_fde710a5.vtex"

})";

	auto buffer = new unsigned char[ 0x100 + sizeof( ams::key_values3_t ) ];
	CRT::MemorySet( buffer, 0, sizeof( buffer ) );
	ams::key_values3_t* kv3 = ( ams::key_values3_t* )( buffer + 0x100 );

	ams::kv3_id_t kv3ID;
	kv3ID.szName = "generic";
	kv3ID.unk0 = 0x469806E97412167C;
	kv3ID.unk1 = 0xE73790B53EE6F2AF;

	if ( !ams::load_key_value( kv3, nullptr, szVmatBuffer, &kv3ID, nullptr ) )
		throw;

	ams::material2_t** custom_material;
	ams::fn_create_material( nullptr, &custom_material, m_name, kv3, 0, 1 );

	return *custom_material;
}
ams::material2_t* create_material_illum_visible( const char* m_name ) {
	const char szVmatBuffer[ ] = R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
     shader = "csgo_complex.vfx"
 
    g_tColor = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tNormal = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tSelfIllumMask = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    TextureAmbientOcclusion = resource:"materials/debug/particleerror.vtex"
    g_tAmbientOcclusion = resource:"materials/debug/particleerror.vtex"
    
    g_vColorTint = [ 20.000000, 20.000000, 20.000000, 20.000000 ]
    g_flSelfIllumScale = [ 5.000000, 5.000000, 5.000000, 5.000000 ]
    g_flSelfIllumBrightness = [ 5.000000, 5.000000, 5.000000, 5.000000 ]
    g_vSelfIllumTint = [ 10.000000, 10.000000, 10.000000, 10.000000 ]

    F_SELF_ILLUM = 1
    
    F_PAINT_VERTEX_COLORS = 1

    F_TRANSLUCENT = 1

})";

	auto buffer = new unsigned char[ 0x100 + sizeof( ams::key_values3_t ) ];
	CRT::MemorySet( buffer, 0, sizeof( buffer ) );
	ams::key_values3_t* kv3 = ( ams::key_values3_t* )( buffer + 0x100 );

	ams::kv3_id_t kv3ID;
	kv3ID.szName = "generic";
	kv3ID.unk0 = 0x469806E97412167C;
	kv3ID.unk1 = 0xE73790B53EE6F2AF;

	if ( !ams::load_key_value( kv3, nullptr, szVmatBuffer, &kv3ID, nullptr ) )
		throw;

	ams::material2_t** custom_material;
	ams::fn_create_material( nullptr, &custom_material, m_name, kv3, 0, 1 );

	return *custom_material;
}
ams::material2_t* create_material_illum_invisible( const char* m_name ) {
	const char szVmatBuffer[ ] = R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
     shader = "csgo_complex.vfx"
 
    g_tColor = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tNormal = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    g_tSelfIllumMask = resource:"materials/default/default_mask_tga_fde710a5.vtex"
    TextureAmbientOcclusion = resource:"materials/debug/particleerror.vtex"
    g_tAmbientOcclusion = resource:"materials/debug/particleerror.vtex"
    
    g_vColorTint = [ 20.000000, 20.000000, 20.000000, 20.000000 ]
    g_flSelfIllumScale = [ 5.000000, 5.000000, 5.000000, 5.000000 ]
    g_flSelfIllumBrightness = [ 5.000000, 5.000000, 5.000000, 5.000000 ]
    g_vSelfIllumTint = [ 10.000000, 10.000000, 10.000000, 10.000000 ]

    F_SELF_ILLUM = 1
    
    F_PAINT_VERTEX_COLORS = 1

    F_TRANSLUCENT = 1

    F_DISABLE_Z_BUFFERING = 1

})";

	auto buffer = new unsigned char[ 0x100 + sizeof( ams::key_values3_t ) ];
	CRT::MemorySet( buffer, 0, sizeof( buffer ) );
	ams::key_values3_t* kv3 = ( ams::key_values3_t* )( buffer + 0x100 );

	ams::kv3_id_t kv3ID;
	kv3ID.szName = "generic";
	kv3ID.unk0 = 0x469806E97412167C;
	kv3ID.unk1 = 0xE73790B53EE6F2AF;

	if ( !ams::load_key_value( kv3, nullptr, szVmatBuffer, &kv3ID, nullptr ) )
		throw;

	ams::material2_t** custom_material;
	ams::fn_create_material( nullptr, &custom_material, m_name, kv3, 0, 1 );

	return *custom_material;
}

// other functions.
bool ams::chams_t::initialize( ) {
	// first we have to check if this shit is alr initialized
	if ( this->m_initialized ) {
		return this->m_initialized;
	}

	// only initialize this for moment, later we're gonna init more
	array_materials[ material_list_t::material_white ] = custom_material_data_t{
		.m_material = create_material_flat_visible( "materials/dev/primary_white.vmat" ),
		.m_material_z = create_material_flat_invisible( "materials/dev/primary_white.vmat" ),
	};

	array_materials[ material_list_t::material_default ] = custom_material_data_t{
		.m_material = create_material_default_visible( "materials/dev/primary_white.vmat" ),
		.m_material_z = create_material_default_invisible( "materials/dev/primary_white.vmat" ),
	};

	array_materials[ material_list_t::material_illum ] = custom_material_data_t{
		.m_material = create_material_illum_visible( "materials/dev/primary_white.vmat" ),
		.m_material_z = create_material_illum_invisible( "materials/dev/primary_white.vmat" ),
	};

	// we initialized by now
	this->m_initialized = true;

	// iterate.
	for ( auto& [m_visible, m_invisible] : array_materials ) {
		if ( m_visible == nullptr || m_invisible == nullptr )
			this->m_initialized = false;
	}

	// finish and return value
	return this->m_initialized;
}

void ams::chams_t::destroy( ) { 
	// nothing to destroy boss
}

bool ams::chams_t::draw_object( void* animatable_object, void* dx11, material_data_t* arr_material_data, int data_count, 
								void* scene_view, void* scene_layer, void* unk1, void* unk2 ) {
	// check if we initialized.
	if ( !this->m_initialized ) {
		return false;
	}

	// no chams enable.
	// return false
	if ( !_cfg->bool_elem[ bool_features::enemy_chams ] )
		return false;

	// no data on material
	if ( arr_material_data == nullptr ) {
		return false;
	}

	// no data on scene object.
	if ( arr_material_data->m_scene_animable == nullptr ) {
		return false;
	}

	// owner.
	CBaseHandle m_owner = arr_material_data->m_scene_animable->m_owner;

	// get entity.
	auto m_entity = ams::resource_services->m_game_entity_system->construct< base_entity_t >( m_owner );
	if ( m_entity == nullptr ) {
		return false;
	}
		
	// schema info
	schema_class_info_data_t* m_class_info;
	m_entity->get_schema_class_info( &m_class_info );
	if ( m_class_info == nullptr ) {
		return false;
	}

	// compare string.
	if ( CRT::StringCompare( m_class_info->m_name, CS_XOR( "C_CSPlayerPawn" ) ) != 0 )
		return false;

	// get pawn.
	auto m_pawn = ams::resource_services->m_game_entity_system->construct< player_pawn_t>( m_owner );
	if ( m_pawn == nullptr ) {
		return false;
	}
		
	// other entity
	if ( !m_pawn->enemy( game::local_pawn ) ) {
		return false;
	}

	// it is alive
	if ( m_pawn->get_health( ) <= 0 ) {
		return false;
	}

	// we passed to everythign.
	// please render material.
	return this->override_material( animatable_object, dx11, arr_material_data, data_count,
									scene_view, scene_layer, unk1, unk2 );
}

bool ams::chams_t::override_material( void* animatable_object, void* dx11, material_data_t* arr_material_data, int data_count, 
									  void* scene_view, void* scene_layer, void* unk1, void* unk2 ) {
	auto original = ams::draw_object::shared_hook.get_original<void( __fastcall* )
		( void*, void*, material_data_t*, int, void*, void*, void*, void* )>( );

	const custom_material_data_t custom_material = array_materials[ _cfg->int_elem[ int_features::material_type ] ];

	if ( _cfg->bool_elem[ bool_features::enemy_xyz_chams ] ) {
		arr_material_data->m_material = custom_material.m_material_z;
		ams::material_system->set_color( arr_material_data, _cfg->color_elem[ color_featues::chams_color_invis ] );
		original( animatable_object, dx11, arr_material_data, data_count, scene_view, scene_layer, unk1, unk2 );
	}

	arr_material_data->m_material = custom_material.m_material;
	ams::material_system->set_color( arr_material_data, _cfg->color_elem[ color_featues::chams_color_vis ] );
	original( animatable_object, dx11, arr_material_data, data_count, scene_view, scene_layer, unk1, unk2 );

	// passed succesfully
	return true;
}