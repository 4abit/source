#pragma once
#include "../../includes.hpp"

namespace ams {
    struct autowall_data_t {
        autowall_data_t( ) = default;

        autowall_data_t( bool & m_bIsTracingPlayer, float& m_flDamageLogger, float& flDamage, ams::weapon_data_t* const pWeaponData, ams::player_pawn_t* const pLocal, ams::player_pawn_t* const pTarget ) noexcept
            : m_bIsTracingPlayer( m_bIsTracingPlayer), m_flDamageLogger( m_flDamageLogger ), m_flDamage( flDamage ), m_pWeaponData( pWeaponData ), m_pLocal( pLocal ), m_pTarget( pTarget ) { }

        bool m_bIsTracingPlayer = false;
        float m_flDamage = 0.0f, m_flDamageLogger = 0.0f;
        ams::weapon_data_t* m_pWeaponData = nullptr;
        ams::player_pawn_t* m_pLocal = nullptr;
        ams::player_pawn_t* m_pTarget = nullptr;
    };

    struct HandleBulletData_t {
        HandleBulletData_t( const float flDamageMod, const float flPenetration, const float flRangeMod, const float flRange, const int nPenetrationCount, const bool bFailed ) :
            m_flDamage( flDamageMod ), m_flPenetration( flPenetration ), m_flRangeMod( flRangeMod ), m_flRange( flRange ), m_nPenetrationCount( nPenetrationCount ), m_bFailed( bFailed ) { }

        float m_flDamage;
        float m_flPenetration;
        float m_flRangeMod;
        float m_flRange;
        int m_nPenetrationCount;
        bool m_bFailed;
    };

    namespace autowall {
        // client.dll: 48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 40 F2 0F 10 02
        __forceinline static void CreateTrace( ams::trace_data_t* const pTraceData, const evo::vec3_t vecStart, const evo::vec3_t vecEnd, const ams::trace_filter_t& pFilter, const int nPenetrationCount ) {
            using fnCreateTrace = void( __fastcall* )( ams::trace_data_t*, evo::vec3_t, evo::vec3_t, trace_filter_t, void*, void*, void*, void*, int );
            static const fnCreateTrace oCreateTrace = reinterpret_cast< fnCreateTrace >( memory::find_pattern( L"client.dll", ( "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 40 F2 0F 10 02" ) ) );

#ifdef CS_PARANOID
            CS_ASSERT( oCreateTrace != nullptr );
#endif

            return oCreateTrace( pTraceData, vecStart, vecEnd, pFilter, nullptr, nullptr, nullptr, nullptr, nPenetrationCount );
        }

        // client.dll: 48 89 5C 24 08 57 48 83 EC 20 48 8B D9 33 FF 48 8B 0D
        __forceinline static void InitTraceInfo( game_trace_t* const pTrace ) {
            using fnInitTraceInfo = void( __fastcall* )( game_trace_t* );
            static const fnInitTraceInfo oInitTraceInfo = reinterpret_cast< fnInitTraceInfo >( memory::find_pattern( L"client.dll", ( "48 89 5C 24 08 57 48 83 EC 20 48 8B D9 33 FF 48 8B 0D" ) ) );

#ifdef CS_PARANOID
            CS_ASSERT( oInitTraceInfo != nullptr );
#endif

            return oInitTraceInfo( pTrace );
        }

        // client.dll: 48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 60 48 8B E9 0F
        __forceinline static void GetTraceInfo( ams::trace_data_t* const pTraceData, game_trace_t* const pTrace, const float flUnknownFloat, void* pUnknown ) {
            using fnGetTraceInfo = void( __fastcall* )( ams::trace_data_t*, game_trace_t*, float, void* );
            static const fnGetTraceInfo oGetTraceInfo = reinterpret_cast< fnGetTraceInfo >( memory::find_pattern( L"client.dll", ( "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 60 48 8B E9 0F" ) ) );

#ifdef CS_PARANOID
            CS_ASSERT( oGetTraceInfo != nullptr );
#endif

            return oGetTraceInfo( pTraceData, pTrace, flUnknownFloat, pUnknown );
        }

        // william: there is no need to rebuild this function.
        // client.dll; 48 8B C4 44 89 48 20 55 57 41 55
        __forceinline static bool HandleBulletPenetration( ams::trace_data_t* const pTraceData, void* pStats, update_value_t* const pModValue, const bool bDrawShowImpacts = false ) {
            using fnHandleBulletPenetration = bool( __fastcall* )( ams::trace_data_t*, void*, update_value_t*, void*, void*, void*, void*, void*, bool );
            static const fnHandleBulletPenetration oHandleBulletPenetration = reinterpret_cast< fnHandleBulletPenetration >( memory::find_pattern( L"client.dll", ( "48 8B C4 44 89 48 20 55 57 41 55" ) ) );

#ifdef CS_PARANOID
            CS_ASSERT( oHandleBulletPenetration != nullptr );
#endif

            return oHandleBulletPenetration( pTraceData, pStats, pModValue, nullptr, nullptr, nullptr, nullptr, nullptr, bDrawShowImpacts );
        }

        inline autowall_data_t m_data = autowall_data_t( );
        void scale_damage( const int nHitGroup, ams::player_pawn_t* pEntity );
        bool fire_bullet( const evo::vec3_t vecSource, const evo::vec3_t vecEnd );
    }

}