#include "penetration.hpp"
#include "../rage/rage.hpp"

void ams::autowall::scale_damage( const int nHitGroup, ams::player_pawn_t* pEntity ) { 
    static convar_t* mp_damage_scale_ct_head = ams::cvar->find_var(
        FNV1A::HashConst( "mp_damage_scale_ct_head" ) ),
        * mp_damage_scale_t_head = ams::cvar->find_var(
            FNV1A::HashConst( "mp_damage_scale_t_head" ) ),
        * mp_damage_scale_ct_body = ams::cvar->find_var(
            FNV1A::HashConst( "mp_damage_scale_ct_body" ) ),
        * mp_damage_scale_t_body = ams::cvar->find_var(
            FNV1A::HashConst( "mp_damage_scale_t_body" ) );

    const auto damage_scale_ct_head = mp_damage_scale_ct_head->m_value.fl,
        damage_scale_t_head = mp_damage_scale_t_head->m_value.fl,
        damage_scale_ct_body = mp_damage_scale_ct_body->m_value.fl,
        damage_scale_t_body = mp_damage_scale_t_body->m_value.fl;

    const bool bIsCT = pEntity->get_team( ) == 3;
    const bool bIsT = pEntity->get_team( ) == 2;

    float flHeadDamageScale = bIsCT ? damage_scale_ct_head : bIsT ? damage_scale_t_head : 1.0f;
    const float flBodyDamageScale = bIsCT ? damage_scale_ct_body : bIsT ? damage_scale_t_body : 1.0f;

    // william: magic values u can see here: ida: server.dll; F3 0F 10 35 ?? ?? ?? ?? 0F 29 7C 24 30 44 0F 29 44 24
    // xref: mp_heavybot_damage_reduction_scale
    const bool bHasHeavyArmor = ( pEntity->item_services( ) && pEntity->item_services( )->has_heavy_armor( ) );
    if ( bHasHeavyArmor )
        flHeadDamageScale *= 0.5f;

    // todo: mb missed some hitgroups, anyway this is a calculation of all important hitgroups
    switch ( nHitGroup ) {
        case e_hitgroups::hitgroup_head:
            m_data.m_flDamage *= m_data.m_pWeaponData->headshot_multiplier( ) * flHeadDamageScale;
            break;
        case e_hitgroups::hitgroup_chest:
        case e_hitgroups::hitgroup_left_arm:
        case e_hitgroups::hitgroup_right_arm:
        case e_hitgroups::hitgroup_neck:
            m_data.m_flDamage *= flBodyDamageScale;
            break;
        case e_hitgroups::hitgroup_stomach:
            m_data.m_flDamage *= 1.25f * flBodyDamageScale;
            break;
        case e_hitgroups::hitgroup_left_leg:
        case e_hitgroups::hitgroup_right_leg:
            m_data.m_flDamage *= 0.75f * flBodyDamageScale;
            break;
        default:
            break;
    }

    if ( !pEntity->is_armored( nHitGroup ) )
        return;

    float flHeavyArmorBonus = 1.0f;
    float flArmorBonus = 0.5f;
    float flArmorRatio = m_data.m_pWeaponData->armor_ratio( ) * 0.5f;

    if ( bHasHeavyArmor ) {
        flHeavyArmorBonus = 0.25f;
        flArmorBonus = 0.33f;
        flArmorRatio *= 0.20f;
    }

    float flDamageToHealth = m_data.m_flDamage * flArmorRatio;
    const float flDamageToArmor = ( m_data.m_flDamage - flDamageToHealth ) * ( flHeavyArmorBonus * flArmorBonus );

    if ( flDamageToArmor > static_cast< float >( pEntity->armor_value( ) ) )
        flDamageToHealth = m_data.m_flDamage - static_cast< float >( pEntity->armor_value( ) ) / flArmorBonus;

    m_data.m_flDamage = flDamageToHealth;
}

bool ams::autowall::fire_bullet( const evo::vec3_t vecSource, const evo::vec3_t vecEnd ) {
    autowall_data_t& data = m_data;

    // invlaid data.
    if ( data.m_pTarget == nullptr )
        return false;

    // invlaid data.
    if ( data.m_pLocal == nullptr )
        return false;

    // invlaid data.
    if ( data.m_pWeaponData == nullptr )
        return false;

    trace_data_t traceData = trace_data_t( );
    traceData.m_arr_pointer = &traceData.m_arr;

    const evo::vec3_t vecDirection = vecEnd - vecSource;
    const evo::vec3_t vecEndPos = vecDirection * data.m_pWeaponData->fl_range( );

    const trace_filter_t filter( 0x1C300B, data.m_pLocal, 3 ); // work?
    CreateTrace( &traceData, vecSource, vecEndPos, filter, 4 );

    HandleBulletData_t handleBulletData = HandleBulletData_t(
        static_cast< float >( data.m_pWeaponData->damage( ) ),
        data.m_pWeaponData->fl_penetration( ),
        data.m_pWeaponData->fl_range( ),
        data.m_pWeaponData->fl_range_modifier( ),
        4,
        false
    );

    // set default weapon range
    float flMaxRange = data.m_pWeaponData->fl_range( );

    // create trace length
    float flTraceLength = 0.0f;

    // set default damage
    data.m_flDamage = static_cast< float >( data.m_pWeaponData->damage( ) );

    // log.
    _rage->trace_damage = data.m_flDamage;

    if ( traceData.m_num_update > 0 ) {
        for ( int i = 0; i < traceData.m_num_update; i++ ) {
            flMaxRange -= flTraceLength;

            update_value_t* pValue = reinterpret_cast< update_value_t* const >( reinterpret_cast< std::uintptr_t >( traceData.m_pointer_update_value ) + i * sizeof( update_value_t ) );

            game_trace_t trace = game_trace_t( );
            InitTraceInfo( &trace );
            GetTraceInfo( &traceData, &trace, 0.0f, reinterpret_cast< void* >( reinterpret_cast< std::uintptr_t >( traceData.m_arr.data( ) ) + sizeof( trace_arr_element_t ) * ( pValue->m_handle_idx & ENT_ENTRY_MASK ) ) );

            flTraceLength += trace.m_fraction * flMaxRange;
            data.m_flDamage *= std::powf( data.m_pWeaponData->fl_range_modifier( ), flTraceLength / 500 );

            // log.
            _rage->trace_damage = data.m_flDamage;

            if ( trace.m_hit_entity && trace.m_hit_entity->get_reference_handle( ).GetEntryIndex( ) == data.m_pTarget->get_reference_handle( ).GetEntryIndex( ) ) {
                // we've got the player and we trace it
                data.m_bIsTracingPlayer = true;

                // damage data.
                if ( data.m_flDamage > 0.0f ) // huh?
                    scale_damage( trace.m_hitbox_data->m_hitgroup, trace.m_hit_entity );

                // log.
                _rage->trace_damage = data.m_flDamage;

                return true;
            } else {
                // we dont trace the player
                data.m_bIsTracingPlayer = false;

                // log.
                _rage->trace_damage = data.m_flDamage;
            }

            if ( HandleBulletPenetration( &traceData, &handleBulletData, pValue ) ) {
                // we dont trace the player.
                data.m_bIsTracingPlayer = false;

                // retrn/
                return false;
            }

            data.m_flDamage = handleBulletData.m_flDamage;

            // log.
            _rage->trace_damage = data.m_flDamage;
        }
    }

    // we dont trace the player.
    data.m_bIsTracingPlayer = false;

    // return.
    return false;
}
