#pragma once
#include "../../includes.hpp"
#include "../../game-data/game_data.hpp"

namespace ams {
	enum hitscan_mode_t {
		hitscan_normal,
		hitscan_lethal,
		hitscan_prefer
	};

	struct hitscan_t {
		hitscan_mode_t m_mode{};
		evo::vec3_t m_point{};
		int m_index{};
		bool m_can_pen{};

		// constructor
		hitscan_t( hitscan_mode_t m_mode, evo::vec3_t m_point, int m_index, bool m_can_pen ) {
			// preinit by args.
			this->m_mode = m_mode;
			this->m_point = m_point;
			this->m_index = m_index;
			this->m_can_pen = m_can_pen;
		}
	};

	class rage_t {
	private:
		bool autostop_internal( user_cmd_t* cmd, ams::player_pawn_t* target,
								ams::weapon_base_t* weapon, ams::weapon_data_t* weapon_data );
		
		bool hitchance( evo::vec3_t point, ams::player_pawn_t* target,
						ams::weapon_base_t* weapon, ams::weapon_data_t* weapon_data );

		void setup_hitscan_mode( ams::player_pawn_t* target );
		bool setup_hitbox_points( ams::player_pawn_t* target, std::vector< hitscan_t >& points );
		void get_best_hitbox_point( ams::player_pawn_t* target, evo::vec3_t& exit_point, evo::vec3_t& exit_pos );
		bool can_shot( );
		void init( );
	public:
		void run( user_cmd_t* cmd );
		void draw_targeted_point( );

		std::vector <entity_cache_data_t> m_target;
	private:
		bool is_tracing_player{ false };
		evo::vec3_t targeted_point{};

		hitscan_mode_t m_mode{};
		std::vector<hitscan_t> m_points{};

	public:
		float trace_damage{ 0.0f };
		bool ignored_by_damage{ false };
	};

	share_class( _rage, rage_t );
}