#include "rage.hpp"
#include "../penetration/penetration.hpp"

void ams::rage_t::init( ) {
	this->m_target.clear( );
}

void ams::rage_t::run( user_cmd_t* cmd ) {
	// no rage enabled
	if ( !_cfg->bool_elem[ bool_features::ragebot ] )
		return;

	this->init( );

	// do not run if local is dead or invalid
	if ( game::local_controller == nullptr || game::local_pawn == nullptr )
		return;

	// do not run if local is dead.
	if ( game::local_pawn->get_health( ) <= 0 )
		return;

	[ & ]( /* target selection */ ) {
		ams::_game->cache_aimbot( this->m_target );
	}( );

	auto weapon = game::local_pawn->clipping_weapon( );
	if ( weapon == nullptr )
		return;

	auto weapon_data = weapon->get_weapon_data( );
	if ( weapon_data == nullptr )
		return;

	// do not run.
	// this crashes when targets = 0
	// lets return if we have no targets
	if ( this->m_target.empty( ) )
		return;

	// we still got to use this :/
	auto can_see = [ & ]( player_pawn_t* enemy, player_pawn_t* local ) -> bool {
		if ( !enemy || enemy->get_health( ) <= 0 )
			return false;

		trace_filter_t filter( 0x1C3003, local, 3 );

		game_trace_t trace = {};
		ray_t ray = {};

		auto start_eye = local->get_eye_pos( );
		auto end_eye = enemy->get_eye_pos( );

		ams::engine_trace->trace_shape( ray, &start_eye, &end_eye, filter, trace );
		return trace.m_fraction > 0.97f;
		};

	// we can go and target aimbot 
	// get eye pos.
	auto local_pos = game::local_pawn->get_eye_pos( );

	// do not try if we cant shot
	if ( !this->can_shot( ) )
		return;

	if ( this->m_target.size( ) > 0 ) {
		for ( int i = 0; i < this->m_target.size( ); i++ ) {
			const auto& target = this->m_target[ i ];

			// main shit safety 
			if ( ( target.controller != nullptr ) && ( target.pawn != nullptr ) ) {
				// exit point data.
				evo::vec3_t exit_point;
				evo::vec3_t exit_pos;

				// autowall.
				static float traced_damage{};
				ams::autowall::m_data = ams::autowall_data_t( this->is_tracing_player, this->trace_damage, traced_damage, game::local_pawn->clipping_weapon( )->get_weapon_data( ),
															  game::local_pawn, target.pawn );

				this->get_best_hitbox_point( target.pawn, exit_point, exit_pos );

				// store it
				this->targeted_point = exit_pos;

				// knifebot fix.
				auto dist_to_player = game::local_pawn->scene_node( )->get_vec_origin( ).dist_to( target.pawn->scene_node( )->get_vec_origin( ) ) / 90;
				if ( _cfg->bool_elem[ bool_features::knifebot ] && ( weapon_data->weapon_type( ) == ams::weapon_type_t::weapon_type_knife ) &&
					 dist_to_player > 1 ) {
					// do not run with knife if we're to far from player
					// might work
					continue;
				} else if ( !_cfg->bool_elem[ bool_features::knifebot ] && ( weapon_data->weapon_type( ) == ams::weapon_type_t::weapon_type_knife ) ) {
					// do not run.
					continue;
				}

				// go for fire
				if ( ams::autowall::fire_bullet( local_pos, exit_pos ) ) {
					auto hit = this->hitchance( exit_pos, target.pawn, weapon, weapon_data );
					if ( !hit ) { // failed hitchance
						// run this only if we have it enabled
						if ( _cfg->bool_elem[ bool_features::autostoprage ] )
							this->autostop_internal( cmd, target.pawn, weapon, weapon_data );
					}

					// minimum damage setup
					// this is abit gheto, but we can work with it
					bool overrider = ams::shared::active( keybind_features::damage_override );
					static int damage{}; // update this on the way

					// yeah, i could use tenary : overrider ? dmgover : damagenormal
					// but as i want to hardcode this shit i wont
					// or i will
					// depends on how it is when u see this code 
					if ( !_cfg->bool_elem[ bool_features::force_visible_damage_global ] ) {
						// since this shit overrider was done via tenary why not do it complete via tenary
						damage = can_see( target.pawn, game::local_pawn ) ? ( overrider ? _cfg->int_elem[ int_features::rage_minimumdamage_override ] :
																			  _cfg->int_elem[ int_features::rage_minimumdamage ] ) :
							( overrider ? _cfg->int_elem[ int_features::rage_minimumdamage_override ] :
							  _cfg->int_elem[ int_features::rage_minimumdamage_wall ] );
					} else {
						damage = overrider ? _cfg->int_elem[ int_features::rage_minimumdamage_override ] :
							_cfg->int_elem[ int_features::rage_minimumdamage ];
					}

					// gheto minimum damage
					// since our is_tracing_player gets modified only while trace_data is valid
					// we might want to do a little hoking around
					if ( this->trace_damage < damage ) {
						// we might use this for a flag later
						this->ignored_by_damage = true;

						// now continue till we have a valid damage
						continue;
					}

					// set subtick
					cmd->set_subtick_angle( exit_point );

					static bool was_in_fire = false;
					if ( !( cmd->m_buttons.m_value & in_attack ) && !was_in_fire ) {
						cmd->m_buttons.m_value |= in_attack;
						was_in_fire = true;
					} else {
						cmd->m_buttons.m_value &= ~in_attack;
						was_in_fire = false;
					}
				}
			}
		}
	}
}

bool ams::rage_t::autostop_internal( user_cmd_t* cmd, ams::player_pawn_t* target, ams::weapon_base_t* weapon, ams::weapon_data_t* weapon_data ) {
	float m_max_speed = weapon->get_max_speed( );
	evo::vec3_t velocity = game::local_pawn->get_velocity( );

	// set z to 0
	velocity.z = 0.f;

	float speed = velocity.length_2d( );

	// we are pressing move keys
	bool pressing_move_keys = ( cmd->m_buttons.m_value & in_forward || cmd->m_buttons.m_value & in_moveleft ||
								cmd->m_buttons.m_value & in_back || cmd->m_buttons.m_value & in_moveright );

	bool fullstop = true;
	fullstop = speed > ( m_max_speed * 0.33000001 );

	if ( fullstop && ( cmd->m_base_cmd->m_forward_move != 0.f || cmd->m_base_cmd->m_side_move != 0.f ) ) {
		cmd->m_base_cmd->m_forward_move = 0.f;
		cmd->m_base_cmd->m_side_move = 0.f;

		return true;
	}

	return true;
}

bool ams::rage_t::hitchance( evo::vec3_t point, ams::player_pawn_t* target,
							 ams::weapon_base_t* weapon, ams::weapon_data_t* weapon_data ) {
	// what do we know?
	// we do not have to use seeds.
	auto get_weapon_spread = [ & ]( int seed, float spread, float inaccuracy ) -> evo::vec3_t {
		ams::fn_random_seed( ( seed & 0xff ) + 1 );

		const float r1 = ams::fn_random_float( 0.f, 1.f );
		const float r2 = ams::fn_random_float( 0.f, 3.14159265358979323846264338327950288f * 2 );
		const float r3 = ams::fn_random_float( 0.f, 1.f );
		const float r4 = ams::fn_random_float( 0.f, 3.14159265358979323846264338327950288f * 2 );

		/* get needed sine / cosine values. */
		const float c1 = std::cos( r2 );
		const float c2 = std::cos( r4 );
		const float s1 = std::sin( r2 );
		const float s2 = std::sin( r4 );

		/* calculate spread vector. */
		return { ( c1 * ( r1 * inaccuracy ) ) + ( c2 * ( r3 * spread ) ) ,
			( s1 * ( r1 * inaccuracy ) ) + ( s2 * ( r3 * spread ) ) , 0.f };
		};

	if ( !weapon )
		return false;

	if ( !weapon_data )
		return false;

	// safety later !!!!!!!!
	evo::vec3_t eye_pos = game::local_pawn->get_eye_pos( );

	// stuff
	evo::vec3_t fwd, right, up;

	// get needed directional vectors.
	evo::math::angle_vectors( point, fwd, &right, &up );

	// store
	const float inaccuracy = weapon->get_inaccuracy( );
	const float spread = weapon->get_spread( );

	size_t total_hits{ }, needed_hits{ ( size_t )std::ceil( ( _cfg->int_elem[ int_features::rage_hitchance ] * 255 ) / 100 ) };

	// try as 256 
	for ( int i = 0; i <= 255; ++i ) {
		evo::vec3_t weapon_spread = get_weapon_spread( i, spread, inaccuracy );

		// direction
		evo::vec3_t direction = ( fwd + ( right * weapon_spread.x ) +
								  ( up + weapon_spread.y ) ).normalized( );

		evo::vec3_t end = eye_pos + ( direction * weapon_data->fl_range( ) );

		// should work?
		if ( this->is_tracing_player ) {
			++total_hits;
		}

		// abort if hitchance is already sufficent.
		if ( static_cast< float >( total_hits ) / static_cast< float >( 255 ) >= _cfg->int_elem[ int_features::rage_hitchance ] / 100.f ) {
			return true;
		}

		// abort if we can no longer reach hitchance.
		if ( static_cast< float >( total_hits + 255 - i ) / static_cast< float >( 255 ) < _cfg->int_elem[ int_features::rage_hitchance ] / 100.f ) {
			return false;
		}
	}

	// return
	return total_hits >= needed_hits;
}

void ams::rage_t::setup_hitscan_mode( ams::player_pawn_t* target ) {
	bool lethal = target->get_health( ) <= 30; 

	// pretty simple, huh.
	if ( lethal ) {
		this->m_mode = hitscan_mode_t::hitscan_lethal;
	} else {
		this->m_mode = hitscan_mode_t::hitscan_normal;
	}
}

bool ams::rage_t::setup_hitbox_points( ams::player_pawn_t* target, std::vector<hitscan_t>& points ) {
	// go and setup hitscan mode
	this->setup_hitscan_mode( target );

	// clearn points data.
	points.clear( );

	auto can_see = [ & ]( evo::vec3_t point, player_pawn_t* local ) -> bool {
		auto start_eye = local->get_eye_pos( );
		return ams::autowall::fire_bullet( start_eye, point );
	};

	// get the positions.
	// head
	if ( _cfg->bool_elem[ bool_features::headhitbox ] )
	{
		static evo::vec3_t head_pos{ };
		static evo::vec3_t head_rot{ };

		// get it.
		target->get_bone_position( 6, head_pos, head_rot );

		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, head_pos, 6, can_see( head_pos, game::local_pawn ) } );
	}
	
	// pelvis
	if ( _cfg->bool_elem[ bool_features::pelvishitbox ] )
	{
		static evo::vec3_t pelvis_pos{ };
		static evo::vec3_t pelvis_rot{ };

		// get it.
		target->get_bone_position( pelvis, pelvis_pos, pelvis_rot );

		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, pelvis_pos, pelvis, can_see( pelvis_pos, game::local_pawn ) } );
	}

	// neck_0
	if ( _cfg->bool_elem[ bool_features::neckhitbox ] )
	{
		static evo::vec3_t neck_pos{ };
		static evo::vec3_t neck_rot{ };

		// get it.
		target->get_bone_position( neck_0, neck_pos, neck_rot );

		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, neck_pos, neck_0, can_see( neck_pos, game::local_pawn ) } );
	}

	// spine_2
	if ( _cfg->bool_elem[ bool_features::spinehitbox ] )
	{
		static evo::vec3_t spine_pos{ };
		static evo::vec3_t spine_rot{ };

		// get it.
		target->get_bone_position( spine_2, spine_pos, spine_rot );

		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, spine_pos, spine_2, can_see( spine_pos, game::local_pawn ) } );
	}

	// arms
	if ( _cfg->bool_elem[ bool_features::armshitbox ] )
	{
		static evo::vec3_t arms[4]{ };
		static evo::vec3_t arms2[4]{ };

		// get it.
		target->get_bone_position( arm_upper_R, arms[0], arms2[ 0 ] );
		target->get_bone_position( arm_lower_R, arms[1], arms2[ 1 ] );
		target->get_bone_position( arm_upper_L, arms[2], arms2[ 2 ] );
		target->get_bone_position( arm_lower_L, arms[3], arms2[ 3 ] );


		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, arms[0], arm_upper_R, can_see( arms[0], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, arms[1], arm_lower_R, can_see( arms[1], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, arms[2], arm_upper_L, can_see( arms[2], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, arms[3], arm_lower_L, can_see( arms[3], game::local_pawn ) } );
	}

	// legs
	if ( _cfg->bool_elem[ bool_features::legshitbox ] )
	{
		static evo::vec3_t legs[ 4 ]{ };
		static evo::vec3_t legs2[ 4 ]{ };

		// get it.
		target->get_bone_position( leg_upper_R, legs[ 0 ], legs2[ 0 ] );
		target->get_bone_position( leg_lower_R, legs[ 1 ], legs2[ 1 ] );
		target->get_bone_position( leg_upper_L, legs[ 2 ], legs2[ 2 ] );
		target->get_bone_position( leg_lower_L, legs[ 3 ], legs2[ 3 ] );


		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, legs[ 0 ], leg_upper_R, can_see( legs[0], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, legs[ 1 ], leg_lower_R, can_see( legs[1], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, legs[ 2 ], leg_upper_L, can_see( legs[2], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, legs[ 3 ], leg_lower_L, can_see( legs[3], game::local_pawn ) } );
	}

	// other
	if ( _cfg->bool_elem[ bool_features::foothitbox ] )
	{
		static evo::vec3_t other[ 4 ]{ };
		static evo::vec3_t other2[ 4 ]{ };

		// get it.
		target->get_bone_position( hand_L, other[ 0 ], other2[ 0 ] );
		target->get_bone_position( hand_R, other[ 1 ], other2[ 1 ] );
		target->get_bone_position( ankle_L, other[ 2 ], other2[ 2 ] );
		target->get_bone_position( ankle_R, other[ 3 ], other2[ 3 ] );


		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, other[ 0 ], hand_L, can_see( other[0], game::local_pawn )} );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, other[ 1 ], hand_R, can_see( other[1], game::local_pawn )} );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, other[ 2 ], ankle_L, can_see( other[2], game::local_pawn ) } );
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_normal, other[ 3 ], ankle_R, can_see( other[3], game::local_pawn ) } );
	}

	// lethals
	// pelvis
	{
		static evo::vec3_t pelvis_pos{ };
		static evo::vec3_t pelvis_rot{ };

		// get it.
		target->get_bone_position( pelvis, pelvis_pos, pelvis_rot );

		// push data.
		points.push_back( hitscan_t{ hitscan_mode_t::hitscan_lethal, pelvis_pos, pelvis, can_see( pelvis_pos, game::local_pawn ) } );
	}

	return true;
}

void ams::rage_t::get_best_hitbox_point( ams::player_pawn_t* target, evo::vec3_t& exit_point, evo::vec3_t& exit_pos ) {
	// setup points first
	// reason: so we can return if we have null data.
	// first setup hitbox points
	this->setup_hitbox_points( target, this->m_points );

	// no point to get hitbox data from
	if ( this->m_points.empty( ) )
		return;

	static bool done = false;
	
	// get local pos
	auto local_pos = game::local_pawn->get_eye_pos( );

	// iterate
	for ( const auto& point : this->m_points ) {
		done = false; // presetup 

		// will this fix out bone problem?
		// run penetration for each hitbox and check if we can go for it
		if ( !point.m_can_pen ) {
			continue;
		}

		// player is lethal abort scaning other hitboxes
		if ( point.m_mode == hitscan_mode_t::hitscan_lethal && target->get_health( ) <= 30 ) {
			// get out of loop
			done = true;
		} else if ( point.m_mode == hitscan_mode_t::hitscan_prefer ) {
			// we ve got this hitbox prefeered, exit the loop
			done = true;
		} else if ( point.m_mode == hitscan_mode_t::hitscan_normal ) {
			// this is not the best way to force targeting head
			// but ig this works pretty much good
			// we'll see soon what we can do abt this
			// pretty much the proble was solved, but to aquire more accuracy to aimbot
			// we must check if player is too low to run on this
			// since our lethal goes out when <= 30 hp we might want to go for head till 50 hp
			// force baim when player is lower than 50 hp and improve our aimbot accuracy
			// no way to force head actually, just let it like this
			done = true;
		}

		if ( done ) {
			auto calculated_point = evo::math::normalize_angle_sdk( evo::math::calc_angle_boss( local_pos, point.m_point ) );
			exit_point = calculated_point;
			exit_pos = point.m_point;

			// get out of loop
			break;
		}
	}
}

bool ams::rage_t::can_shot( ) { 
	// player can fire.
	// i guess u can use this sometime
	// i commented it myself
	// auto player_can_fire = ams::globals->m_cur_time >= game::local_pawn->weapon_services( )->next_attack( );
	
	// weapon is grenade.
	if ( game::local_pawn->clipping_weapon( )->get_weapon_data( )->weapon_type( ) == ams::weapon_type_t::weapon_type_grenade ) {
		return false;
	}

	if ( game::local_pawn->clipping_weapon( )->get_weapon_data( )->weapon_type( ) != ams::weapon_type_t::weapon_type_knife &&
		 game::local_pawn->clipping_weapon( )->get_clip( ) < 1 ) {
		return false;
	}

	// i guess we do it with ratio
	// maybe
	if ( ams::globals->m_cur_time >= game::local_pawn->clipping_weapon( )->next_primary_attack_ratio( ) )
		return true;

	// nothing stopped us
	// lets go for can
	return true;
}

// include
#include "../../hooks/hooks.hpp"
void ams::rage_t::draw_targeted_point( ) { 
	// no rage enabled
	if ( !_cfg->bool_elem[ bool_features::ragebot ] )
		return;

	// avoi crashes
	if ( this->targeted_point.x == 0 
		 || this->targeted_point.y == 0 )
		return;

	// safety.
	if ( this->m_target.size( ) <= 0 )
		return;

	// world to screen the point 
	evo::vec2_t screen;
	if ( !ams::screen::world_to_screen( this->targeted_point, screen ) ) {
		return; // world to screen failed
	}

	// draw point
	evo::_render->add_radial_gradient( screen, 10, evo::col_t( 255, 0, 0, 200 ).convert( ), evo::col_t( 255, 0, 0, 20 ).convert( ) );
}
