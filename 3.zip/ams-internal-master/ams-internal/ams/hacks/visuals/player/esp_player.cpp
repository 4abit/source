#include "esp_player.hpp"
#include "../../../hooks/hooks.hpp"
#include "../../../game-data/game_data.hpp"

evo::rect_t ams::esp_player_t::grab_bounding_data( player_pawn_t* pawn ) {
	auto node = pawn->scene_node( );
	if ( node == nullptr ) {
		return evo::rect_t{};
	}

	auto collision = pawn->collision_property( );
	if ( collision == nullptr ) {
		return evo::rect_t{};
	}

	evo::vec2_t flb, brt, blb, frt, frb, brb, blt, flt = { };
	float left, top, right, bottom = 0.f;

	auto origin = node->get_abs_origin( );
	evo::vec3_t min = collision->get_mins( ) + origin;
	evo::vec3_t max = collision->get_maxs( ) + origin;

	// pos array
	std::array<evo::vec3_t, 8> points = {
		evo::vec3_t( min.x, min.y, min.z ),
		evo::vec3_t( min.x, min.y, max.z ),
		evo::vec3_t( min.x, max.y, min.z ),
		evo::vec3_t( min.x, max.y, max.z ),
		evo::vec3_t( max.x, min.y, min.z ),
		evo::vec3_t( max.x, min.y, max.z ),
		evo::vec3_t( max.x, max.y, min.z ),
		evo::vec3_t( max.x, max.y, max.z ) 
	};

	if ( !ams::screen::world_to_screen( points[ 3 ], flb )
		 || !ams::screen::world_to_screen( points[ 5 ], brt )
		 || !ams::screen::world_to_screen( points[ 0 ], blb )
		 || !ams::screen::world_to_screen( points[ 4 ], frt )
		 || !ams::screen::world_to_screen( points[ 2 ], frb )
		 || !ams::screen::world_to_screen( points[ 1 ], brb )
		 || !ams::screen::world_to_screen( points[ 6 ], blt )
		 || !ams::screen::world_to_screen( points[ 7 ], flt ) ) {
		return evo::rect_t{};
	}

	std::array<evo::vec2_t, 8> arr = { flb, brt, blb, frt, frb, brb, blt, flt };

	left = flb.x;
	top = flb.y;
	right = flb.x;
	bottom = flb.y;

	for ( std::int32_t i = 1; i < 8; i++ ) {
		if ( left > arr[ i ].x ) {
			left = arr[ i ].x;
		}

		if ( bottom < arr[ i ].y ) {
			bottom = arr[ i ].y;
		}

		if ( right < arr[ i ].x ) {
			right = arr[ i ].x;
		}

		if ( top > arr[ i ].y ) {
			top = arr[ i ].y;
		}
	}


	return evo::rect_t{
		( int )left,
		( int )top,
		( int )( right - left ),
		( int )( bottom - top )
	};
}

void ams::esp_player_t::bounding_box( ) {
	if ( !_cfg->bool_elem[ bool_features::bounding_box ] )
		return;

	auto c = _cfg->color_elem[ color_featues::bounding_box_color ];

	evo::_render->add_rect( this->box.x, this->box.y, this->box.w, this->box.h, c, 0, 1 );
	evo::_render->add_rect( this->box.x - 1, this->box.y - 1, this->box.w + 2, this->box.h + 2, evo::col_t(0, 0, 0 ), 0, 1 );
	evo::_render->add_rect( this->box.x + 1, this->box.y + 1, this->box.w - 2, this->box.h - 2, evo::col_t(0, 0, 0 ), 0, 1 );
}

void ams::esp_player_t::name_esp( player_controller_t* controller ) {
	if ( !_cfg->bool_elem[ bool_features::name_esp ] )
		return;

	auto c = _cfg->color_elem[ color_featues::name_color ];
	auto width = evo::_render->text_size( controller->get_player_name( ), evo::fonts_t::_fsmallest_pixel ).x;

	evo::_render->add_text( box.x + box.w * 0.5 - width * 0.5, box.y - 12, c, evo::fonts_t::_fsmallest_pixel, controller->get_player_name( ), evo::font_flags_t::outline );
}

void ams::esp_player_t::health_esp( player_pawn_t* pawn, int ent_index ) {
	if ( !_cfg->bool_elem[ bool_features::health_esp ] )
		return;

	int player_hp = pawn->get_health();
	int max_hp = 100; /* fix retarded servers that have more than 100 hp*/

	static float prev_player_hp[ 64 ];
	constexpr float speed_freq = 255 / 1.0f;

	if ( prev_player_hp[ ent_index ] > player_hp )
		prev_player_hp[ ent_index ] -= speed_freq * 0.015;
	else
		prev_player_hp[ ent_index ] = player_hp;

	/* calc hp color */
	int r = std::fmin( ( 510 * ( 100 - player_hp ) ) / 100, 255 );
	int g = std::fmin( ( 510 * player_hp ) / 100, 255 );

	evo::col_t health_color{ };
	evo::col_t health_color2{ };

	switch ( _cfg->int_elem[ int_features::health_color_style ] ) {
		case 0:
		{
			health_color = evo::col_t( r, g, 0 ).modify_alpha( 255 );
		} break;
		case 1:
		{
			health_color = _cfg->color_elem[ color_featues::health_color ].modify_alpha( 255 );
		} break;
		case 2:
		{
			health_color = _cfg->color_elem[ color_featues::health_color ].modify_alpha( 255 );
			health_color2 = _cfg->color_elem[ color_featues::health_color2 ].modify_alpha( 255 );
		} break;
	}

	int h = this->box.h + 2;
	int fill = ( int )std::round( prev_player_hp[ ent_index ] * h / 100.f );

	if ( _cfg->bool_elem[ bool_features::health_enab_shadow ] ) {
		evo::_render->add_rect_filled_shadowed( this->box.x - 6, this->box.y + ( h - fill ), 2, fill - 2, health_color, 0, _cfg->int_elem[ int_features::health_shadow ] ); 
	}

	evo::_render->add_rect_filled( this->box.x - 7, this->box.y - 1, 4, this->box.h + 2, evo::col_t( 0, 0, 0, 155 ), 0 );

	if ( _cfg->int_elem[ int_features::health_color_style ] != 2 ) {
		evo::_render->add_rect_filled( this->box.x - 6, this->box.y + ( h - fill ), 2, fill - 2, health_color, 0 ); 
	} else {
		evo::_render->add_gradient_horizontal( this->box.x - 6, this->box.y + ( h - fill ), 2, fill - 2, health_color, health_color2, 0 );
	}
}

void ams::esp_player_t::ammo_esp( player_pawn_t* pawn ) {
	if ( !_cfg->bool_elem[ bool_features::ammo_esp ] )
		return;

	auto weapon = pawn->clipping_weapon( );
	if ( weapon == nullptr )
		return;

	auto weapon_data = weapon->get_weapon_data( );
	if ( weapon_data == nullptr )
		return;

	int bullets = weapon->get_clip( );
	int max = weapon_data->max_clip( );

	int bar;
	float scale;

	evo::col_t health_color{ };
	evo::col_t health_color2{ };
	switch ( _cfg->int_elem[ int_features::ammo_color_style ] ) {
		case 0:
		{
			health_color = _cfg->color_elem[ color_featues::ammo_color ].modify_alpha( 255 );
		} break;
		case 1:
		{
			health_color = _cfg->color_elem[ color_featues::ammo_color ].modify_alpha( 255 );
			health_color2 = _cfg->color_elem[ color_featues::ammo_color2 ].modify_alpha( 255 );
		} break;
	}

	int w = this->box.w + 2;
	if ( max != -1 ) {
		scale = ( float )bullets / max;
		bar = ( int )std::round( ( this->box.w + 2 ) * scale );

		auto fill = bar;

		if ( _cfg->bool_elem[ bool_features::ammo_en_shadow ] ) {
			evo::_render->add_rect_filled_shadowed( this->box.x, this->box.y + this->box.h + 4, fill - 2, 4 - 2, health_color, 0, _cfg->int_elem[ int_features::ammo_shadow ] ); // inverse. : x + ( w - fill )
		}

		evo::_render->add_rect_filled( this->box.x - 1, this->box.y + this->box.h + 3, this->box.w + 2, 4, evo::col_t( 0, 0, 0, 155 ), 0 );
		if ( _cfg->int_elem[ int_features::ammo_color_style ] != 1 ) {
			evo::_render->add_rect_filled( this->box.x, this->box.y + this->box.h + 4, fill - 2, 4 - 2, health_color, 0 ); // inverse. : x + ( w - fill )
		} else {
			evo::_render->add_gradient_vertical( this->box.x, this->box.y + this->box.h + 4, fill - 2, 4 - 2, health_color, health_color2, 0 ); // inverse. : x + ( w - fill )
		}
	}
}

void ams::esp_player_t::weapon_name( player_pawn_t* pawn ) {
	auto weapon = pawn->clipping_weapon( );
	if ( weapon == nullptr )
		return;

	if ( _cfg->bool_elem[ bool_features::weapon_name ] ) {
		auto name = weapon->get_weapon_name( );
		auto pos = name.find( "weapon_" );
		std::string final{};

		// we found the weapon_
		if ( pos != std::string::npos ) {
			final = name.substr( pos + 7 );
		}

		int add = _cfg->bool_elem[ bool_features::ammo_esp ] ? 5 : 0;

		auto c = _cfg->color_elem[ color_featues::weapon_color ];
		auto width = evo::_render->text_size( final.c_str( ), evo::fonts_t::_fsmallest_pixel ).x;

		evo::_render->add_text( box.x + 1 + box.w * 0.5 - width * 0.5, box.y + box.h + 3 + add, c, evo::fonts_t::_fsmallest_pixel,
								final.c_str( ), evo::font_flags_t::outline );
	}

	if ( _cfg->bool_elem[ bool_features::weapon_icon ] ) {
		auto name = game::id_to_icon( weapon->attribute_manager( ).econ_item( ).item_definition_index( ) );
		int add = _cfg->bool_elem[ bool_features::ammo_esp ] ? 5 : 0;
		auto add2 = _cfg->bool_elem[ bool_features::weapon_name ] ? evo::_render->text_size( "justget", evo::fonts_t::_fsmallest_pixel ).y : 0;

		auto c = _cfg->color_elem[ color_featues::weapon_color ];
		auto width = evo::_render->text_size( name.c_str( ), evo::fonts_t::_weapon_icons ).x;
		evo::_render->add_text( box.x + 1 + box.w * 0.5 - width * 0.5, box.y + box.h + 3 + add + add2, c, evo::fonts_t::_weapon_icons,
								name.c_str( ), evo::font_flags_t::outline );
	}
}

namespace ams::bone_list {
	inline std::list<DWORD> trunk = { neck_0,spine_2, pelvis, };
	inline std::list<DWORD> left_arm = { neck_0,arm_upper_L, arm_lower_L, hand_L }; /*
		works: c_arm_lower_r
	*/
	inline std::list<DWORD> right_arm = { neck_0,arm_upper_R,arm_lower_R, hand_R };
	inline std::list<DWORD> left_leg = { pelvis, leg_upper_L , leg_lower_L, ankle_L };
	inline std::list<DWORD> right_leg = { pelvis, leg_upper_R , leg_lower_R, ankle_R };

	inline std::vector<std::list<DWORD>> hitbox_list = { trunk, left_arm, right_arm, left_leg, right_leg };
}

void ams::esp_player_t::calculate_skeleton( player_pawn_t* pawn ) {
	if ( !_cfg->bool_elem[ bool_features::skeleton_esp ] )
		return;

	evo::vec3_t current;
	evo::vec3_t prev;

	evo::vec2_t currents;
	evo::vec2_t prevs;

	/* iterate through bones */
	for ( auto bone : bone_list::hitbox_list ) {
		prev = evo::vec3_t( 0, 0, 0 );
		for ( auto index : bone ) {

			// vecs.
			evo::vec3_t bone_position = { };
			evo::vec3_t bone_rotation = { };

			// bone position
			pawn->get_bone_position( index, bone_position, bone_rotation );
			
			// store the bone pos to current
			current = bone_position;

			// update prev pos of the bone
			if ( prev == evo::vec3_t( 0, 0, 0 ) ) {
				prev = current;
				continue;
			}

			// world to screen
			ams::screen::world_to_screen( current, currents );
			ams::screen::world_to_screen( prev, prevs );

			// render bone
			evo::_render->add_line( prevs, currents, _cfg->color_elem[ color_featues::skeleton_color ], 1.f );

			// update bone
			prev = current;
		}
	}
}

void ams::esp_player_t::flags( player_pawn_t* pawn, player_controller_t* controller, int ent_index ) {
	struct flags_data_t {
		std::string flag;
		evo::col_t color;
	};

	// vector
	std::vector < flags_data_t > flags;

	// for flags.
	bool has_defuser = _cfg->bool_elem[ bool_features::deuser_flag ] && pawn->item_services( )->has_defuser( );
	bool has_money = _cfg->bool_elem[ bool_features::money_flag ];
	bool armor_flag = _cfg->bool_elem[ bool_features::armor_flag ];
	bool distance_flag = _cfg->bool_elem[ bool_features::distance_flag ];
	bool scoped_flag = _cfg->bool_elem[ bool_features::scoped_flag ] && pawn->is_scoped();
	
	if ( has_defuser ) {
		flags_data_t info;
		info.color = evo::col_t( 255, 129, 120 );
		info.flag = "DEFUSER";

		flags.push_back( info );
	}

	if ( has_money ) {
		flags_data_t info;
		info.color = evo::col_t( 8, 230, 0 );
		info.flag = "$" + str_( controller->money_services( )->get_account( ) );

		flags.push_back( info );
	}

	if ( armor_flag ) {
		flags_data_t info;
		info.color = evo::col_t( );
		info.flag = "HK";

		flags.push_back( info );
	}

	if ( distance_flag ) {
		flags_data_t info;
		info.color = evo::col_t( );

		// distance
		int dist = game::local_pawn->scene_node( )->get_vec_origin( ).dist_to( pawn->scene_node( )->get_vec_origin( ) ) / 90;

		// flag.
		info.flag = str_( dist ) + "FT";

		// push
		flags.push_back( info );
	}

	if ( scoped_flag ) {
		flags_data_t info;
		info.color = evo::col_t( 0, 140, 255 );
		info.flag = "ZOOM";

		flags.push_back( info );
	}

	static float flags_interp[ 64 ]{};
	auto static_size = evo::_render->text_size( "something", evo::fonts_t::_fsmallest_pixel ).y * flags.size( );

	// animation.
	if ( flags_interp[ ent_index ] != static_size ) {
		flags_interp[ ent_index ] += ( static_size - flags_interp[ ent_index ] ) * 0.08f;
	}

	for ( size_t i{ }; i < flags.size( ); ++i ) {
		const auto& f = flags[ i ];
		int offset = i * ( evo::_render->text_size( "something", evo::fonts_t::_fsmallest_pixel ).y - 1 );

		// (box.x + box.w + 2, box.y + flags_interp[player->index()] - offset - render::esp_small.m_size.m_height, f.second, f.first);

		evo::_render->add_text( this->box.x + this->box.w + 3, this->box.y + flags_interp[ ent_index ] - offset - evo::_render->text_size( "something", evo::fonts_t::_fsmallest_pixel ).y,
								f.color, evo::fonts_t::_fsmallest_pixel, f.flag.c_str( ), evo::font_flags_t::outline );
	}
}