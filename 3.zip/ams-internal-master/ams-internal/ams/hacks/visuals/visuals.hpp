#pragma once
#include "../../includes.hpp"

namespace ams {
	class visuals_t {
	public:
		void construct( );
	};


	share_class( _visuals, visuals_t );
}