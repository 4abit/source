#include "usermode.hpp"
#include "../../../ui/container/container.hpp"

void ams::usermode_t::construct( ) { 
	this->watermark( );
	this->keybinds( );
}

void ams::usermode_t::watermark( ) { 
	if ( !_cfg->bool_elem[ bool_features::watermark ] )
		return;

	// note:
	// in the future we will create a chat command or console command to set username
	// .username <username>
	// for now i will just take the one pc has
	// lambada abuser as all time
	auto get_username = [ & ]( ) -> std::string {
		// username vars
		char username[ 256 ];
		DWORD size_username = sizeof( username );

		// store username
		GetUserName( username, &size_username );

		return username;
	};

	// store username
	// since we wont change pc username x times we will store this as a static so it wont overrun.
	static std::string username = get_username( );
	std::string text = "amnesia | Developer";

	// full size.
	auto width = evo::_render->text_size( text.c_str( ), evo::fonts_t::_default2 ).x + 15;

	// init moving shit
	static evo::vec2_t pos{ 10, 10 };

	// update it only if saved positions are != 0
	if ( _cfg->float_elem[ float_features::watermark_x ] != 0 && _cfg->float_elem[ float_features::watermark_y ] != 0 ) {
		// update position
		pos = { _cfg->float_elem[ float_features::watermark_x ], _cfg->float_elem[ float_features::watermark_y ] };
	}

	// init moving
	static bool in_area = false;

	// update in area
	if ( evo::_input->mouse_in_box( pos, { width, 30 } ) ) {
		in_area = true;
	}

	// start dragging
	if ( in_area && GetAsyncKeyState( VK_LBUTTON ) ) {
		// we will use this later
		_panel.watermark_state = true;

		// update pos
		_cfg->float_elem[ float_features::watermark_x ] = evo::_input->get_mouse_position( ).x;
		_cfg->float_elem[ float_features::watermark_y ] = evo::_input->get_mouse_position( ).y;
	}

	// update in_area
	if ( in_area && !GetAsyncKeyState( VK_LBUTTON ) ) {
		// set to false.
		in_area = false;
		_panel.watermark_state = false;
	}

	// draw panel.
	evo::_render->add_rect_filled_shadowed( pos.x, pos.y, width, 30, evo::_container->window_outline.modify_alpha( 255 ), 4, 15 );
	evo::_render->add_rect_filled( pos.x, pos.y, width, 30, evo::_container->window_backround.modify_alpha( 255 ), 4 );
	evo::_render->add_rect_filled( pos.x + 8 + evo::_render->text_size( "amnesia ", evo::fonts_t::_default2 ).x, 
								   pos.y, 1, 30, evo::_container->window_outline.modify_alpha( 255 ), 4 );
	evo::_render->add_rect( pos.x, pos.y, width, 30, evo::_container->window_outline.modify_alpha( 255 ), 4, 1 );

	evo::_render->add_text( pos.x + 7, pos.y + 5, evo::_container->window_accent.modify_alpha( 255 ), evo::fonts_t::_default2, "amnesia", 0 );
	evo::_render->add_text( pos.x + 14 + evo::_render->text_size( "amnesia ", evo::fonts_t::_default2 ).x, pos.y + 5,
							evo::col_t( ).modify_alpha( 255 / 2 ), evo::fonts_t::_default2, "Developer", 0 );
}

__forceinline float out_quint( float v ) {
	return 1 - pow( 1 - v, 9 );
}
__forceinline float in_quint( float x ) {
	return x * x * x * x * x;
}

// disable warning
#pragma warning ( disable : 4805 )

// arch.
// milkshake.
void ams::usermode_t::keybinds( ) { 
	if ( !_cfg->bool_elem[ bool_features::indicators ] )
		return;

	auto want_offset = 0;
	static std::map<int, float> anim_stack;

	const auto indicator = [ & ]( bool display, const std::string& title, const std::string& description ) -> void {
		auto title_size = evo::_render->text_size( title.c_str( ), evo::fonts_t::_default2 );
		auto text_size = evo::_render->text_size( description.c_str( ), evo::fonts_t::_default2 );

		auto size = evo::vec2_t( title_size.x + 10 + text_size.x + 12, 30 );
		auto screen_size = evo::vec2_t( ImGui::GetIO( ).DisplaySize.x, ImGui::GetIO( ).DisplaySize.y );

		auto pos = evo::vec2_t( 15, screen_size.y / 2 - size.y / 2 + want_offset );

		auto id = std::hash<std::string>( )( title );
		auto id_co = std::hash<std::string>( )( title + "#co" );
		auto id_open = std::hash<std::string>( )( title + description );
		float additive = ( 1.f / 0.6f ) * ImGui::GetIO( ).DeltaTime * 0.5f;

		auto alpha = anim_stack.find( id );
		if ( alpha == anim_stack.end( ) ) {
			anim_stack.insert( { id, 0.f } );
			alpha = anim_stack.find( id );
		}

		auto open_anim = anim_stack.find( id_open );
		if ( open_anim == anim_stack.end( ) ) {
			anim_stack.insert( { id_open, 0.f } );
			open_anim = anim_stack.find( id_open );
		}

		bool collapse = alpha->second > 0.9f;

		if ( open_anim->second != collapse ) {
			open_anim->second += ( collapse - open_anim->second ) * 0.1f;
		}
		alpha->second = std::clamp( alpha->second + ( 3.f * additive * ( display ? 1.f : -1.f ) ), 0.0f, 1.f );

		auto eased = display ? out_quint( alpha->second ) : in_quint( alpha->second );
		auto eased_open = open_anim->second;
		size.x = title_size.x + 21 + ( ( text_size.x + 5 ) * eased_open );

		pos.x -= ( size.x + 15 ) * ( 1.f - eased );

		evo::_render->clip_rect( pos.x, pos.y, size.x, size.y, [ & ]( ) {
			evo::_render->add_rect_filled_shadowed( pos.x, pos.y, size.x, size.y, evo::_container->window_outline.modify_alpha( 255 ), 4, 15 );
			evo::_render->add_rect_filled( pos.x, pos.y, size.x, size.y, evo::_container->window_backround.modify_alpha( 255 ), 4 );

			evo::_render->add_rect_filled( pos.x + 8 + title_size.x + 5,
										   pos.y, 1, size.y, evo::_container->window_outline.modify_alpha( 255 ), 4 );

			evo::_render->add_rect( pos.x, pos.y, size.x, size.y, evo::_container->window_outline.modify_alpha( 255 ), 4, 1 );

			evo::_render->add_text( pos.x + 7, pos.y + 6, evo::_container->window_accent.modify_alpha( 255 * alpha->second ), evo::fonts_t::_default2, title.c_str( ), 0 );
			evo::_render->add_text( pos.x + 7 + title_size.x + 12, pos.y + 6, evo::_container->window_text.modify_alpha( ( 155 * alpha->second ) * eased ), evo::fonts_t::_default2, description.c_str( ), 0 );
		} );

		if ( alpha->second > 0.3f )
			want_offset += size.y + 15;
	};

	indicator( ams::shared::active( keybind_features::damage_override ), "Damage override", "Set damage to " + str_( _cfg->int_elem[ int_features::rage_minimumdamage_override ] ) );
}
