#pragma once
#include "../visuals.hpp"

namespace ams {
	// panel
	struct usermode_panel_t {
		bool watermark_state{ false };
	}; inline usermode_panel_t _panel;

	// class.
	class usermode_t {
	public:
		void construct( );
	private:
		void watermark( );
		void keybinds( );
	};

	share_class( _usermode, usermode_t );
}