#include "world.hpp"
#include "../../../game-data/game_data.hpp"

void ams::world_t::construct( ) { 
	this->world_modulation( );
}

void ams::world_t::world_modulation( ) { 
	// old expoposure
	static float old_exposure_min = 1.f;
	static float old_exposure_max = 1.f;

	// pawn
	auto pawn = game::local_pawn;
	if ( !pawn ) {
		return; // do not run nightmode
	}

	// camera services
	auto camera_services = pawn->camera_services( );
	if ( !camera_services ) {
		return; // do not run nightmode
	}

	auto post_processing = ams::resource_services->m_game_entity_system->construct<ams::post_processing_t>(
		camera_services->post_processing_values( ) );
	if ( !post_processing )
		return;

	if ( !_cfg->bool_elem[ bool_features::nightmode ] ) {
		post_processing->min_exposure( ) = old_exposure_min;
		post_processing->max_exposure( ) = old_exposure_max;
		
		return;
	}

	// value.
	const float value = 0.1f - ( ( _cfg->float_elem[ float_features::nightmode_value ] - 1 ) * 0.0010f );

	post_processing->min_exposure( ) = value;
	post_processing->max_exposure( ) = value;
}
