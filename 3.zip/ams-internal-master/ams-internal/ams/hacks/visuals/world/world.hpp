#pragma once
#include "../visuals.hpp"

namespace ams {
	class world_t {
	public:
		void construct( );
	private:
		void world_modulation( );
	};

	share_class( _world, world_t )
}