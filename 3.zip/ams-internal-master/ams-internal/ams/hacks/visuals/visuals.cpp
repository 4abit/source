#include "visuals.hpp"
#include "../../game-data/game_data.hpp"
#include "player/esp_player.hpp"
#include "world/world.hpp"
#include "../../hooks/hooks.hpp"


void ams::visuals_t::construct( ) { 
	// player esp
	for ( int i = 0; i < game::entity_data.size( ); i++ ) {
		// get data for box
		_esp_player->box = _esp_player->grab_bounding_data( game::entity_data[ i ].pawn );

		if ( _esp_player->box.x != 0 ) {
			// draw box 
			_esp_player->bounding_box( );
			_esp_player->name_esp( game::entity_data[ i ].controller );
			_esp_player->health_esp( game::entity_data[ i ].pawn, i );
			_esp_player->ammo_esp( game::entity_data[ i ].pawn );
			_esp_player->weapon_name( game::entity_data[ i ].pawn );
			_esp_player->flags( game::entity_data[ i ].pawn, game::entity_data[ i ].controller, i );
			_esp_player->calculate_skeleton( game::entity_data[ i ].pawn );
		}
	}
}
