#pragma once

#define schema_add_offset(TYPE, NAME, OFFSET)                                                                 \
	[[nodiscard]] CS_INLINE std::add_lvalue_reference_t<TYPE> NAME()                                          \
	{                                                                                                         \
		static const std::uint32_t uOffset = OFFSET;                                                          \
		return *reinterpret_cast<std::add_pointer_t<TYPE>>(reinterpret_cast<std::uint8_t*>(this) + (uOffset)); \
	}

#define schema_add_poffset(TYPE, NAME, OFFSET)                                                               \
	[[nodiscard]] CS_INLINE std::add_pointer_t<TYPE> NAME()                                                  \
	{                                                                                                        \
		const static std::uint32_t uOffset = OFFSET;                                                         \
		return reinterpret_cast<std::add_pointer_t<TYPE>>(reinterpret_cast<std::uint8_t*>(this) + (uOffset)); \
	}

#define schema_add_field_offset(TYPE, NAME, FIELD, ADDITIONAL) schema_add_offset(TYPE, NAME, ams::schema::get_offset(FNV1A::HashConst(FIELD)) + ADDITIONAL)

#define schema_add_field(TYPE, NAME, FIELD) schema_add_field_offset(TYPE, NAME, FIELD, 0U)

#define schema_add_pfield_offset(TYPE, NAME, FIELD, ADDITIONAL) schema_add_poffset(TYPE, NAME, ams::schema::get_offset(FNV1A::HashConst(FIELD)) + ADDITIONAL)

#define schema_add_pfield(TYPE, NAME, FIELD) schema_add_pfield_offset(TYPE, NAME, FIELD, 0U)

#include "../../utils/other/stuff.hpp"
using FNV1A_t = std::uint64_t;

/*
 * 64-BIT FNV1A HASH
 */
namespace FNV1A {
	/* @section: [internal] constants */
	constexpr FNV1A_t ullBasis = 0xCBF29CE484222325ULL;
	constexpr FNV1A_t ullPrime = 0x100000001B3ULL;

	/* @section: get */
	/// @param[in] szString string for which you want to generate a hash
	/// @param[in] uKey key of hash generation
	/// @returns: calculated at compile-time hash of given string
	consteval FNV1A_t HashConst( const char* szString, const FNV1A_t uKey = ullBasis ) noexcept {
		return ( szString[ 0 ] == '\0' ) ? uKey : HashConst( &szString[ 1 ], ( uKey ^ static_cast< FNV1A_t >( szString[ 0 ] ) ) * ullPrime );
	}

	/// @param[in] szString string for which you want to generate a hash
	/// @param[in] uKey key of hash generation
	/// @returns: calculated at run-time hash of given string
	inline FNV1A_t Hash( const char* szString, FNV1A_t uKey = ullBasis ) noexcept {
		const std::size_t nLength = CRT::StringLength( szString );

		for ( std::size_t i = 0U; i < nLength; ++i ) {
			uKey ^= szString[ i ];
			uKey *= ullPrime;
		}

		return uKey;
	}
}

namespace ams {
	namespace schema {
		bool construct_schema( const wchar_t* m_file_name );

		/* @section: get */
		// get offset of the field in the class
		// @note: only client.dll class & fields
		[[nodiscard]] std::uint32_t get_offset( const FNV1A_t uHashedFieldName );

		// get foregin offset from other .dll
		// maybe we will do this sometime./
		[[nodiscard]] std::uint32_t get_foreign_offset( const char* szModulenName, const FNV1A_t uHashedClassName, const FNV1A_t uHashedFieldName );
	}
}