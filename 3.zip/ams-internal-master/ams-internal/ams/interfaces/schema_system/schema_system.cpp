#include "../../includes.hpp"
#include <shlobj_core.h>
#include "../../utils/other/stuff.hpp"

// schema data.
struct schema_data_t {
	FNV1A_t m_hashed_field_name = 0x0ULL;
	std::uint32_t m_offset = 0x0U;
};

// vec the data.
static std::vector< schema_data_t > m_vec_data;

// working path.
bool get_working_path( wchar_t* wsz_destination ) {
    bool b_success = false;
    PWSTR wsz_path_to_documents = nullptr;

    // get path to user documents.
    if ( SUCCEEDED( ::SHGetKnownFolderPath( FOLDERID_Documents, KF_FLAG_CREATE, nullptr, &wsz_path_to_documents ) ) ) {
        CRT::StringCat( CRT::StringCopy( wsz_destination, wsz_path_to_documents ), CS_XOR( L"\\.amnesia_cs2\\" ) );
        b_success = true;

        // create directory if it doesn't exist.
        if ( !::CreateDirectoryW( wsz_destination, nullptr ) ) {
            if ( ::GetLastError( ) != ERROR_ALREADY_EXISTS ) {
                log_error( "failed to create default working directory, because one or more intermediate directories don't exist" );
                b_success = false;
            }
        }
    }
    ::CoTaskMemFree( wsz_path_to_documents );

    return b_success;
}

// construct schema.
bool ams::schema::construct_schema( const wchar_t* m_file_name ) {
	wchar_t m_dumped_path[ MAX_PATH ];

	// we've got no working path
    if ( !get_working_path( m_dumped_path ) ) {
        return false; // dont do it brother.
    }

    // string the cat.
    CRT::StringCat( m_dumped_path, m_file_name );

    // outfile.
    HANDLE m_out_file = ::CreateFileW(
        m_dumped_path, GENERIC_WRITE, FILE_SHARE_READ, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr
    );
    if ( m_out_file == INVALID_HANDLE_VALUE ) {
        return false; // dont do it brother.
    }

    // time
    const std::time_t m_time = std::time( nullptr );
    std::tm m_time_point;
    localtime_s( &m_time_point, &m_time );

    // string that
    CRT::String_t<64> m_time_buffer( CS_XOR( "[%d-%m-%Y %T] amnesia_cs2 | schema dump\n\n" ), &m_time_point );

    // write data/time and info.
    ::WriteFile( m_out_file, m_time_buffer.Data( ), m_time_buffer.Length( ), nullptr, nullptr );

    // schema type
    ams::schema_system_type_scope_t* m_type_scope = ams::schema_system->find_module( "client.dll" );
    if ( m_type_scope == nullptr ) {
        log_error( "m_type_scope is nullptr" );
        return false; // exit it bro.
    }

    // table size 
    const int m_table_size = m_type_scope->m_hash_classes.Count( );

    // log this shit out.
    log_warning( "found -> " + str_( m_table_size ) + " schema classes in that module!" );

    // allocate memory.
    UtlTSHashHandle_t* m_elements = new UtlTSHashHandle_t[ m_table_size + 1 ];
    const auto m_elements_found = m_type_scope->m_hash_classes.GetElements( 0, m_table_size, m_elements );

    // loop throught elements.
    for ( int i = 0; i < m_elements_found; i++ ) {
        // elements data.
        const UtlTSHashHandle_t h_element = m_elements[ i ];

        // ignore h_element if idx = 0;
        if ( h_element == 0 ) {
            continue;
        }

        // schema binding.
        ams::schema_class_binding_t* m_class_binding = m_type_scope->m_hash_classes[ h_element ];
        if ( m_class_binding == nullptr ) {
            continue; // skip if this is nullptr.
        }

        // declared info.
        ams::schema_class_info_data_t* m_declared_class_info;

        // find the declared classes.
        m_type_scope->find_declared_class( &m_declared_class_info, m_class_binding->m_binary_name );

        // skip if m_declared_class_info is nullptr.
        if ( m_declared_class_info == nullptr ) {
            continue; // skip
        }

        if ( m_declared_class_info->m_field_size == 0 ) {
            continue; // skip this tho
        }

        // crt.
        CRT::String_t<MAX_PATH> m_class_buffer( CS_XOR( "class %s\n" ), m_declared_class_info->m_name );

        // write file.
        ::WriteFile( m_out_file, m_class_buffer.Data( ), m_class_buffer.Length( ), nullptr, nullptr );

        // iterate.
        for ( auto j = 0; j < m_declared_class_info->m_field_size; j++ ) {
            // class fields.
            ams::schema_class_field_data_t* m_fields = m_declared_class_info->m_fields;

            // crt.
            CRT::String_t<MAX_PATH> m_field_class_buffer( CS_XOR( "%s->%s" ), 
                                                        m_class_binding->m_binary_name, m_fields[ j ].m_name );

            // store info.
            m_vec_data.emplace_back( FNV1A::Hash( m_field_class_buffer.Data( ) ), m_fields[ j ].m_single_offset );

            // crt 2.
            CRT::String_t<MAX_PATH> m_field_buffer( CS_XOR( "    %s %s = 0x%X\n" ),
                                                    m_fields[ j ].m_schema_type->m_name, m_fields[ j ].m_name, m_fields[ j ].m_single_offset );

            // write data.
            ::WriteFile( m_out_file, m_field_buffer.Data( ), m_field_buffer.Length( ), nullptr, nullptr );
        }
    }

    // delete allocated memory;
    delete[ ] m_elements;

    // close file.
    ::CloseHandle( m_out_file );

    // return;
    return true;
}

// get offset.
std::uint32_t ams::schema::get_offset( const FNV1A_t m_hashed_file_name ) {
    if ( const auto it = std::ranges::find_if( m_vec_data, [ m_hashed_file_name ](
        const schema_data_t& data ) { return data.m_hashed_field_name == m_hashed_file_name; } ); it != m_vec_data.end( ) )
        return it->m_offset;

    // hope it wont crash
    log_error( "failed to get offset -> " + std::string( ( const char* )m_hashed_file_name ) );

    // schema not found
    CS_ASSERT( false ); // schema field not found

    // return 0
    return 0;
}