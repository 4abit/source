#pragma once
#include "../../utils/other/base_handle.hpp"

#define max_entities_in_list 512
#define max_entity_list 64 // 0x3F

#define max_total_entities max_entities_in_list* max_entity_list

// @asplexya
namespace ams {
	// preclass.
	class base_entity_t; 
	// info: 
	// thats how the class name of entity will get named.

	// class main.
	class game_entity_system_t {
	public:
		// get client entity.
		template <typename T = base_entity_t>
		T* construct( int m_index ) { // get
			return reinterpret_cast< T* >( this->construct_entity_by_index( m_index ) );
		}

		/// GetClientEntityFromHandle
		template <typename T = base_entity_t>
		T* construct( const CBaseHandle hHandle ) {
			if ( !hHandle.IsValid( ) )
				return nullptr;

			return reinterpret_cast< T* >( this->construct_entity_by_index( hHandle.GetEntryIndex( ) ) );
		}

		int get_highest_index( ) {
			return *reinterpret_cast< int* >( reinterpret_cast< std::uintptr_t >( this ) + 0x1510 );
		}
	private:
		void* construct_entity_by_index( int m_index ) { // get entity by index
			using fn_get_base_entity = void* ( CS_THISCALL* )( void*, int );
			static auto get_base_entity = reinterpret_cast< fn_get_base_entity >( 
				ams::memory::find_pattern( L"client.dll", CS_XOR( "81 FA ? ? ? ? 77 ? 8B C2 C1 F8 ? 83 F8 ? 77 ? 48 98 48 8B 4C C1 ? 48 85 C9 74 ? 8B C2 25 ? ? ? ? 48 6B C0 ? 48 03 C8 74 ? 8B 41 ? 25 ? ? ? ? 3B C2 75 ? 48 8B 01" ) ) );
			return get_base_entity( this, m_index );
		}
	};
}