#pragma once

#pragma warning(push)
#pragma warning(disable : 4191)

namespace ams {
	class mem_alloc_t {
	public:
		void* alloc( std::size_t m_size ) {
			return ams::memory::call_function<void*, 1>( this, m_size );
		}

		void* reallocation( const void* m_memory, std::size_t m_size ) {
			return ams::memory::call_function<void*, 2>( this, m_memory, m_size );
		}

		void free( const void* m_memory ) {
			return ams::memory::call_function<void, 3>( this, m_memory );
		}

		std::size_t get_size( const void* m_memory ) {
			return ams::memory::call_function<std::size_t, 21>( this, m_memory );
		}
	};
}

#pragma warning(pop)