#pragma once

namespace ams {
	class render_view_t {
	public:
		evo::vec3_t m_origin;
		evo::vec3_t m_angles;
		float m_fov;
		char pad_0x001C[ 0x14 ];
		evo::view_matrix_t m_mat_unk1;
		char pad_0x0070[ 0x30 ];
		evo::view_matrix_t m_mat_unk2;
		char pad_0x00E0[ 0xC8 ];
		evo::view_matrix_t m_mat_unk3;
		char pad_0x01E8[ 0x28 ];
	};
}