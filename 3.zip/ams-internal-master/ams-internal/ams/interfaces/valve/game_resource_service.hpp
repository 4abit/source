#pragma once

namespace ams {
	// pre class.
	class game_entity_system_t;

	// main.
	class game_resource_services_t {
	public:
		memory_pad( 0x58 );
		game_entity_system_t* m_game_entity_system;
	};
}