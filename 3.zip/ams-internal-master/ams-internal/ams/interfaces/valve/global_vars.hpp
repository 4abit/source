#pragma once

namespace ams {
	class global_vars_t {
	public:
		float m_real_time;
		std::int32_t m_frame_count;
		float m_frame_time;
		float m_frame_time_second;
		memory_pad( 0XC );
		memory_pad( 0X8 );
		float m_interval_per_tick;
		float m_cur_time;
		float m_cur_time_second;
		memory_pad( 0x148 );
		char* m_cur_map;
		char* m_cur_map_name;
	};
}