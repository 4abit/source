#pragma once

#define COMBINE( x, y ) x##y
#define COMBINE2( x, y ) COMBINE( x, y )

#define PAD( sz ) \
	private: \
	std::uint8_t COMBINE2( pad_, __COUNTER__ )[ sz ]; \
	public:

namespace ams {
	class cs_input_t {
	public:
		//char pad__001[ 0x250 ];
		PAD( 0x250 );
		user_cmd_t commands[ 150 ];
		//char pad__002[ 0x1 ];
		PAD( 0x99 );
		bool bInThirdPerson;
		//char pad__003[ 0x22 ];
		PAD( 0x6 );
		std::int32_t seq_number;
		std::int32_t old_seq_number;
		//char pad__004[ 0x4 ];
		PAD( 0xE );
		double dbUnknown; // look's like a timer
		std::uint64_t m_button_state;
		std::uint64_t m_button_state2;
		std::uint64_t m_button_state3;
		std::uint64_t m_button_state4;
		//char pad__005[ 0xC ];
		PAD( 0xC );
		std::int32_t mouse_x;
		std::int32_t mouse_y;
		//char pad__006[ 0xC ];
		PAD( 0xC );
		std::int64_t old_pressed_button;
		bool is_button_pressed;
		//char pad__007[ 0x10F ];
		PAD( 0x10F );
		evo::vec3_t viewangles;
		//char pad__008[ 0x8C ];
		PAD( 0x8C );
		bool bUnknownBool;
		//char pad__000[ 0x7 ];
		PAD( 0x7 );
		//bool bUnknownBool;
		//char pad__0010[ 0xC ];

		// usercmd
		user_cmd_t* get_user_cmd( ) {
			return &commands[ seq_number % 150 ];
		}

		// user old cmd
		user_cmd_t* get_old_user_cmd( ) {
			return &commands[ old_seq_number % 150 ];
		}

		// set viewangle.
		void set_view_angle( evo::vec3_t& angle_view ) {
			using function_view_angles = std::int64_t( __fastcall* )( void*, std::int32_t, evo::vec3_t& );
			static auto set_view_angle = reinterpret_cast< function_view_angles >( memory::find_pattern( L"client.dll", "85 D2 75 3F 48" ) );

#ifdef CS_PARANOID
			CS_ASSERT( set_view_angle != nullptr );
#endif

			set_view_angle( this, 0, std::ref( angle_view ) );
		}

		evo::vec3_t get_viewangles( ) {
			using function_t = void* ( __fastcall* )( cs_input_t*, std::int32_t );
			static function_t fn = reinterpret_cast< function_t >( 
				memory::find_pattern( L"client.dll", CS_XOR( "4C 8B C1 85 D2 74 08 48 8D 05 ? ? ? ? C3" ) ) );

			evo::vec3_t* view_angle = reinterpret_cast< evo::vec3_t* >( fn( this, 0 ) );
			return *view_angle;
		}
	};
}