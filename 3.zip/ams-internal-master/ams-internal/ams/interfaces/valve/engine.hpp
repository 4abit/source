#pragma once

namespace ams {
    enum e_client_frame_stage : int {
        frame_undefined = -1,
        frame_start,
        // a network packet is being received
        frame_net_update_start,
        // data has been received and we are going to start calling postdataupdate
        frame_net_update_postdataupdate_start,
        // data has been received and called postdataupdate on all data recipients
        frame_net_update_postdataupdate_end,
        // received all packets, we can now do interpolation, prediction, etc
        frame_net_update_end,
        // start rendering the scene
        frame_render_start,
        // finished rendering the scene
        frame_render_end,
        frame_net_full_frame_update_on_remove
    };

    class engine_t {
    public:
        int get_max_clients( ) {
            return ams::memory::call_function<int, 34>( this );
        }

        bool is_in_game( ) {
            return ams::memory::call_function<bool, 35>( this );
        }

        bool is_connected( ) {
            return ams::memory::call_function<bool, 36>( this );
        }

        // return CBaseHandle index
        int get_local_player( ) {
            int m_index = -1;

            ams::memory::call_function<void, 49>( this, std::ref( m_index ), 0 );

            return m_index + 1;
        }

        [[nodiscard]] const char* get_level_name( ) {
            return ams::memory::call_function<const char*, 56>( this );
        }

        [[nodiscard]] const char* get_level_name_short( ) {
            return ams::memory::call_function<const char*, 57>( this );
        }

        [[nodiscard]] const char* get_product_version_string( ) {
            return ams::memory::call_function<const char*, 84>( this );
        }
    };
}