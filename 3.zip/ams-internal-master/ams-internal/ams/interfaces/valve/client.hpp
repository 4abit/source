#pragma once

namespace ams {
	class client_t {
	public:
		// this is just an empty class to create the interface.
		// i do not care that much about this shit.
		// so i will just leave it as it is now.
	};
}