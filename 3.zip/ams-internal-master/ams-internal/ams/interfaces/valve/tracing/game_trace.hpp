#pragma once

#define CS2_PAD( number, size )                          \
private:                                                 \
    [[maybe_unused]] std::array< std::byte, size > m_unknown_##number{ }; \
public:

namespace ams {
    inline static constexpr std::uint32_t k_main_pen_mask = 0x1C300Bu; // mask_shot_hull | contents_hitbox?

    struct ray_t {
        evo::vec3_t Start = evo::vec3_t( 0, 0, 0 );
        evo::vec3_t End = evo::vec3_t( 0, 0, 0 );
        evo::vec3_t Mins = evo::vec3_t( 0, 0, 0 );
        evo::vec3_t Maxs = evo::vec3_t( 0, 0, 0 );
        char __pad0000[ 0x4 ];
        std::uint8_t UnkownType = 0x0;
    };

    static_assert( sizeof( ray_t ) == 0x38 );

    struct surface_data_t {
        CS2_PAD( 0, 0x8 );
        float m_penetration_modifier{ };
        float m_damage_modifier{ };
        CS2_PAD( 1, 0x4 );
        int m_material{ };
    };

    struct trace_hitbox_data_t {
        CS2_PAD( 0, 0x38 );
        int m_hitgroup{ };
        CS2_PAD( 1, 0x4 );
        int m_hitbox_id{};
    };


    // preclas.
    class base_entity_t;
    class player_pawn_t;

    struct game_trace_t {
        void* m_surface{ };
        player_pawn_t* m_hit_entity{ };
        trace_hitbox_data_t* m_hitbox_data{ };
        CS2_PAD( 0, 0x38 )
        std::uint32_t m_contents{ };
        CS2_PAD( 1, 0x24 )
        evo::vec3_t m_start_pos{ }, m_end_pos{ }, m_normal{ }, m_pos{ };
        CS2_PAD( 2, 0x4 )
        float m_fraction{ };
        CS2_PAD( 3, 0x6 )
        bool m_all_solid{ };
        CS2_PAD( 4, 0x4D )
    };

    // tracefilter.
    struct trace_filter_t {
        memory_pad( 0x8 );
        std::int64_t m_trace_mask{ };
        std::array< std::int64_t, 2 > m_v1{ };
        std::array< std::int32_t, 4 > m_skip_handles{ };
        std::array< std::int16_t, 2 > m_collisions{ };
        std::int16_t m_v3{ };
        bool m_v4{ }, m_v5{ }, m_v6{ };

        trace_filter_t( std::uintptr_t mask, const void* skip, int layer ) noexcept;
    };

    //struct trace_filter_t {
    //    memory_pad( 0x8 );
    //    std::int64_t m_uTraceMask;
    //    std::array< std::int64_t, 2 > m_v1;
    //    std::array< std::int32_t, 4 > m_arrSkipHandles;
    //    std::array< std::int16_t, 2 > m_arrCollisions;
    //    std::int16_t m_v2;
    //    std::uint8_t m_v3;
    //    std::uint8_t m_v4;
    //    std::uint8_t m_v5;
    //
    //    trace_filter_t( ) = default;
    //    trace_filter_t( std::uint32_t uMask, C_CSPlayerPawn* pSkip1, C_CSPlayerPawn* pSkip2, int nLayer );
    //};

    struct update_value_t {
        float m_previous_length_mod{ };
        float m_current_length_mod{ };
        CS2_PAD( 0, 0x8 )
        std::int16_t m_handle_idx{ };
        CS2_PAD( 1, 0x6 )
    };

    struct trace_arr_element_t {
        CS2_PAD( 0, 0x30 )
    };

    struct trace_data_t {
        std::int32_t m_uk1{ };
        float m_uk2{ 52.0f };
        void* m_arr_pointer{ };
        std::int32_t m_uk3{ 128 };
        std::int32_t m_uk4{ static_cast< std::int32_t >( 0x80000000 ) };
        std::array< trace_arr_element_t, 0x80 > m_arr = { };
        CS2_PAD( 0, 0x8 )
        std::int64_t m_num_update{ };
        void* m_pointer_update_value{ };
        CS2_PAD( 1, 0xC8 )
        evo::vec3_t m_start{ }, m_end{ };
        CS2_PAD( 2, 0x50 )
    };

    class engine_trace_t {
    public:
        void init_trace_filter( trace_filter_t& filter, player_pawn_t* skip, uint64_t mask, uint8_t layer, uint16_t idk ) {
            using function_t = trace_filter_t * ( __fastcall* )( trace_filter_t&, void*, uint64_t, uint8_t, uint16_t );
            static function_t fn = reinterpret_cast< function_t >( memory::find_pattern( L"client.dll", CS_XOR( "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC 20 0F B6 41 ? 33 F6" ) ) );
            if ( fn == nullptr ) {
               // L_PRINT( LOG_WARNING ) << CS_XOR( "trace_filter_t Invalid signature!" );
            }

            CS_ASSERT( fn != nullptr );

            fn( filter, skip, mask, layer, idk );
        }

        // init
        __forceinline static void init_trace_info( game_trace_t* hit ) {
            // ida
            // ; #STR: "invalid_bone", "default", "invalid_hitbox" + 1
            // 48 89 5C 24 08 57 48 83 EC 20 48 8B D9 33 FF 48 8B 0D

            using init_trace_info_fn = void( __fastcall* )( game_trace_t* );
            static auto init_trace = reinterpret_cast< init_trace_info_fn >(
                memory::find_pattern( L"client.dll", CS_XOR( "48 89 5C 24 08 57 48 83 EC 20 48 8B D9 33 FF 48 8B 0D" ) ) );
            return init_trace( hit );
        }

        void clip_trace_to_players( evo::vec3_t& start, evo::vec3_t& end, trace_filter_t* filter, game_trace_t* trace, float min, int length, float max ) { // cHoca
            using function_t = void( __fastcall* )( evo::vec3_t&, evo::vec3_t&, trace_filter_t*, game_trace_t*, float, int, float );
            static function_t fn = reinterpret_cast< function_t >( memory::find_pattern( L"client.dll", "48 8B C4 55 56 48 8D A8 48 FF FF FF 48 81 EC A8 01 00 00 48 89 58 08 4" ) );
            if ( fn == nullptr ) {
                // ugh??
                fn = reinterpret_cast< function_t >( memory::find_pattern( L"client.dll", "48 8B C4 55 56 48 8D A8 58" ) );
            }

            CS_ASSERT( fn != nullptr );

            fn( start, end, filter, trace, min, max, length );
        }

        void trace_shape( ray_t& ray, evo::vec3_t* start, evo::vec3_t* end, trace_filter_t filter, game_trace_t& trace ) {
            // "Physics/TraceShape (Client)"

            using function_t = bool( __fastcall* )( void*, ray_t&, evo::vec3_t*, evo::vec3_t*, trace_filter_t, game_trace_t& );
            static function_t fn = reinterpret_cast< function_t >( memory::find_pattern( L"client.dll", "48 89 5C 24 20 48 89 4C 24 08 55 56 41" ) );
            CS_ASSERT( fn != nullptr );
            fn( this, ray, start, end, filter, trace );
        }

        // get info
        __forceinline static void get_trace_info( trace_data_t* trace, game_trace_t* hit,
                                                  const float unknown_float, void* unknown ) {
            // ; #STR: "Client Simulation" - 3

            using get_trace_info_fn = void( __fastcall* )( trace_data_t*, game_trace_t*, float, void* );
            static auto get_trace_info = reinterpret_cast< get_trace_info_fn >(
                memory::find_pattern( L"client.dll", CS_XOR( "48 89 5C 24 08 57 48 83 EC 20 48 8B D9 33 FF 48 8B 0D" ) ) );

            return get_trace_info( trace, hit, unknown_float, unknown );
        }

        __forceinline static bool handle_bullet_penetration( trace_data_t* trace, void* stats, update_value_t* mod_value,
                                                             const bool draw_showimpacts = false ) {
            using handle_bullet_penetration_fn = bool( __fastcall* )( trace_data_t*, void*, update_value_t*, void*, void*,
                                                                      void*, void*, void*, bool );
            static auto handle_bullet_penetration = reinterpret_cast< handle_bullet_penetration_fn >(
                memory::find_pattern( L"client.dll", CS_XOR( "48 8B C4 44 89 48 20 48 89 50 10 48" ) ) );
            return handle_bullet_penetration( trace, stats, mod_value, nullptr, nullptr, nullptr, nullptr, nullptr, draw_showimpacts );
        }


        __forceinline void create_trace( trace_data_t* pTraceData, const evo::vec3_t vecStart, const evo::vec3_t vecEnd, const trace_filter_t& pFilter, const int iPenCount ) {
            using fnCreateTrace = void( __fastcall* )( trace_data_t*, evo::vec3_t, evo::vec3_t, trace_filter_t, int );
            static auto oCreateTrace = reinterpret_cast< fnCreateTrace >( memory::find_pattern( L"client.dll", CS_XOR( "48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 40 F2" ) ) );

#ifdef CS_PARANOID
            CS_ASSERT( oCreateTrace != nullptr );
#endif

            return oCreateTrace( pTraceData, vecStart, vecEnd, pFilter, iPenCount );
        }
    };
}