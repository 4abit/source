#include "../../../includes.hpp"

ams::trace_filter_t::trace_filter_t( const std::uintptr_t mask,
									 const void* skip, const int layer ) noexcept {
	// tracefilter
	// 48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 0F B6 41 37 33
	// (__int64 a1, _DWORD *a2, __int64 a3, char a4, __int16 a5)
	/* using these to find it easier when this sig will change
	* @ dutu
		*(_QWORD *)(a1 + 24) = 0i64;
		*(_QWORD *)a1 = &CTraceFilter::`vftable';
		*(_WORD *)(a1 + 52) = a5;
	*/

	// trace filtr init
	using trace_filter_function = void( __fastcall* )( void*, const void*, std::uintptr_t, int, int );
	static auto trace_filter = reinterpret_cast< trace_filter_function >(
		memory::find_pattern( L"client.dll", CS_XOR( "48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 0F B6 41 37 33" ) ) );

	// trace filter using
	trace_filter( this, skip, mask, layer, 7 );
}