#pragma once

#define DEG2RAD(x) (x * 0.0174532925f)

namespace ams {
	enum e_command_buttons : int {
		in_attack = ( 1 << 0 ),
		in_jump = ( 1 << 1 ),
		in_duck = ( 1 << 2 ),
		in_forward = ( 1 << 3 ),
		in_back = ( 1 << 4 ),
		in_use = ( 1 << 5 ),
		in_cancel = ( 1 << 6 ),
		in_left = ( 1 << 7 ),
		in_right = ( 1 << 8 ),
		in_moveleft = ( 1 << 9 ),
		in_moveright = ( 1 << 10 ),
		in_second_attack = ( 1 << 11 ),
		in_run = ( 1 << 12 ),
		in_reload = ( 1 << 13 ),
		in_left_alt = ( 1 << 14 ),
		in_right_alt = ( 1 << 15 ),
		in_score = ( 1 << 16 ),
		in_speed = ( 1 << 17 ),
		in_walk = ( 1 << 18 ),
		in_zoom = ( 1 << 19 ),
		in_first_weapon = ( 1 << 20 ),
		in_second_weapon = ( 1 << 21 ),
		in_bullrush = ( 1 << 22 ),
		in_first_grenade = ( 1 << 23 ),
		in_second_grenade = ( 1 << 24 ),
		in_middle_attack = ( 1 << 25 ),
		in_use_or_reload = ( 1 << 26 )
	};

	class base_pb {
		memory_pad( 0x18 );
	};

	class cmd_angle : public base_pb {
	public:
		// memory pad from base_pb.
		evo::vec3_t m_angle; // 0x18
	};

	// assert
	static_assert( sizeof( cmd_angle ) == 0x24 );

	class cmd_vector : public base_pb {
	public:
		evo::vec4_t m_angle;
	};

	// assert
	static_assert( sizeof( cmd_vector ) == 0x28 );

	class interpolation_info_t : public base_pb {
	public:
		float m_fraction;
		int m_source_tick;
		int m_destination_tick;
	};

	// assert
	static_assert( sizeof( interpolation_info_t ) == 0x24 );

	class input_history_entry_pb : public base_pb {
	public:
		cmd_angle* m_view_cmd;
		cmd_vector* m_shoot_origin;
		cmd_vector* m_target_head_origin;
		cmd_vector* m_target_abs_origin;
		cmd_angle* m_target_view;
		interpolation_info_t* cl_interp; // cl_interp - 0x40;
		interpolation_info_t* sv_interp;
		interpolation_info_t* sv_interp_second;
		interpolation_info_t* player_interp;
		int m_render_tick_count;
		float m_render_tick_fraction;
		int m_player_tick_count;
		float m_player_tick_fraction;
		int m_frame_number;
		int m_target_ent_index;
	};

	class user_cmd_pb {
	public:
		int32_t m_tick_count;
		memory_pad( 0x4 );
		void* m_input_history;

		input_history_entry_pb* get_history_entry( std::int32_t m_tick ) {
			if ( m_tick < this->m_tick_count ) {
				input_history_entry_pb** m_tick_list = reinterpret_( input_history_entry_pb**,
																	 reinterpret_( std::uintptr_t, m_input_history ) + 0x8 );
				return m_tick_list[ m_tick ];
			}

			return nullptr;
		}
	};

	// assert
	static_assert( sizeof( user_cmd_pb ) == 0x10 );

	struct button_state_t {
		memory_pad( 0x8 );
		uint64_t m_value;
		uint64_t m_changed_value;
		uint64_t m_scroll_value;
	};

	// assert
	static_assert( sizeof( button_state_t ) == 0x20 );

	class base_user_cmd_pb : public base_pb {
	public:
		memory_pad( 0x20 );
		button_state_t* m_buttons;
		cmd_angle* m_cmd_view;
		int m_command_number;
		int m_tick_count;
		float m_forward_move;
		float m_side_move;
		float m_up_move;
		int32_t m_impulse;
		int32_t m_weapon_select;
		int32_t m_random_seed;
		int32_t moused_x;
		int32_t moused_y;
		uint32_t m_consumed_server_angle_changes;
		int32_t m_cmd_flags;
		uint32_t m_pawn_entity;
		memory_pad( 0x4 );
	};

	// asert.
	static_assert( sizeof( base_user_cmd_pb ) == 0x80 );

	class user_cmd_t {
	public:
		memory_pad( 0x20 );
		user_cmd_pb m_user_cmd;
		base_user_cmd_pb* m_base_cmd;
		memory_pad( 0x10 );
		button_state_t m_buttons;
		memory_pad( 0x20 );

		// set subtick
		// as im aware of it should be a const
		void set_subtick_angle( evo::vec3_t& m_angle ) {
			for ( int i = 0; i < this->m_user_cmd.m_tick_count; i++ ) {
				input_history_entry_pb* m_input_entry = this->m_user_cmd.get_history_entry( i );
				if ( m_input_entry == nullptr ) {
					continue;
				}

				if ( m_input_entry->m_view_cmd == nullptr ) {
					continue;
				}

				// set angles.
				m_input_entry->m_view_cmd->m_angle = m_angle;
				m_input_entry->m_view_cmd->m_angle.clamp( );
			}
		}
	};

	// assert.
	static_assert( sizeof( user_cmd_t ) == 0x88 );


	/*
	#define MULTIPLAYER_BACKUP 150

		enum ECommandButtons {
			IN_NONE = 0x0,
			IN_ALL = 0xffffffffffffffff,
			IN_ATTACK = 0x1,
			IN_JUMP = 0x2,
			IN_DUCK = 0x4,
			IN_FORWARD = 0x8,
			IN_BACK = 0x10,
			IN_USE = 0x20,
			IN_TURNLEFT = 0x80,
			IN_TURNRIGHT = 0x100,
			IN_MOVELEFT = 0x200,
			IN_MOVERIGHT = 0x400,
			IN_ATTACK2 = 0x800,
			IN_RELOAD = 0x2000,
			IN_SPEED = 0x10000,
			IN_JOYAUTOSPRINT = 0x20000,
			IN_FIRST_MOD_SPECIFIC_BIT = 0x100000000,
			IN_USEORRELOAD = 0x100000000,
			IN_SCORE = 0x200000000,
			IN_ZOOM = 0x400000000,
			IN_JUMP_THROW_RELEASE = 0x800000000,
		};

		template <typename T>
		struct repeated_ptr_field_t {
			struct repeat_t {
				int m_alloc_size;
				T* m_elements[ ( INT_MAX - 2 * sizeof( int ) ) / sizeof( void* ) ];
			};

			void* m_arena;
			int m_current_size;
			int m_total_size;
			repeat_t* m_repeat;
		};

		class c_msg_qangle {
		public:
			char pad_0000[ 24 ]; //0x0000
			evo::vec3_t angles;
		};

		class c_msg_vector {
		public:
			std::uint8_t padding_1[ 0x18 ]{ };
			evo::vec3_t m_view_angles; // 0x18
		};

		class c_msg_angle {
		public:
			char pad_0000[ 24 ]; //0x0000
			evo::vec3_t angles; //0x0018
		}; //Size: 0x0024

		class c_csgo_interpolation_info {
		public:
			char pad_0000[ 24 ]; //0x0000
			float fraction; //0x0018
			int32_t src_tick; //0x001C
			int32_t dst_tick; //0x0020
			char pad_0024[ 12 ]; //0x0024
			c_msg_angle entity_view_angles; //0x0030
		}; //Size: 0x0054

		class c_csgo_input_history_entry_pb {
		public:
			char pad_0008[ 8 ]; //0x0008
			uint32_t has_bits;
			uint64_t cached_size;
			c_msg_angle* view_angle_msg; //0x0018
			c_msg_vector* m_shoot_position; //0x0020
			c_msg_vector* m_target_head_position; //0x0028 I wonder guys I wonder
			c_msg_vector* m_target_abs_origin_message; //0x0030
			c_msg_qangle* m_target_angle_message; //0x0038
			c_csgo_interpolation_info* cl_interp; //0x0040
			c_csgo_interpolation_info* sv_interp0; //0x0048
			c_csgo_interpolation_info* sv_interp1; //0x0050
			c_csgo_interpolation_info* player_interp; //0x0058
			int32_t render_tick_count; //0x0060
			float render_tick_fraction; //0x0064
			int32_t player_tick_count; //0x0068
			float player_tick_fraction; //0x006C
			int32_t frame; //0x0070
			int32_t target_ent_index; //0x0074
		};

		class CCmdAllocationParameter {
		public:
			void* vftable;
			uint32_t has_bits;
			uint64_t cached_size;
		};

		class CCSInputHistoryEntry : public CCmdAllocationParameter {
		public:
			c_msg_angle* view_angles;
			c_msg_angle* shooting_position;
			c_msg_angle* target_head_position;
			c_msg_angle* target_abs_origin;
			c_msg_angle* target_view_angles;
			c_csgo_interpolation_info* cl_interp;
			c_csgo_interpolation_info* sv_interp0;
			c_csgo_interpolation_info* sv_interp1;
			c_csgo_interpolation_info* player_interp;
			int32_t render_tickcount;
			float render_fraction;
			int32_t player_tickcount;
			float player_fraction;
			int32_t frametime;
			int32_t target_index;
		};

		struct c_subtick_move_step {
			std::uint8_t padding_1[ 0x18 ]{ };
			uint64_t nButton;
			bool bPressed;
			float flWhen;
		};

		struct c_in_button_state_pb {
			std::uint8_t padding_1[ 0x18 ]{ };
			std::uint64_t m_hold;
			std::uint64_t m_pressed;
			std::uint64_t m_scrolled;
		};

		struct c_in_button_state {
			char pad_0000[ 0x8 ]; // 0x0
			int64_t buttonstate1; // 0x18
			int64_t buttonstate2; // 0x1C
			int64_t buttonstate3; // 0x20
		};

		class CBasePB {
			char pad_001[ 0x18 ]; // 0x0
		};

		class CCmdQAngle : public CBasePB {
		public:
			evo::vec3_t angValue; // 0x18
		};

		class CCmdVector : public CBasePB {
		public:
			evo::vec3_t vecValue; // 0x18
		};

		class CCSGOInterpolationInfo : public CBasePB {
		public:
			float flFraction; // 0x18
			int nSrcTick; // 0x1C
			int nDstTick; // 0x20
		};

		// credits: @patoke [uc:3872928-post1311]
		class CCSGOInputHistoryEntryPB : public CBasePB {
		public:
			CCmdQAngle* pViewCmd; // 0x18
			CCmdVector* pShootOriginCmd; // 0x20
			CCmdVector* pTargetHeadOriginCmd; // 0x28
			CCmdVector* pTargetAbsOriginCmd; // 0x30
			CCmdQAngle* pTargetViewCmd; // 0x38
			CCSGOInterpolationInfo* cl_interp; // 0x40
			CCSGOInterpolationInfo* sv_interp0; // 0x48
			CCSGOInterpolationInfo* sv_interp1; // 0x50
			CCSGOInterpolationInfo* player_interp; // 0x58
			int nRenderTickCount; // 0x60
			float flRenderTickFraction; // 0x64
			int nPlayerTickCount; // 0x68
			float flPlayerTickFraction; // 0x6C
			int nFrameNumber; // 0x70
			int nTargetEntIndex; // 0x74
		};

		class CCSGOUserCmdPB {
		public:
			int32_t nTickCount; // 0x0
			char pad_001[ 0x4 ]; // 0x4
			void* pInputHistory; // 0x8

			CCSGOInputHistoryEntryPB* GetInputHistoryEntry( std::int32_t nTick ) {
				if ( nTick < this->nTickCount ) {
					CCSGOInputHistoryEntryPB** arrTickList = reinterpret_cast< CCSGOInputHistoryEntryPB** >( reinterpret_cast< std::uintptr_t >( pInputHistory ) + 0x8 );
					return arrTickList[ nTick ];
				}

				return nullptr;
			}
		};
		static_assert( sizeof( CCSGOUserCmdPB ) == 0x10 );

		struct CInButtonState {
			char pad_0000[ 0x8 ]; //0x0000
			uint64_t buttonstate1; //0x0008
			uint64_t buttonstate2; //0x0010
			uint64_t buttonstate3; //0x0018
		};

		class CInButtonStatePB {
		public:
			char pad_0000[ 0x18 ]; // 0x0
			int64_t buttonstate1; // 0x18
			int64_t buttonstate2; // 0x1C
			int64_t buttonstate3; // 0x20
		};

		class CMsgQangle {
		public:
			char pad_0000[ 0x18 ]; // 0x0
			float pitch; // 0x18
			float yaw; // 0x1C
			float roll; // 0x20

			void normalize( ) {
				while ( yaw > 180.f ) yaw -= 360.f;
				while ( yaw < -180.f ) yaw += 360.f;

				pitch = min( max( pitch, -89.f ), 89.f );
			}
		};

		class CBaseUserCmd {
		public:
			char pad_0000[ 0x38 ]; //0x0000
			CInButtonStatePB* buttons_pb; //0x0038
			CMsgQangle* viewangles; //0x0040
			int32_t command_number; //0x0048
			int32_t tick_count; //0x004C
			float forwardmove; //0x0050
			float leftmove; //0x0054
			float upmove; //0x0058
			int32_t impulse; //0x0058
			int32_t weaponselect; //0x0060
			int32_t random_seed; //0x0064
			int32_t mousedx; //0x0068
			int32_t mousedy; //0x006C
			bool hasbeenpredicted; //0x0070

			void fix_movement( float original_yaw ) {
				float old_yaw = original_yaw + ( original_yaw < 0.0f ? 360.0f : 0.0f );
				float new_yaw = viewangles->yaw + ( viewangles->yaw < 0.0f ? 360.0f : 0.0f );
				float yaw_delta = new_yaw < old_yaw ? fabsf( new_yaw - old_yaw ) : 360.0f - fabsf( new_yaw - old_yaw );
				yaw_delta = 360.0f - yaw_delta;

				const float _forwardmove = forwardmove;
				const float _sidemove = leftmove;
				forwardmove = std::cos( DEG2RAD( yaw_delta ) ) * _forwardmove + std::cos( DEG2RAD( yaw_delta + 90.0f ) ) * _sidemove;
				leftmove = std::sin( DEG2RAD( yaw_delta ) ) * _forwardmove + std::sin( DEG2RAD( yaw_delta + 90.0f ) ) * _sidemove;
			}
		};

		class c_input_history_entry_pb {
		public:
			char pad_0000[ 24 ]; //0x0000
			c_msg_qangle* angles; //0x0018
			char pad_0020[ 80 ]; //0x0020
		}; //Size: 0x0070

		class c_subtick_container {
		public:
			char pad_0000[ 8 ]; //0x0000
			c_csgo_input_history_entry_pb* subticks[ 7 ]; //0x0008
			char pad_0010[ 56 ]; //0x0010
		}; //Size: 0x0048

		class CUserCmd {
		public:
			char pad_0000[ 32 ]; //0x0000
			int32_t subtick_count; //0x0020
			int32_t max_subtick_count; //0x0024
			c_subtick_container* subticks; //0x0028
			CBaseUserCmd* base_user_cmd_pb; //0x0030
			int32_t attack_history_1; //0x0038
			int32_t attack_history_2; //0x003C
			int32_t attack_history_3; //0x0040
			char pad_0044[ 4 ]; //0x0044
			c_in_button_state button_state; //0x0048
			char pad_0055[ 32 ];

			c_csgo_input_history_entry_pb* get_subtick( int index ) {
				if ( index >= subtick_count )
					return nullptr;

				return subticks->subticks[ index ];
			}
		};
	*/
}