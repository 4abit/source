#pragma once
#include "../../utils/other/utlvector.hpp"

// schema defines.
#define schema_type_scopes 0x188
#define schema_off_1 0x3F8
#define schema_off_2 0x8

namespace ams {
	// macros.
	using schema_string_t = const char*;
	using schema_virtualizer_t = void*;

	// schema metadata.
	struct schema_metadata_entry_t;

	// class.
	class schema_system_type_scope_t;
	class schema_type_t;

	// schema binding.
	struct schema_class_binding_t {
		// parent binding.
		schema_class_binding_t* m_parent;

		// schema names.
		schema_string_t m_binary_name;
		schema_string_t m_module_name;
		schema_string_t m_class_name;

		// virtualization.
		schema_virtualizer_t m_class_info_old;
		schema_virtualizer_t m_class_info;
		schema_virtualizer_t m_module_bind_ptr;

		// schema type.
		schema_type_t* m_schema_type;
	};

	// schema type.
	class schema_type_t {
	public:
		// virtual calling.
		bool get_size_virtual( int* m_out_size, uint8_t* m_unk_ptr ) {
			return ams::memory::call_function<bool, 3>( this, m_out_size, m_unk_ptr );
		}

		// get from virtual.
		bool get_size( int* m_out_size ) {
			uint8_t m_ptr = 0;

			// get size from virtual
			return this->get_size_virtual( m_out_size, &m_ptr );
		}
	public:
		// other shit.
		schema_virtualizer_t m_vtable;
		schema_string_t m_name;

		schema_system_type_scope_t* m_system_type_scope;
		uint8_t m_type_category;
		uint8_t m_atomic_category;
	};

	// schema field.
	struct schema_class_field_data_t {
		schema_string_t m_name;
		schema_type_t* m_schema_type;

		std::uint32_t m_single_offset;
		std::uint32_t m_data_size;

		schema_metadata_entry_t* m_data;
	};

	// struct it.
	struct schema_class_info_data_t;
	struct schema_base_class_info_data_t {
		int32_t m_offset;
		schema_class_info_data_t* m_class;
	};

	// class info
	struct schema_class_info_data_t {
	private:
		schema_virtualizer_t m_vtable;
	public:
		schema_string_t m_name;
		char* m_description;

		int m_size;
		std::int16_t m_field_size;
		std::int16_t m_static_size;
		std::int16_t m_metadata_size;

		std::uint8_t m_align_offset;
		std::uint8_t m_base_class_count;
		
		char pad2[ 0x4 ];
		schema_class_field_data_t* m_fields;
		char pad3[ 0x8 ];
		schema_base_class_info_data_t* m_base_classes;
		char pad4[ 0x28 ];

		// function.
		bool construct_from( schema_class_info_data_t* m_class_info ) {
			if ( m_class_info == this && m_class_info != nullptr ) {
				// go ahead mohamed.
				return true;
			} else if ( this->m_base_classes == nullptr || m_class_info == nullptr ) {
				// stop it here mohamed
				return false;
			}

			for ( int i = 0; i < this->m_base_class_count; i++ ) {
				// get items.
				auto& m_base_class = this->m_base_classes[ i ];
				if ( m_base_class.m_class->construct_from( m_class_info ) ) {
					// thats good.
					return true;
				}
			}

			return false;
		}
	};

	// enumerator info
	struct schema_enumerator_info_data_t {
		schema_string_t m_name;

		// union
		union {
			unsigned char value_char;
			unsigned short value_short;
			unsigned int value_int;
			unsigned long long value;
		};

		// add memory padd
		memory_pad( 0x10 );
	};

	// class enum info.
	class schema_enumerator_info_t {
		schema_enumerator_info_data_t m_info_data;
	};

	// schema enum binding.
	class schema_enum_binding_t {
	public:
		virtual const char* get_binding_name( ) = 0;
		virtual schema_class_binding_t* as_class_binding( ) = 0;
		virtual schema_enum_binding_t* as_enum_binding( ) = 0;
		virtual const char* get_binary_name( ) = 0;
		virtual const char* get_project_name( ) = 0;
	public:
		char* m_binding_name;
		char* m_dll_name;
		std::int8_t m_align;
		memory_pad( 0x3 );
		std::int16_t m_size;
		std::int16_t m_flags;
		schema_enumerator_info_data_t* m_enum_info;
		memory_pad( 0x8 );
		schema_system_type_scope_t* m_type_scope;
		memory_pad( 0x8 );
		std::int32_t m_unknown;
	};

	// schema type scope
	class schema_system_type_scope_t {
	public:
		void find_declared_class( schema_class_info_data_t** m_return_class, const char* m_class_name ) {
			return ams::memory::call_function<void, 2>( this, m_return_class, m_class_name );
		}

		schema_type_t* find_schema_type_by_name( const char* m_name, std::uintptr_t* m_schema ) {
			return ams::memory::call_function< schema_type_t*, 4>( this, m_name, m_schema );
		}

		schema_type_t* find_type_declared_class( const char* m_name ) {
			return ams::memory::call_function< schema_type_t*, 5>( this, m_name );
		}

		schema_type_t* find_type_declared_enum( const char* m_name ) {
			return ams::memory::call_function< schema_type_t*, 6>( this, m_name );
		}

		schema_class_binding_t* find_raw_class_binding( const char* m_name ) {
			return ams::memory::call_function< schema_class_binding_t*, 7>( this, m_name );
		}

		void* m_vtable;
		char m_name[ 256 ];
		memory_pad( schema_off_1 );
		CUtlTSHash< schema_class_binding_t*, 256, unsigned int > m_hash_classes;
		memory_pad( schema_off_2 );
		CUtlTSHash< schema_class_binding_t*, 256, unsigned int > m_hash_enums;
	};

	class schema_system_t {
	public:
		schema_system_type_scope_t* find_module( const char* m_module_name ) {
			return ams::memory::call_function< schema_system_type_scope_t*, 13>( this, m_module_name, nullptr );
		}
	private:
		memory_pad( schema_type_scopes );
	public:
		CUtlVector< schema_system_type_scope_t*> m_vec_type_scopes;
	};
}