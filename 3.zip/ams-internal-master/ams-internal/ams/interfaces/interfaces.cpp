#include "../includes.hpp"
#include "../utils/other/utlvector.hpp"

// force it as nullptr.
ams::client_t* ams::client = nullptr;
ams::schema_system_t* ams::schema_system = nullptr;
ams::mem_alloc_t* ams::mem_alloc = nullptr;
ams::engine_t* ams::engine = nullptr;
ams::game_resource_services_t* ams::resource_services = nullptr;
ams::global_vars_t* ams::globals = nullptr;
ams::cs_input_t* ams::input = nullptr;
ams::material_system_t* ams::material_system = nullptr;
ams::engine_cvar_t* ams::cvar = nullptr;
ams::engine_trace_t* ams::engine_trace = nullptr;//engine_trace_t* engine_trace;

bool ams::interface_t::create_interfaces( ) {
	// create interface.
	ams::client = ams::memory::create_interface<ams::client_t>( "client.dll", "Source2Client002" );
	if ( ams::client == nullptr ) { // i hope this will work
		log_error( "Source2Client002 interface coudn't initialize" );
		return false;
	}

	// create schema system
	ams::schema_system = ams::memory::create_interface<ams::schema_system_t>( "schemasystem.dll", "SchemaSystem_001" );
	if ( ams::schema_system == nullptr ) { // i hope this will work
		log_error( "SchemaSystem_001 interface coudn't initialize" );
		return false;
	}

	// resource services
	ams::resource_services = ams::memory::create_interface<ams::game_resource_services_t>( "engine2.dll", "GameResourceServiceClientV001" );
	if ( ams::resource_services == nullptr ) { // i hope this will work
		log_error( "GameResourceServiceClientV001 interface coudn't initialize" );
		return false;
	} 

	// engine
	ams::engine = ams::memory::create_interface<ams::engine_t>( "engine2.dll", "Source2EngineToClient001" );
	if ( ams::engine == nullptr ) { // i hope this will work
		log_error( "Source2EngineToClient00 interface coudn't initialize" );
		return false;
	}

	ams::input = *reinterpret_cast< ams::cs_input_t** >(
		memory::resolve_rip( memory::find_pattern( L"client.dll", CS_XOR( "48 8B 0D ? ? ? ? 4C 8B C6 8B 10 E8" ) ), 0x3, 0x7 ) );
	if ( ams::input == nullptr ) { // i hope this will work
		log_error( "ams::input coudn't initialize" );
		return false;
	}

	ams::globals = *reinterpret_cast< ams::global_vars_t** >( 
		memory::resolve_rip( memory::find_pattern( L"client.dll", CS_XOR( "48 89 15 ?? ?? ?? ?? 48 89 42" ) ), 0x3, 0x7 ) );
	if ( ams::globals == nullptr ) { // i hope this will work
		log_error( "ams::global_vars_t coudn't initialize" );
		return false;
	}

	// L"materialsystem2.dll"
	// VMaterialSystem2_001
	ams::material_system = ams::memory::create_interface<ams::material_system_t>( "materialsystem2.dll", "VMaterialSystem2_001" );
	if ( ams::material_system == nullptr ) { // i hope this will work
		log_error( "VMaterialSystem2_001 interface coudn't initialize" );
		return false;
	}

	// tier0.dll -> g_pMemAlloc
	// create tire0
	const auto m_tire0_handle = ams::memory::get_module_base_handle( L"tier0.dll" );
	if ( m_tire0_handle == nullptr ) {
		log_error( "m_tire0_handle is nullptr." );
	}

	ams::cvar = ams::memory::create_interface<ams::engine_cvar_t>( "tier0.dll", "VEngineCvar007" );
	if ( ams::cvar == nullptr ) { // i hope this will work
		log_error( "g_pMemAlloc interface coudn't initialize" );
		return false;
	}

	// 	Trace = *reinterpret_cast<i_trace**>(MEM::ResolveRelativeAddress(MEM::FindPattern(CLIENT_DLL, CS_XOR("48 8B 05 ? ? ? ? 80 A4 24")), 0x3, 0x7));

	ams::engine_trace = *reinterpret_cast< ams::engine_trace_t** >( memory::resolve_rip( memory::find_pattern( L"client.dll", CS_XOR( "48 8B 0D ? ? ? ? 4C 8B C3 66 89 44 24" ) ), 0x3, 0x7 ) );
	if ( ams::engine_trace == nullptr ) { // i hope this will work
		log_error( "engine_trace interface coudn't initialize" );
		return false;
	}

	// init this 
	ams::mem_alloc = *reinterpret_cast< ams::mem_alloc_t** >( 
		ams::memory::get_export_address( m_tire0_handle, CS_XOR( "g_pMemAlloc" ) ) );
	if ( ams::mem_alloc == nullptr ) { // i hope this will work
		log_error( "g_pMemAlloc interface coudn't initialize" );
		return false;
	}

	// update this.
	utl_mem::mem_all = ams::mem_alloc;
	if ( utl_mem::mem_all == nullptr ) { // i hope this will work
		log_error( "utl_mem::mem_all couldn't copy ams::mem_alloc data" );
		return false;
	}

	const void* handle_tire0 = ams::memory::get_module_base_handle( L"tier0.dll" );
	ams::load_key_value = reinterpret_cast< decltype( ams::load_key_value ) >
		( memory::get_export_address( handle_tire0, CS_XOR( "?LoadKV3@@YA_NPEAVKeyValues3@@PEAVCUtlString@@PEBDAEBUKV3ID_t@@2@Z" ) ) );

	ams::fn_create_material = reinterpret_cast< decltype( ams::fn_create_material ) >
		( memory::find_pattern( L"materialsystem2.dll", CS_XOR( "48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 56 48 81 EC ? ? ? ? 48 8B 05" ) ) );

	fn_random_float = reinterpret_cast< decltype( fn_random_float ) >( memory::get_export_address( handle_tire0, CS_XOR( "RandomFloat" ) ) );
	fn_random_seed = reinterpret_cast< decltype( fn_random_seed ) >( memory::get_export_address( handle_tire0, CS_XOR( "RandomSeed" ) ) );

	// we got it brother.
	log_success( "interfaces initialized" );

	// return final.
	return true;
}
