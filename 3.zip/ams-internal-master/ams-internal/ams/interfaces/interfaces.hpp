#pragma once
#include "valve/client.hpp"
#include "valve/schema_system.hpp"
#include "valve/memory_alloc.hpp"
#include "valve/entity_system.hpp"
#include "valve/engine.hpp"
#include "valve/game_resource_service.hpp"
#include "valve/global_vars.hpp"
#include "valve/user_cmd.hpp"
#include "valve/cs_input.hpp"
#include "valve/render_view.hpp"
#include "valve/material_system.hpp"
#include "valve/cvar.hpp"
#include "valve/tracing/game_trace.hpp"

namespace ams {
	// main externs.
	extern client_t* client;
	extern schema_system_t* schema_system;
	extern mem_alloc_t* mem_alloc;
	extern engine_t* engine;
	extern game_resource_services_t* resource_services;
	extern global_vars_t* globals;
	extern cs_input_t* input;
	extern material_system_t* material_system;
	extern engine_cvar_t* cvar;
	extern engine_trace_t* engine_trace;

	// externals.
	inline bool( __fastcall* load_key_value )( key_values3_t*, void*, const char*, const kv3_id_t*, const char* );
	inline std::int64_t( __fastcall* fn_create_material )( void*, void*, const char*, void*, unsigned int, unsigned int );
	inline float( CS_CDECL* fn_random_float )( float min_val, float max_val ) = nullptr;
	inline int( CS_CDECL* fn_random_seed )( int i_seed ) = nullptr;

	// main class.
	class interface_t {
	public:
		bool create_interfaces( );
	};

	// will this work?
	share_class( _interfaces, interface_t );
}